/* ==========================================================================
   StudioForge — editor.js
   Edit-mode camera (orbit + pan + zoom) and pointer interaction:
   click to select, drag to move an object across the terrain.
   ========================================================================== */

import * as THREE from 'three';

export class Editor {
  constructor(app) {
    this.app = app;
    this.canvas = app.renderer.domElement;

    this.target = new THREE.Vector3(0, 6, 0);
    this.theta = Math.PI * 0.25;
    this.phi = Math.PI * 0.34;
    this.distance = 95;
    this.minDist = 8;
    this.maxDist = 420;

    this.dragMode = null;      // 'orbit' | 'pan' | 'object'
    this.pointer = { x: 0, y: 0 };
    this.moved = 0;
    this.grabbed = null;

    this.raycaster = new THREE.Raycaster();
    this.ndc = new THREE.Vector2();
    this.groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

    this.bind();
  }

  get active() { return this.app.mode === 'edit'; }

  bind() {
    const c = this.canvas;

    c.addEventListener('pointerdown', (e) => this.onDown(e));
    c.addEventListener('pointermove', (e) => this.onMove(e));
    window.addEventListener('pointerup', () => this.onUp());
    c.addEventListener('wheel', (e) => this.onWheel(e), { passive: false });
    c.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  localPoint(e) {
    const r = this.canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top, w: r.width, h: r.height };
  }

  onDown(e) {
    if (!this.active) return;

    const p = this.localPoint(e);
    this.pointer = { x: p.x, y: p.y };
    this.moved = 0;

    const hit = this.pick(p.x, p.y, p.w, p.h);

    if (e.button === 0 && hit && hit.object) {
      this.app.selectObject(hit.object.id);
      this.dragMode = 'object';
      this.grabbed = hit.object.id;
      this.grabbedStart = { x: hit.object.x, z: hit.object.z };
      this.canvas.setPointerCapture && this.canvas.setPointerCapture(e.pointerId);
      return;
    }

    if (e.button === 0 && !hit) this.app.selectObject(null);

    this.dragMode = e.shiftKey || e.button === 1 || e.button === 2 ? 'pan' : 'orbit';
  }

  onMove(e) {
    if (!this.active) return;

    const p = this.localPoint(e);
    const dx = p.x - this.pointer.x;
    const dy = p.y - this.pointer.y;
    this.pointer = { x: p.x, y: p.y };
    this.moved += Math.abs(dx) + Math.abs(dy);

    if (!this.dragMode) return;

    if (this.dragMode === 'orbit') {
      this.theta -= dx * 0.0052;
      this.phi = Math.max(0.12, Math.min(1.5, this.phi - dy * 0.0042));
    } else if (this.dragMode === 'pan') {
      const scale = this.distance * 0.0018;
      const right = new THREE.Vector3().setFromMatrixColumn(this.app.camera.matrix, 0);
      const up = new THREE.Vector3().setFromMatrixColumn(this.app.camera.matrix, 1);
      this.target.addScaledVector(right, -dx * scale);
      this.target.addScaledVector(up, dy * scale);
      const lim = 340;
      this.target.x = Math.max(-lim, Math.min(lim, this.target.x));
      this.target.z = Math.max(-lim, Math.min(lim, this.target.z));
      this.target.y = Math.max(-20, Math.min(160, this.target.y));
    } else if (this.dragMode === 'object' && this.grabbed != null) {
      const obj = this.app.findObject(this.grabbed);
      if (obj) {
        const ground = this.pickGround(p.x, p.y, p.w, p.h);
        if (ground) {
          obj.x = Math.round(ground.x * 100) / 100;
          obj.z = Math.round(ground.z * 100) / 100;
          obj.y = Math.round(this.app.sampler.heightAt(obj.x, obj.z) * 100) / 100;
          this.app.applyObjectTransform(obj);
          this.app.syncInspectorValues();
        }
      }
    }
  }

  onUp() {
    if (this.dragMode === 'object' && this.grabbed != null && this.moved > 6) {
      this.app.markChange();
      const moved = this.app.findObject(this.grabbed);
      if (moved && this.app.plugins) {
        this.app.plugins.emit('object:moved', { name: moved.name, x: moved.x, z: moved.z });
      }
      this.app.setActivity('Moved object to its new position.');
    }
    this.dragMode = null;
    this.grabbed = null;
  }

  onWheel(e) {
    if (!this.active) return;
    e.preventDefault();
    const f = Math.exp(e.deltaY * 0.0011);
    this.distance = Math.max(this.minDist, Math.min(this.maxDist, this.distance * f));
  }

  /* Screen point → ray. */
  cast(x, y, w, h) {
    this.ndc.x = (x / w) * 2 - 1;
    this.ndc.y = -(y / h) * 2 + 1;
    this.raycaster.setFromCamera(this.ndc, this.app.camera);
    return this.raycaster;
  }

  /* Pick a placed object; returns { object, point } or null. */
  pick(x, y, w, h) {
    const rc = this.cast(x, y, w, h);
    const meshes = this.app.objects.map((o) => o.mesh).filter(Boolean);
    const hits = rc.intersectObjects(meshes, true);

    for (let i = 0; i < hits.length; i++) {
      let node = hits[i].object;
      while (node && !node.userData.objId) node = node.parent;
      if (node && node.userData.objId != null) {
        const obj = this.app.findObject(node.userData.objId);
        if (obj) return { object: obj, point: hits[i].point };
      }
    }
    return null;
  }

  /* Ray → terrain, falling back to a horizontal plane. */
  pickGround(x, y, w, h) {
    const rc = this.cast(x, y, w, h);
    if (this.app.terrain) {
      const hits = rc.intersectObject(this.app.terrain, false);
      if (hits.length) return hits[0].point;
    }
    const out = new THREE.Vector3();
    this.groundPlane.constant = -this.app.sampler.heightAt(this.target.x, this.target.z);
    if (rc.ray.intersectPlane(this.groundPlane, out)) return out;
    return null;
  }

  /* A comfortable spot in front of the camera for newly added objects. */
  spotInFront(distance) {
    const dir = new THREE.Vector3();
    this.app.camera.getWorldDirection(dir);
    dir.y = 0;
    if (dir.lengthSq() < 1e-6) dir.set(0, 0, -1);
    dir.normalize();

    const x = Math.round((this.app.camera.position.x + dir.x * (distance || 22)) * 100) / 100;
    const z = Math.round((this.app.camera.position.z + dir.z * (distance || 22)) * 100) / 100;
    const cx = Math.max(-280, Math.min(280, x));
    const cz = Math.max(-280, Math.min(280, z));
    return { x: cx, z: cz, y: this.app.sampler.heightAt(cx, cz) };
  }

  /* Camera update — called every frame. */
  update() {
    const cam = this.app.camera;
    const sinPhi = Math.sin(this.phi);

    cam.position.set(
      this.target.x + this.distance * sinPhi * Math.cos(this.theta),
      this.target.y + this.distance * Math.cos(this.phi),
      this.target.z + this.distance * sinPhi * Math.sin(this.theta)
    );
    cam.lookAt(this.target);

    if (this.app.terrain) {
      const ground = this.app.sampler.heightAt(cam.position.x, cam.position.z) + 1.6;
      if (cam.position.y < ground) cam.position.y = ground;
    }
  }
}
