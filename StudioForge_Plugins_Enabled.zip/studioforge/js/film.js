/* ==========================================================================
   StudioForge — film.js
   The 🎬 Film workspace: prompt → scenes → shots, storyboard, timeline,
   cinema playback and a continuity bible.

   HONESTY NOTE: this is a deterministic *planner*, not a generative-video
   model. It expands the prompt into a structured, editable storyboard and
   animates that storyboard. It does not render real frames or video.
   ========================================================================== */

const STYLE_CAMERA = {
  'Animation · Cinematic 3D': ['32mm · slow dolly', '50mm · crane up', '85mm · push in', '24mm · low angle'],
  '2D hand-drawn': ['35mm · static frame', '50mm · pan right', '70mm · hold', '28mm · tilt up'],
  Anime: ['40mm · speed lines', '85mm · snap zoom', '50mm · over-shoulder', '24mm · wide sweep'],
  'Stop-motion': ['50mm · locked-off', '35mm · stepped push', '65mm · macro insert', '30mm · tilt down'],
  'Photoreal film': ['24mm · handheld', '50mm · anamorphic pan', '85mm · shallow rack focus', '21mm · steadicam']
};

const LOCATION_KEYS = [
  [/ocean|sea|underwater|abyss|reef/, 'Ocean Planet Surface'],
  [/city|metropolis|citadel|civilis/, 'The Living City'],
  [/station|ship|vessel|hull|bridge/, 'Vessel Interior'],
  [/orbit|space|star|nebula|void/, 'High Orbit'],
  [/desert|dune|sand/, 'Dune Expanse'],
  [/forest|jungle|wood/, 'Deep Forest'],
  [/mountain|peak|ridge|cliff/, 'Mountain Ridge'],
  [/beneath|below|depth|trench/, 'The Deep']
];

const ROLE_WORDS = [
  ['pilot', 'Aria'], ['captain', 'Vance'], ['engineer', 'Rook'],
  ['scientist', 'Dr. Sey'], ['companion', 'KAI-7'], ['ai', 'KAI-7'],
  ['girl', 'Mara'], ['boy', 'Eli'], ['father', 'Corin'], ['mother', 'Sable'],
  ['soldier', 'Kess'], ['thief', 'Nyx']
];

function extractCharacters(text) {
  const found = [];
  const seen = {};

  /* Explicit capitalised names, e.g. "Mara" / "KAI-7" */
  const caps = text.match(/\b[A-Z][a-z]{2,}(?:-\d+)?\b/g) || [];
  caps.forEach((c) => {
    if (['Create', 'Keep', 'Build', 'Make', 'The', 'A', 'An', 'And', 'With',
         'Its', 'This', 'That', 'Then', 'Final', 'Complete', 'Sequence',
         'Visual', 'Style', 'Story', 'Same', 'Film', 'Cinematic', 'Action',
         'Dialogue', 'Emotional', 'Continuity', 'Generating', 'Custom'].indexOf(c) !== -1) return;
    if (!seen[c]) { seen[c] = true; found.push({ name: c, role: 'Lead' }); }
  });

  /* Role nouns → default character names */
  ROLE_WORDS.forEach((pair) => {
    if (new RegExp('\\b' + pair[0] + '\\b', 'i').test(text)) {
      if (!seen[pair[1]]) {
        seen[pair[1]] = true;
        found.push({ name: pair[1], role: pair[0].replace(/\b\w/g, (m) => m.toUpperCase()) });
      }
    }
  });

  if (!found.length) {
    found.push({ name: 'Mara', role: 'Pilot' }, { name: 'KAI-7', role: 'Companion AI' });
  }
  return found.slice(0, 5);
}

function extractLocations(text) {
  const locs = [];
  LOCATION_KEYS.forEach((pair) => {
    if (pair[0].test(text) && locs.indexOf(pair[1]) === -1) locs.push(pair[1]);
  });
  if (!locs.length) locs.push('Unknown Expanse');
  return locs;
}

function extractFacts(text, chars, locs) {
  const facts = [];
  facts.push('Style lock: one visual language across every shot.');
  facts.push('Cast: ' + chars.map((c) => c.name).join(', ') + '.');
  facts.push('Geography: ' + locs.join(' → ') + '.');
  if (/first|opens|begins|arrival/i.test(text)) facts.push('The film opens on arrival, not on backstory.');
  if (/cliffhanger/i.test(text)) facts.push('Final beat is an unresolved cliffhanger.');
  if (/dialogue/i.test(text)) facts.push('Dialogue is carried in close-ups.');
  if (/action/i.test(text)) facts.push('Action beats use wide lenses and fast cutting.');
  return facts;
}

const BEATS = [
  ['Establishing', 'A vast %LOC% fills the frame, scale established before character.', 'wide'],
  ['Arrival', '%LEAD% moves into %LOC%, costume and craft unchanged.', 'tracking'],
  ['Anomaly', 'A signal crosses the frame — something here is alive.', 'insert'],
  ['Descent', 'The camera follows %LEAD% deeper into %LOC%.', 'dolly'],
  ['Revelation', '%LOC% reveals itself in full; the score opens up.', 'crane'],
  ['Ally', '%ALLY% reads the situation and warns %LEAD%.', 'over-shoulder'],
  ['Recognition', 'A quiet close-up: %LEAD% realises what the symbol means.', 'close'],
  ['Escalation', 'The environment reacts — light, movement, rising tension.', 'wide'],
  ['Conflict', 'Opposition arrives; the stakes turn physical.', 'handheld'],
  ['Cost', '%LEAD% pays a price to keep going.', 'close'],
  ['Push', 'Momentum builds toward the centre of %LOC%.', 'tracking'],
  ['Cliffhanger', 'Cut to black on the unanswered question.', 'freeze']
];

/* --------------------------------------------------------------- studio */

export class FilmStudio {
  constructor(api) {
    this.api = api;                 // { toast, setStatus }
    this.projectName = 'The Last Horizon';
    this.scenes = [];
    this.shots = [];                // flat list, carries .sceneName
    this.selectedId = null;
    this.playing = false;
    this.time = 0;                  // seconds
    this.total = 1112;              // 18:32 default
    this.lastShotIndex = -1;
    this.chars = [];
    this.locs = [];
    this.facts = [];
    this.shotCounter = 0;

    this.bind();
    this.buildDefault();
  }

  /* ------------------------------------------------------------- binding */

  bind() {
    const $ = (id) => document.getElementById(id);
    this.els = {
      prompt: $('filmPrompt'),
      style: $('filmStyle'),
      ratio: $('filmRatio'),
      length: $('filmLength'),
      generate: $('filmGenerateBtn'),
      head: $('filmHead'),
      story: $('story'),
      timelineBody: $('filmTimelineBody'),
      caption: $('caption'),
      screenText: $('screenText'),
      screen: $('filmScreen'),
      bar: $('filmBar'),
      time: $('filmTime'),
      play: $('filmPlay'),
      pause: $('filmPause'),
      stop: $('filmStop'),
      addShot: $('filmAddShot'),
      clearShots: $('filmClearShots'),
      exportBtn: $('filmExportBtn'),
      saveBtn: $('filmSaveBtn'),
      projectName: $('filmProjectName'),
      projectMeta: $('filmProjectMeta'),
      runtime: $('filmRuntime'),
      contChars: $('contChars'),
      contLocs: $('contLocs'),
      contFacts: $('contFacts'),
      scenesCount: $('scenesCount'),
      shotsCount: $('shotsCount'),
      framesCount: $('framesCount'),
      audioState: $('audioState'),
      shotName: $('shotName'),
      shotCam: $('shotCam'),
      shotChars: $('shotChars'),
      shotContinuity: $('shotContinuity')
    };

    const e = this.els;

    if (e.generate) e.generate.addEventListener('click', () => this.generate());
    if (e.play) e.play.addEventListener('click', () => this.play());
    if (e.pause) e.pause.addEventListener('click', () => this.pause());
    if (e.stop) e.stop.addEventListener('click', () => this.stop());
    if (e.addShot) e.addShot.addEventListener('click', () => this.addShot());
    if (e.clearShots) e.clearShots.addEventListener('click', () => this.clear());
    if (e.exportBtn) e.exportBtn.addEventListener('click', () => this.exportStoryboard());
    if (e.saveBtn) e.saveBtn.addEventListener('click', () => {
      if (this.api.save) this.api.save(true);
    });

    if (e.length) {
      e.length.addEventListener('change', () => {
        this.total = this.parseLength(e.length.value);
        this.renderTimeline();
        this.updateTimeLabel();
      });
    }

    if (e.style) {
      e.style.addEventListener('change', () => {
        this.reassignCameras();
        this.renderBoard();
        this.renderTimeline();
      });
    }

    /* Left studio menu — retitles the workspace and scrolls to its block. */
    const PANEL_TITLES = {
      maker: 'AI Film Maker', cinema: 'Cinema', edit: 'Edit & Timeline',
      assets: 'Assets', audio: 'Audio & Voices', director: 'AI Director',
      publish: 'Publish'
    };
    const PANEL_ANCHOR = {
      cinema: 'cinemaBlock', edit: 'filmTimeline', assets: 'story'
    };

    Array.prototype.forEach.call(
      document.querySelectorAll('.menu[data-film-panel]'),
      (btn) => btn.addEventListener('click', () => {
        Array.prototype.forEach.call(
          document.querySelectorAll('.menu[data-film-panel]'),
          (x) => x.classList.toggle('active', x === btn)
        );

        const key = btn.dataset.filmPanel;
        if (this.els.head) this.els.head.textContent = PANEL_TITLES[key] || 'AI Film Maker';

        const target = document.getElementById(PANEL_ANCHOR[key] || '');
        if (target && target.scrollIntoView) {
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        this.setRuntime('panel: ' + key);
      })
    );
  }

  parseLength(v) {
    const m = String(v).match(/(\d+):(\d+)/);
    if (m) return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
    return this.total;
  }

  /* ------------------------------------------------------ default project */

  buildDefault() {
    const text = this.els.prompt ? this.els.prompt.value : '';
    const chars = extractCharacters(text);
    const locs = extractLocations(text);
    this.chars = chars;
    this.locs = locs;
    this.facts = extractFacts(text, chars, locs);

    const names = [
      ['Arrival', ['Ocean planet', 'Descent', 'Signal', 'Below']],
      ['The Living City', ['The Gate', 'KAI-7', 'Memory', 'The City']]
    ];

    this.scenes = names.map((pair, si) => ({
      name: 'Scene 0' + (si + 1) + ' — ' + pair[0],
      shots: pair[1].map((title, i) => this.makeShot(title, si, i))
    }));
    this.flatten();
    this.refreshMeta();
  }

  makeShot(title, sceneIndex, indexInScene) {
    const styleCams = STYLE_CAMERA[this.els.style ? this.els.style.value : ''] || STYLE_CAMERA['Animation · Cinematic 3D'];
    const lead = this.chars[0] ? this.chars[0].name : 'Mara';
    const ally = this.chars[1] ? this.chars[1].name : 'KAI-7';
    const loc = this.locs[Math.min(sceneIndex, this.locs.length - 1)];

    const beat = BEATS[(this.shotCounter) % BEATS.length];
    this.shotCounter++;

    let desc = title === 'Ocean planet'
      ? 'A vast blue planet, storm clouds opening to reveal the pilot\u2019s craft.'
      : beat[1].replace('%LEAD%', lead).replace('%ALLY%', ally).replace(/%LOC%/g, loc);

    return {
      id: 'sh' + (indexInScene + 1) + '-' + sceneIndex + '-' + Math.random().toString(36).slice(2, 6),
      number: 0,
      title,
      desc,
      camera: styleCams[this.shotCounter % styleCams.length],
      chars: [lead, ally],
      duration: 8 + (this.shotCounter % 5) * 5,
      continuity: 'Continuity locked'
    };
  }

  flatten() {
    const flat = [];
    let n = 0;
    this.scenes.forEach((sc) => {
      sc.shots.forEach((s) => {
        s.number = ++n;
        s.sceneName = sc.name;
        flat.push(s);
      });
    });
    this.shots = flat;
    return flat;
  }

  reassignCameras() {
    const styleCams = STYLE_CAMERA[this.els.style ? this.els.style.value : ''] ||
      STYLE_CAMERA['Animation · Cinematic 3D'];
    this.shots.forEach((s, i) => { s.camera = styleCams[i % styleCams.length]; });
  }

  /* ------------------------------------------------------------ generate */

  generate() {
    const prompt = this.els.prompt ? this.els.prompt.value : '';
    const btn = this.els.generate;

    if (btn) { btn.textContent = 'Generating…'; btn.disabled = true; }

    setTimeout(() => {
      this.total = this.parseLength(this.els.length ? this.els.length.value : '18:32');

      const chars = extractCharacters(prompt);
      this.chars = chars;
      this.locs = extractLocations(prompt);
      this.facts = extractFacts(prompt, chars, this.locs);

      const styleCams = STYLE_CAMERA[this.els.style ? this.els.style.value : ''] ||
        STYLE_CAMERA['Animation · Cinematic 3D'];

      const sceneCount = 4;
      const perScene = 4;
      this.shotCounter = 0;
      this.scenes = [];

      for (let si = 0; si < sceneCount; si++) {
        const shots = [];
        for (let i = 0; i < perScene; i++) {
          const beat = BEATS[(si * perScene + i) % BEATS.length];
          const loc = this.locs[(si + i) % this.locs.length];
          const lead = chars[0] ? chars[0].name : 'Mara';
          const ally = chars[1] ? chars[1].name : 'KAI-7';

          shots.push({
            id: 'g' + si + '-' + i,
            number: 0,
            title: beat[0],
            desc: beat[1]
              .replace('%LEAD%', lead)
              .replace('%ALLY%', ally)
              .replace(/%LOC%/g, loc),
            camera: styleCams[(si * perScene + i) % styleCams.length],
            chars: [lead, ally],
            duration: 8 + ((si * perScene + i) % 5) * 5,
            continuity: 'Continuity locked'
          });
        }
        this.scenes.push({ name: 'Scene 0' + (si + 1) + ' — ' + this.locs[si % this.locs.length], shots });
      }

      this.flatten();
      this.playing = false;
      this.time = 0;
      this.lastShotIndex = -1;

      if (this.els.bar) this.els.bar.style.width = '0%';
      if (this.els.screenText) {
        this.els.screenText.textContent = 'Cinema Preview — press Play to watch the storyboard';
      }

      this.renderBoard();
      this.renderTimeline();
      this.refreshMeta();
      this.updateTimeLabel();
      this.selectShot(this.shots[0] ? this.shots[0].id : null);
      this.setRuntime('planner run complete · ' + this.shots.length + ' shots');
      if (this.api.emit) this.api.emit('film:generated', { scenes: this.scenes.length, shots: this.shots.length });

      if (btn) { btn.textContent = 'Generate sequence'; btn.disabled = false; }
      if (this.api.toast) {
        this.api.toast('Storyboard planned: ' + this.scenes.length + ' scenes · ' +
          this.shots.length + ' shots (frames are not rendered in this build).');
      }
    }, 700);
  }

  addShot() {
    if (!this.scenes.length) this.scenes.push({ name: 'Scene 01 — Untitled', shots: [] });
    const scene = this.scenes[this.scenes.length - 1];
    const i = scene.shots.length;
    const beat = BEATS[(this.shotCounter + i) % BEATS.length];
    const lead = this.chars[0] ? this.chars[0].name : 'Mara';
    const loc = this.locs[0] || 'the world';

    scene.shots.push({
      id: 'm' + Date.now(),
      number: 0,
      title: beat[0],
      desc: beat[1].replace('%LEAD%', lead).replace('%ALLY%', 'KAI-7').replace(/%LOC%/g, loc),
      camera: '35mm · new shot',
      chars: [lead],
      duration: 10,
      continuity: 'New — needs continuity pass'
    });

    this.flatten();
    this.renderBoard();
    this.renderTimeline();
    this.refreshMeta();
  }

  clear() {
    this.scenes = [];
    this.shots = [];
    this.selectedId = null;
    this.playing = false;
    this.time = 0;
    if (this.els.bar) this.els.bar.style.width = '0%';
    if (this.els.caption) this.els.caption.textContent = 'SHOT —';
    if (this.els.screenText) this.els.screenText.textContent = 'Cinema Preview — storyboard empty';
    this.renderBoard();
    this.renderTimeline();
    this.refreshMeta();
    this.paintInspector(null);
  }

  /* --------------------------------------------------------------- board */

  renderBoard() {
    if (!this.els.story) return;

    if (!this.shots.length) {
      this.els.story.innerHTML =
        '<div class="shot" style="cursor:default"><div class="thumb">EMPTY</div>' +
        '<div class="shotbody"><b>No shots</b><p>Press “Generate sequence” to plan the storyboard.</p></div></div>';
      return;
    }

    this.els.story.innerHTML = this.shots.map((s) =>
      '<div class="shot' + (s.id === this.selectedId ? ' active' : '') +
      '" data-shot="' + s.id + '">' +
        '<div class="thumb">FRAME ' + String(s.number).padStart(2, '0') + '</div>' +
        '<div class="shotbody">' +
          '<b>Shot ' + String(s.number).padStart(2, '0') + ' · ' + escapeHtml(s.title) + '</b>' +
          '<p>' + escapeHtml(s.desc) + '</p>' +
          '<span class="tag">' + escapeHtml(s.continuity) + '</span>' +
        '</div>' +
      '</div>'
    ).join('');

    Array.prototype.forEach.call(
      this.els.story.querySelectorAll('[data-shot]'),
      (node) => node.addEventListener('click', () => this.selectShot(node.dataset.shot))
    );
  }

  selectShot(id) {
    if (!id) return;
    const shot = this.shots.find((s) => s.id === id);
    if (!shot) return;

    this.selectedId = id;

    if (this.els.caption) {
      this.els.caption.textContent = 'SHOT ' + String(shot.number).padStart(2, '0') + ' · ' + shot.title;
    }
    if (this.els.screenText) {
      this.els.screenText.textContent = 'Cinema Preview — ' + shot.title;
    }

    this.paintInspector(shot);
    if (this.api.emit) this.api.emit('shot:selected', { shot });

    Array.prototype.forEach.call(
      this.els.story ? this.els.story.querySelectorAll('[data-shot]') : [],
      (n) => n.classList.toggle('active', n.dataset.shot === id)
    );
    Array.prototype.forEach.call(
      this.els.timelineBody ? this.els.timelineBody.querySelectorAll('[data-clip]') : [],
      (n) => n.classList.toggle('active', n.dataset.clip === id)
    );

    /* Colour the cinema screen per shot so previews read differently. */
    if (this.els.screen) {
      const hue = (shot.number * 37) % 360;
      this.els.screen.style.background =
        'radial-gradient(circle at 50% 40%, hsl(' + hue + ' 32% 24%), #0d1018 62%, #05060a)';
    }
  }

  paintInspector(shot) {
    const e = this.els;
    if (!shot) {
      if (e.shotName) e.shotName.textContent = '—';
      if (e.shotCam) e.shotCam.textContent = '—';
      if (e.shotChars) e.shotChars.textContent = '—';
      if (e.shotContinuity) e.shotContinuity.textContent = '—';
      return;
    }
    if (e.shotName) e.shotName.textContent = 'Shot ' + String(shot.number).padStart(2, '0') + ' · ' + shot.title;
    if (e.shotCam) e.shotCam.textContent = shot.camera;
    if (e.shotChars) e.shotChars.textContent = shot.chars.join(' · ');
    if (e.shotContinuity) {
      e.shotContinuity.textContent = shot.continuity.indexOf('New') === 0
        ? '⚠ ' + shot.continuity
        : '✓ ' + shot.continuity;
    }
  }

  /* ------------------------------------------------------------ timeline */

  renderTimeline() {
    if (!this.els.timelineBody) return;

    if (!this.scenes.length) {
      this.els.timelineBody.innerHTML = 'No scenes yet — generate a sequence.';
      return;
    }

    this.els.timelineBody.innerHTML = this.scenes.map((sc) =>
      '<div class="scene-label">' + escapeHtml(sc.name) + ' · ' + sc.shots.length + ' shot(s)</div>' +
      '<div class="track">' + sc.shots.map((s) =>
        '<div class="clip' + (s.id === this.selectedId ? ' active' : '') + '" data-clip="' + s.id + '">' +
        'Shot ' + String(s.number).padStart(2, '0') + '</div>'
      ).join('') + '</div>'
    ).join('');

    Array.prototype.forEach.call(
      this.els.timelineBody.querySelectorAll('[data-clip]'),
      (n) => n.addEventListener('click', () => this.selectShot(n.dataset.clip))
    );
  }

  /* -------------------------------------------------------------- cinema */

  play() {
    if (!this.shots.length) {
      if (this.api.toast) this.api.toast('Generate a storyboard first.');
      return;
    }
    this.playing = true;
    if (this.api.emit) this.api.emit('cinema:state', { playing: true });
    this.setRuntime('cinema playback running');
  }

  pause() {
    this.playing = false;
    if (this.api.emit) this.api.emit('cinema:state', { playing: false });
    this.setRuntime('cinema playback paused');
  }

  stop() {
    this.playing = false;
    this.time = 0;
    this.lastShotIndex = -1;
    if (this.els.bar) this.els.bar.style.width = '0%';
    this.updateTimeLabel();
    if (this.api.emit) this.api.emit('cinema:state', { playing: false });
    this.setRuntime('cinema stopped');
  }

  /* Called from the app's single rAF loop. dt in seconds. */
  tick(dt) {
    if (!this.playing || !this.shots.length) return;

    /* Playback is compressed: the whole target length plays in ~24 seconds. */
    const wall = Math.max(6, this.total / 46);
    this.time += dt * wall;

    if (this.time >= this.total) {
      this.time = 0;
      this.lastShotIndex = -1;
    }

    const frac = this.time / this.total;
    if (this.els.bar) this.els.bar.style.width = (frac * 100).toFixed(1) + '%';

    const totalWeight = this.shots.reduce((a, s) => a + s.duration, 0);
    let acc = 0;
    let idx = 0;
    for (let i = 0; i < this.shots.length; i++) {
      acc += this.shots[i].duration;
      if (this.time <= (acc / totalWeight) * this.total) { idx = i; break; }
      idx = i;
    }

    if (idx !== this.lastShotIndex) {
      this.lastShotIndex = idx;
      this.selectShot(this.shots[idx].id);
    }

    this.updateTimeLabel();
  }

  updateTimeLabel() {
    if (this.els.time) {
      this.els.time.textContent = fmt(this.time) + ' / ' + fmt(this.total);
    }
  }

  /* --------------------------------------------------------------- meta */

  refreshMeta() {
    const frames = this.shots.reduce((a, s) => a + Math.round(s.duration * 24), 0);
    const e = this.els;

    if (e.contChars) e.contChars.textContent = String(this.chars.length);
    if (e.contLocs) e.contLocs.textContent = String(this.locs.length);
    if (e.contFacts) e.contFacts.textContent = String(this.facts.length);
    if (e.scenesCount) e.scenesCount.textContent = String(this.scenes.length);
    if (e.shotsCount) e.shotsCount.textContent = String(this.shots.length);
    if (e.framesCount) e.framesCount.textContent = frames.toLocaleString();
    if (e.audioState) e.audioState.textContent = this.shots.length ? 'Planned' : '—';
    if (e.projectMeta) {
      e.projectMeta.textContent = this.scenes.length + ' scenes · ' +
        this.shots.length + ' shots · ' + fmt(this.total) + ' target';
    }
    this.updateTimeLabel();
  }

  setRuntime(msg) {
    if (this.els.runtime) this.els.runtime.textContent = msg;
  }

  exportStoryboard() {
    const data = {
      app: 'StudioForge Film Studio',
      version: 1,
      project: this.projectName,
      exportedAt: new Date().toISOString(),
      style: this.els.style ? this.els.style.value : null,
      ratio: this.els.ratio ? this.els.ratio.value : null,
      targetLength: this.total,
      prompt: this.els.prompt ? this.els.prompt.value : '',
      continuity: { characters: this.chars, locations: this.locs, facts: this.facts },
      scenes: this.scenes
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'studioforge-storyboard.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);

    if (this.api.toast) this.api.toast('Storyboard exported as JSON.');
    this.setRuntime('storyboard exported');
  }

  /* ------------------------------------------------------ project bridge */

  serialize() {
    return {
      projectName: this.projectName,
      prompt: this.els.prompt ? this.els.prompt.value : '',
      style: this.els.style ? this.els.style.value : null,
      ratio: this.els.ratio ? this.els.ratio.value : null,
      targetLength: this.total,
      scenes: this.scenes,
      characters: this.chars,
      locations: this.locs,
      facts: this.facts,
      shotCounter: this.shotCounter
    };
  }

  deserialize(d) {
    if (!d) return;
    this.projectName = d.projectName || this.projectName;
    if (this.els.prompt && d.prompt != null) this.els.prompt.value = d.prompt;
    if (this.els.style && d.style) this.els.style.value = d.style;
    if (this.els.ratio && d.ratio) this.els.ratio.value = d.ratio;
    if (d.targetLength) this.total = d.targetLength;
    this.scenes = d.scenes || [];
    this.chars = d.characters || this.chars;
    this.locs = d.locations || this.locs;
    this.facts = d.facts || this.facts;
    this.shotCounter = d.shotCounter || this.shots.length;
    this.flatten();
    this.renderBoard();
    this.renderTimeline();
    this.refreshMeta();
    if (this.shots[0]) this.selectShot(this.shots[0].id);
  }
}

/* ------------------------------------------------------------- helpers */

function fmt(sec) {
  const s = Math.max(0, Math.round(sec));
  const m = Math.floor(s / 60);
  return String(m).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
}

function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
