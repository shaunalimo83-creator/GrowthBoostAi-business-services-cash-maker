/* ==========================================================================
   StudioForge — plugins.js
   Plugin Manager + Event Bus. Every studio capability registers here as a
   plugin, reports its connection state, and talks to every other module
   over the shared bus. The 🧩 Plugin Manager modal lists them all with
   live connect/disconnect toggles and an event log.

   Connected by default: world-forge, asset-palette, wish-engine,
   fps-runtime, film-planner, cinema-playback, continuity-bible,
   voice-narrator, publish-link, storage-sync, pwa-installer, bridge.
   ========================================================================== */

export class PluginSystem {
  constructor(app, defs) {
    this.app = app;
    this.plugins = [];
    this.listeners = {};
    this.logLines = [];
    this.open = false;
    (defs || []).forEach((d) => this.register(d));
  }

  /* ------------------------------------------------------------- the bus */

  on(evt, fn) {
    (this.listeners[evt] = this.listeners[evt] || []).push(fn);
    return () => { this.off(evt, fn); };
  }

  off(evt, fn) {
    const list = this.listeners[evt];
    if (!list) return;
    const i = list.indexOf(fn);
    if (i !== -1) list.splice(i, 1);
  }

  emit(evt, data) {
    data = data || {};
    (this.listeners[evt] || []).slice().forEach((fn) => {
      try { fn(data); } catch (err) { console.error('[bus]', evt, err); }
    });
    this.log('⚡ ' + evt + (data.label ? ' — ' + data.label : ''));
  }

  /* ---------------------------------------------------------- registry */

  register(def) {
    this.plugins.push({
      id: def.id,
      name: def.name,
      icon: def.icon || '🧩',
      desc: def.desc || '',
      setup: def.setup || null,
      connected: false,
      teardown: null
    });
  }

  find(id) { return this.plugins.find((p) => p.id === id) || null; }

  connect(p) {
    if (p.connected) return;
    try {
      p.teardown = p.setup ? p.setup(this.app, this) : null;
      p.connected = true;
      this.log('🔌 connected · ' + p.name);
    } catch (err) {
      this.log('⚠ failed · ' + p.name + ' — ' + err.message);
    }
    this.render();
  }

  disconnect(p) {
    if (!p.connected) return;
    if (typeof p.teardown === 'function') { try { p.teardown(); } catch (e) {} }
    p.teardown = null;
    p.connected = false;
    this.log('⏏ disconnected · ' + p.name);
    this.render();
  }

  toggle(id) {
    const p = this.find(id);
    if (p) { p.connected ? this.disconnect(p) : this.connect(p); }
  }

  connectAll() { this.plugins.forEach((p) => this.connect(p)); }
  connectedCount() { return this.plugins.filter((p) => p.connected).length; }

  /* --------------------------------------------------------------- log */

  log(msg) {
    const stamp = new Date().toTimeString().slice(0, 8);
    this.logLines.push('[' + stamp + '] ' + msg);
    if (this.logLines.length > 140) this.logLines.shift();
    const el = document.getElementById('pluginLog');
    if (el && this.openView) el.textContent = this.logLines.join('\n');
  }

  /* --------------------------------------------------------------- UI */

  showModal() {
    this.openView = true;
    const ov = document.getElementById('pluginsOverlay');
    if (ov) ov.classList.remove('hidden');
    this.render();
  }

  hideModal() {
    this.openView = false;
    const ov = document.getElementById('pluginsOverlay');
    if (ov) ov.classList.add('hidden');
  }

  render() {
    const list = document.getElementById('pluginList');
    if (list) {
      list.innerHTML = this.plugins.map((p) =>
        '<div class="plugin-row' + (p.connected ? ' on' : '') + '" data-plugin="' + p.id + '">' +
          '<span class="plugin-icon">' + p.icon + '</span>' +
          '<span class="plugin-info"><b>' + p.name + '</b>' +
          '<small>' + p.desc + '</small></span>' +
          '<span class="plugin-state">' + (p.connected ? '✓ Connected' : '○ Off') + '</span>' +
          '<button class="plugin-toggle" data-toggle="' + p.id + '">' +
            (p.connected ? 'Disconnect' : 'Connect') + '</button>' +
        '</div>'
      ).join('');

      Array.prototype.forEach.call(
        list.querySelectorAll('[data-toggle]'),
        (btn) => btn.addEventListener('click', () => this.toggle(btn.dataset.toggle))
      );
    }

    const count = document.getElementById('pluginsCount');
    if (count) count.textContent = this.connectedCount() + '/' + this.plugins.length;

    const logEl = document.getElementById('pluginLog');
    if (logEl && this.openView) logEl.textContent = this.logLines.join('\n');
  }
}

/* ----------------------------------------------------------- the plugins */

export function buildPluginDefs() {
  const short = (s, n) => (s.length > n ? s.slice(0, n - 1) + '…' : s);

  return [

    {
      id: 'world-forge',
      name: 'WorldForge · Terrain & Scatter',
      icon: '🌍',
      desc: 'Seeded terrain, water, slope-aware prop scattering and boss placement.',
      setup(app, bus) {
        const off1 = bus.on('world:generated', (d) => {
          app.setAI('WorldForge: seed ' + d.seed + ' resolved — ' + d.objects +
            ' objects across ' + app.WORLD_SIZE + ' m.');
        });
        const off2 = bus.on('object:moved', (d) => {
          app.setStatus('WorldForge: ' + d.name + ' settled at X ' + d.x + ', Z ' + d.z);
        });
        return () => { off1(); off2(); };
      }
    },

    {
      id: 'asset-palette',
      name: 'Asset Palette · Props & Actors',
      icon: '🧱',
      desc: 'Places enemies, buildings, trees, rocks, loot, NPCs and bosses on the terrain.',
      setup(app, bus) {
        const off1 = bus.on('object:added', (d) => {
          app.setAI('Asset palette placed ' + d.name + '. ' + app.objects.length + ' objects in scene.');
        });
        const off2 = bus.on('object:removed', (d) => {
          app.setAI('Removed ' + d.name + '. ' + app.objects.length + ' objects remain.');
        });
        return () => { off1(); off2(); };
      }
    },

    {
      id: 'wish-engine',
      name: 'Wish Engine · Natural Commands',
      icon: '✨',
      desc: 'Parses the wish bar — create, move, resize, delete and regenerate intents.',
      setup(app, bus) {
        return bus.on('wish:processed', (d) => {
          app.setAI('WishEngine → "' + short(d.text, 42) + '" forged: ' + short(d.result, 80));
        });
      }
    },

    {
      id: 'fps-runtime',
      name: 'FPS Runtime · Player & Ballistics',
      icon: '🎮',
      desc: 'Pointer-lock first-person controller, hitscan weapons, hostile AI, HUD.',
      setup(app, bus) {
        return bus.on('mode:changed', (d) => {
          if (d.mode === 'play') {
            const n = app.objects.filter((o) => o.type === 'enemy' || o.type === 'boss').length;
            app.setAI('FPS runtime attached — ' + n + ' hostiles tracking the player.');
          } else {
            app.setAI('FPS runtime detached. Edit-mode camera restored.');
          }
        });
      }
    },

    {
      id: 'film-planner',
      name: 'Film Planner · AI Storyboard',
      icon: '🎬',
      desc: 'Expands the prompt into scenes, shots, camera language and a timeline.',
      setup(app, bus) {
        return bus.on('film:generated', (d) => {
          app.setAI('Film planner built ' + d.scenes + ' scenes / ' + d.shots +
            ' shots. Continuity bible locked.');
        });
      }
    },

    {
      id: 'cinema-playback',
      name: 'Cinema Playback',
      icon: '🎞',
      desc: 'Plays the storyboard on the cinema screen with shot-accurate captions.',
      setup(app, bus) {
        return bus.on('cinema:state', (d) => {
          if (app.film) {
            app.film.setRuntime(d.playing ? 'cinema playback running' : 'cinema playback paused');
          }
        });
      }
    },

    {
      id: 'continuity-bible',
      name: 'Continuity Bible · AI Director',
      icon: '📖',
      desc: 'Carries characters, locations, style and story facts between every shot.',
      setup(app, bus) {
        const off1 = bus.on('shot:selected', (d) => {
          if (d.shot && app.film) {
            const chars = (d.shot.chars || []).join(', ');
            app.setStatus('Shot ' + String(d.shot.number).padStart(2, '0') +
              ' — continuity locked (' + chars + ')');
          }
        });
        const off2 = bus.on('film:generated', () => {
          if (app.film) {
            app.film.setRuntime('continuity bible synced · ' +
              (app.film.chars ? app.film.chars.length : 0) + ' characters tracked');
          }
        });
        return () => { off1(); off2(); };
      }
    },

    {
      id: 'voice-narrator',
      name: 'Voice Narrator · Audio & Voices',
      icon: '🎙',
      desc: 'Speaks each shot title and description during cinema playback (Web Speech).',
      setup(app, bus) {
        let enabled = false;
        let lastSpoken = null;
        const btn = document.getElementById('voiceToggle');
        const card = document.getElementById('audioBlock');

        const paint = () => {
          if (btn) btn.textContent = enabled ? '⏹ Disable voice narration' : '🎙 Enable voice narration';
          if (card) card.style.borderColor = enabled ? 'var(--good, #3ddc84)' : '';
        };

        const speak = (text) => {
          if (!enabled || !('speechSynthesis' in window)) return;
          try {
            window.speechSynthesis.cancel();
            const u = new SpeechSynthesisUtterance(text);
            u.rate = 1.02;
            u.pitch = 0.95;
            window.speechSynthesis.speak(u);
          } catch (e) { /* speech unsupported — stay silent */ }
        };

        const onShot = bus.on('shot:selected', (d) => {
          if (!d.shot || !app.film || !app.film.playing) return;
          if (d.shot.id === lastSpoken) return;
          lastSpoken = d.shot.id;
          speak('Shot ' + d.shot.number + '. ' + d.shot.title + '. ' + d.shot.desc);
        });
        const onStop = bus.on('cinema:state', (d) => {
          if (!d.playing && 'speechSynthesis' in window) window.speechSynthesis.cancel();
          if (!d.playing) lastSpoken = null;
        });
        const onClick = () => { enabled = !enabled; paint(); if (!enabled && 'speechSynthesis' in window) window.speechSynthesis.cancel(); };

        if (btn) btn.addEventListener('click', onClick);
        paint();

        return () => {
          if (off1) off1();
          if (off2) off2();
          if (btn) btn.removeEventListener('click', onClick);
          if ('speechSynthesis' in window) window.speechSynthesis.cancel();
          enabled = false;
          paint();
        };
      }
    },

    {
      id: 'publish-link',
      name: 'Publish Link · Export Pipeline',
      icon: '📤',
      desc: 'Connects the Publish panel to real exports — project JSON + storyboard JSON.',
      setup(app, bus) {
        const note = document.getElementById('filmPublishNote');
        const paint = (extra) => {
          if (note) {
            note.innerHTML = '✓ <b>Connected</b> — the ⇩ button and this panel export the ' +
              'full portable project (game world + film storyboard).' + (extra || '');
          }
        };
        paint();

        const off1 = bus.on('project:exported', () => {
          paint(' Last export: ' + new Date().toLocaleTimeString() + '.');
          app.toast('Publish plugin exported the project bundle.');
        });
        const off2 = bus.on('film:generated', () => paint());

        return () => {
          if (off1) off1();
          if (off2) off2();
          if (note) {
            note.textContent = 'Publish plugin is disconnected — connect it in 🧩 Plugins ' +
              'to link storyboard and world exports.';
          }
        };
      }
    },

    {
      id: 'storage-sync',
      name: 'Storage Sync · Save & Restore',
      icon: '💾',
      desc: 'Auto-saves the project to local storage and restores it on reopen.',
      setup(app, bus) {
        const off1 = bus.on('project:saved', () => {
          app.setStatus('Project saved · storage sync OK');
        });
        const off2 = bus.on('world:generated', () => {
          /* keep the stored copy fresh after a regeneration */
          setTimeout(() => app.saveProject(true), 50);
        });
        return () => { if (off1) off1(); if (off2) off2(); };
      }
    },

    {
      id: 'pwa-installer',
      name: 'PWA Installer · Offline Shell',
      icon: '📲',
      desc: 'Installable app + service-worker cache so the studio reopens offline.',
      setup(app, bus) {
        if ('serviceWorker' in navigator) {
          navigator.serviceWorker.getRegistration().then((r) => {
            if (r) app.setAI('PWA shell cached — StudioForge works offline.');
          }).catch(() => {});
        }
        return bus.on('app:installed', () => app.toast('PWA plugin: install confirmed.'));
      }
    },

    {
      id: 'bridge',
      name: 'Studio Bridge · Film ⇄ Game',
      icon: '🌉',
      desc: 'Cross-workspace link — film beats react to the game world and vice versa.',
      setup(app, bus) {
        const off1 = bus.on('world:generated', (d) => {
          if (app.film) {
            app.film.setRuntime('game world seed ' + d.seed + ' linked to the film studio');
          }
        });
        const off2 = bus.on('film:generated', () => {
          app.setStatus('Film sequence ready — bridge synced to FPS world');
        });
        const off3 = bus.on('mode:changed', (d) => {
          if (d.mode === 'play' && app.film) {
            app.film.setRuntime('play session active — bridge standing by');
          }
        });
        return () => { off1(); off2(); off3(); };
      }
    }
  ];
}
