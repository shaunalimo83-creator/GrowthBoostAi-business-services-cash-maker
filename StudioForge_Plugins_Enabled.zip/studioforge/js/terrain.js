/* ==========================================================================
   StudioForge — terrain.js
   Builds the terrain mesh, water and sky from a height sampler, plus a
   relief-scaling wrapper so the World panel slider rebuilds real geometry.
   ========================================================================== */

import * as THREE from 'three';
import { WORLD, terrainColor } from './noise.js';

/* Scale every height by a factor (the "Terrain relief" control). */
export function scaleSampler(base, factor) {
  const f = Math.max(0.15, factor);
  const heightAt = (x, z) => base.heightAt(x, z) * f;
  return {
    seed: base.seed,
    factor: f,
    heightAt,
    slopeAt: (x, z) => base.slopeAt(x, z) * f,
    biomeAt: (x, z) => base.biomeAt(x, z),
    spawn: { x: base.spawn.x, z: base.spawn.z, y: base.heightAt(0, 0) * f }
  };
}

export function buildTerrain(sampler, opts) {
  opts = opts || {};
  const size = opts.size || WORLD.size;
  const segs = opts.segments || WORLD.segments;

  const geo = new THREE.PlaneGeometry(size, size, segs, segs);
  geo.rotateX(-Math.PI / 2);

  const pos = geo.attributes.position;
  const colors = new Float32Array(pos.count * 3);

  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    const h = sampler.heightAt(x, z);
    pos.setY(i, h);

    const c = terrainColor(h, sampler.slopeAt(x, z), WORLD.waterLevel);
    colors[i * 3] = c[0];
    colors[i * 3 + 1] = c[1];
    colors[i * 3 + 2] = c[2];
  }

  geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geo.computeVertexNormals();
  geo.computeBoundingSphere();

  const mat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.97,
    metalness: 0
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.name = 'terrain';
  mesh.receiveShadow = true;
  mesh.userData.isTerrain = true;
  return mesh;
}

export function buildWater() {
  const geo = new THREE.PlaneGeometry(WORLD.size * 2, WORLD.size * 2, 1, 1);
  geo.rotateX(-Math.PI / 2);

  const mat = new THREE.MeshStandardMaterial({
    color: 0x1d5680,
    transparent: true,
    opacity: 0.76,
    roughness: 0.16,
    metalness: 0.42
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.name = 'water';
  mesh.position.y = WORLD.waterLevel;
  mesh.userData.isWater = true;
  return mesh;
}

export function buildSky() {
  const geo = new THREE.SphereGeometry(3000, 32, 16);

  const mat = new THREE.ShaderMaterial({
    uniforms: {
      topColor: { value: new THREE.Color(0x2b5f9e) },
      bottomColor: { value: new THREE.Color(0xc9dcf2) },
      offset: { value: 120 },
      exponent: { value: 0.75 }
    },
    vertexShader: [
      'varying vec3 vWorldPosition;',
      'void main(){',
      '  vec4 wp = modelMatrix * vec4(position,1.0);',
      '  vWorldPosition = wp.xyz;',
      '  gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0);',
      '}'
    ].join('\n'),
    fragmentShader: [
      'uniform vec3 topColor;',
      'uniform vec3 bottomColor;',
      'uniform float offset;',
      'uniform float exponent;',
      'varying vec3 vWorldPosition;',
      'void main(){',
      '  float h = normalize(vWorldPosition + vec3(0.0, offset, 0.0)).y;',
      '  gl_FragColor = vec4(mix(bottomColor, topColor,',
      '    max(pow(max(h, 0.0), exponent), 0.0)), 1.0);',
      '}'
    ].join('\n'),
    side: THREE.BackSide,
    depthWrite: false
  });

  const mesh = new THREE.Mesh(geo, mat);
  mesh.name = 'sky';
  mesh.userData.isSky = true;
  return mesh;
}

/* Lighting rig: sun with shadows + sky/ground bounce + soft fill. */
export function buildLights() {
  const group = new THREE.Group();
  group.name = 'lights';

  const hemi = new THREE.HemisphereLight(0xbcd8f5, 0x3d4a33, 0.85);
  group.add(hemi);

  const sun = new THREE.DirectionalLight(0xfff2d8, 2.1);
  sun.position.set(120, 170, 90);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.near = 10;
  sun.shadow.camera.far = 520;
  sun.shadow.camera.left = -170;
  sun.shadow.camera.right = 170;
  sun.shadow.camera.top = 170;
  sun.shadow.camera.bottom = -170;
  sun.shadow.bias = -0.0006;
  group.add(sun);

  const fill = new THREE.AmbientLight(0x56708f, 0.35);
  group.add(fill);

  group.userData.sun = sun;
  return group;
}
