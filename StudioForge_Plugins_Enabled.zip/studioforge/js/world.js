/* ==========================================================================
   StudioForge — world.js
   Prop factories (shared geometry/material caches) and the terrain-aware
   scatter pass that populates an open world from a seed.
   ========================================================================== */

import * as THREE from 'three';
import { mulberry32, WORLD } from './noise.js';

/* ----------------------------------------------------------- prop table */

export const PROPS = {
  tree:     { label: 'Tree',     solid: true,  radius: 0.9, yOffset: 0 },
  rock:     { label: 'Rock',     solid: true,  radius: 1.2, yOffset: 0 },
  building: { label: 'Building', solid: true,  radius: 2.8, yOffset: 0 },
  castle:   { label: 'Castle',   solid: true,  radius: 8.5, yOffset: 0 },
  enemy:    { label: 'Enemy',    solid: false, radius: 0.7, yOffset: 0 },
  boss:     { label: 'Boss',     solid: false, radius: 1.8, yOffset: 0 },
  npc:      { label: 'NPC',      solid: false, radius: 0.7, yOffset: 0 },
  loot:     { label: 'Loot',     solid: false, radius: 0.6, yOffset: 0.5 }
};

/* ------------------------------------------------------ shared resources */

const cache = {};
function geo(key, make) {
  if (!cache[key]) cache[key] = make();
  return cache[key];
}
function mat(key, make) {
  if (!cache[key]) cache[key] = make();
  return cache[key];
}

const M = {
  bark: () => mat('bark', () => new THREE.MeshStandardMaterial({ color: 0x5b4227, roughness: 1 })),
  leaf: () => mat('leaf', () => new THREE.MeshStandardMaterial({ color: 0x2f6b3a, roughness: 0.9, flatShading: true })),
  leafDark: () => mat('leafDark', () => new THREE.MeshStandardMaterial({ color: 0x24512e, roughness: 0.9, flatShading: true })),
  stone: () => mat('stone', () => new THREE.MeshStandardMaterial({ color: 0x7d7f86, roughness: 0.95, flatShading: true })),
  wall: () => mat('wall', () => new THREE.MeshStandardMaterial({ color: 0xb9b2a4, roughness: 0.88 })),
  roof: () => mat('roof', () => new THREE.MeshStandardMaterial({ color: 0x7d3b34, roughness: 0.8 })),
  banner: () => mat('banner', () => new THREE.MeshStandardMaterial({ color: 0x2f57b8, roughness: 0.6 })),
  enemy: () => mat('enemy', () => new THREE.MeshStandardMaterial({ color: 0xc4453f, roughness: 0.6, emissive: 0x3a0b0b, emissiveIntensity: 0.6 })),
  boss: () => mat('boss', () => new THREE.MeshStandardMaterial({ color: 0x6b2f8f, roughness: 0.5, emissive: 0x2a0b3a, emissiveIntensity: 0.7 })),
  npc: () => mat('npc', () => new THREE.MeshStandardMaterial({ color: 0x3f9bb0, roughness: 0.7 })),
  loot: () => mat('loot', () => new THREE.MeshStandardMaterial({ color: 0xffcf4d, roughness: 0.25, metalness: 0.75, emissive: 0x6a4a00, emissiveIntensity: 0.5 }))
};

/* -------------------------------------------------------- prop builders */

function tree(rng) {
  const g = new THREE.Group();

  const trunk = new THREE.Mesh(
    geo('trunk', () => new THREE.CylinderGeometry(0.19, 0.29, 2.2, 7)),
    M.bark()
  );
  trunk.position.y = 1.1;
  trunk.castShadow = true;
  g.add(trunk);

  const tiers = 2 + Math.floor(rng() * 2);
  for (let i = 0; i < tiers; i++) {
    const r = 1.75 - i * 0.42;
    const cone = new THREE.Mesh(
      geo('cone' + i, () => new THREE.ConeGeometry(1.75 - i * 0.42, 2.5, 9)),
      i % 2 ? M.leafDark() : M.leaf()
    );
    cone.scale.setScalar(r / 1.75);
    cone.position.y = 2.0 + i * 1.18;
    cone.castShadow = true;
    g.add(cone);
  }
  return g;
}

function rock(rng) {
  const m = new THREE.Mesh(
    geo('rockGeo', () => new THREE.DodecahedronGeometry(1, 0)),
    M.stone()
  );
  m.castShadow = true;
  m.receiveShadow = true;
  m.scale.set(1 + rng() * 0.6, 0.7 + rng() * 0.5, 1 + rng() * 0.6);
  return m;
}

function building() {
  const g = new THREE.Group();

  const body = new THREE.Mesh(
    geo('bldg', () => new THREE.BoxGeometry(5, 4.2, 5)),
    M.wall()
  );
  body.position.y = 2.1;
  body.castShadow = true;
  body.receiveShadow = true;
  g.add(body);

  const roof = new THREE.Mesh(
    geo('roofGeo', () => new THREE.ConeGeometry(4.1, 2.6, 4)),
    M.roof()
  );
  roof.position.y = 5.5;
  roof.rotation.y = Math.PI / 4;
  roof.castShadow = true;
  g.add(roof);

  const door = new THREE.Mesh(
    geo('doorGeo', () => new THREE.BoxGeometry(1.1, 1.9, 0.2)),
    new THREE.MeshStandardMaterial({ color: 0x4a3520, roughness: 0.9 })
  );
  door.position.set(0, 0.95, 2.55);
  g.add(door);

  return g;
}

function castle() {
  const g = new THREE.Group();

  const keep = new THREE.Mesh(
    geo('keep', () => new THREE.BoxGeometry(12, 13, 12)),
    M.wall()
  );
  keep.position.y = 6.5;
  keep.castShadow = true;
  keep.receiveShadow = true;
  g.add(keep);

  const crown = new THREE.Mesh(
    geo('crown', () => new THREE.ConeGeometry(9.4, 5, 4)),
    M.roof()
  );
  crown.position.y = 15.5;
  crown.rotation.y = Math.PI / 4;
  crown.castShadow = true;
  g.add(crown);

  const towerGeo = geo('tower', () => new THREE.CylinderGeometry(2.1, 2.4, 17, 12));
  const capGeo = geo('cap', () => new THREE.ConeGeometry(3, 4.2, 12));
  [[-7.6, -7.6], [7.6, -7.6], [-7.6, 7.6], [7.6, 7.6]].forEach((p) => {
    const t = new THREE.Mesh(towerGeo, M.wall());
    t.position.set(p[0], 8.5, p[1]);
    t.castShadow = true;
    g.add(t);

    const c = new THREE.Mesh(capGeo, M.roof());
    c.position.set(p[0], 19.1, p[1]);
    c.castShadow = true;
    g.add(c);
  });

  const gate = new THREE.Mesh(
    geo('gate', () => new THREE.BoxGeometry(4.4, 6.4, 0.6)),
    new THREE.MeshStandardMaterial({ color: 0x50401f, roughness: 0.85, metalness: 0.2 })
  );
  gate.position.set(0, 3.2, 6.3);
  g.add(gate);

  const flag = new THREE.Mesh(
    geo('flag', () => new THREE.PlaneGeometry(3.4, 2.1)),
    M.banner()
  );
  flag.position.set(0, 20.4, 0);
  flag.rotation.y = Math.PI / 4;
  g.add(flag);

  return g;
}

function humanoid(kind) {
  const g = new THREE.Group();
  const material = kind === 'enemy' ? M.enemy()
    : kind === 'boss' ? M.boss() : M.npc();

  const body = new THREE.Mesh(
    geo('capsule', () => new THREE.CapsuleGeometry(0.42, 1.05, 6, 12)),
    material
  );
  body.position.y = 1.05;
  body.castShadow = true;
  g.add(body);

  const head = new THREE.Mesh(
    geo('head', () => new THREE.SphereGeometry(0.34, 14, 12)),
    material
  );
  head.position.y = 1.98;
  head.castShadow = true;
  g.add(head);

  if (kind === 'enemy' || kind === 'boss') {
    const eyeMat = mat('eye', () => new THREE.MeshStandardMaterial({
      color: 0xffd7a0, emissive: 0xff8a3d, emissiveIntensity: 1.6
    }));
    const eyeGeo = geo('eyeGeo', () => new THREE.SphereGeometry(0.093, 8, 8));
    [-0.14, 0.14].forEach((x) => {
      const e = new THREE.Mesh(eyeGeo, eyeMat);
      e.position.set(x, 2.03, 0.3);
      g.add(e);
    });
  }

  if (kind === 'boss') {
    const hornGeo = geo('horn', () => new THREE.ConeGeometry(0.17, 0.85, 7));
    [-0.3, 0.3].forEach((x) => {
      const h = new THREE.Mesh(hornGeo, M.boss());
      h.position.set(x, 2.42, 0);
      h.rotation.z = x < 0 ? 0.32 : -0.32;
      g.add(h);
    });
    g.scale.setScalar(1.7);
  }

  return g;
}

function loot() {
  const m = new THREE.Mesh(
    geo('lootGeo', () => new THREE.OctahedronGeometry(0.6, 0)),
    M.loot()
  );
  m.userData.spin = true;
  return m;
}

export function buildPropMesh(type, rng) {
  const r2 = rng || Math.random;
  switch (type) {
    case 'tree': return tree(r2);
    case 'rock': return rock(r2);
    case 'building': return building();
    case 'castle': return castle();
    case 'enemy': return humanoid('enemy');
    case 'boss': return humanoid('boss');
    case 'npc': return humanoid('npc');
    case 'loot': return loot();
    default: return building();
  }
}

/* ------------------------------------------------------------ scatter */

const NAME_POOL = {
  tree: ['Pine', 'Oak', 'Birch', 'Elderwood', 'Fir', 'Cedar'],
  rock: ['Boulder', 'Crag', 'Outcrop', 'Megalith'],
  building: ['Watchtower', 'Longhouse', 'Chapel', 'Smithy', 'Storehouse', 'Barracks'],
  enemy: ['Raider', 'Stalker', 'Wraith', 'Ghoul', 'Marauder'],
  npc: ['Merchant', 'Quartermaster', 'Healer', 'Scout'],
  loot: ['Supply Cache', 'Relic', 'Coin Pouch', 'Chest']
};

/*
  Populate a world from a seed. Only places props on walkable land above the
  waterline, so nothing spawns in the sea or on a cliff face.
  Returns objects WITHOUT ids — app.js assigns those.
*/
export function scatterWorld(sampler, seed, opts) {
  opts = opts || {};
  const density = opts.density || 1;
  const rng = mulberry32((seed >>> 0) ^ 0x5f356495);
  const out = [];

  const half = WORLD.size / 2 - 12;

  function findSpot(minY, maxSlope, tries) {
    for (let i = 0; i < (tries || 40); i++) {
      const x = (rng() * 2 - 1) * half;
      const z = (rng() * 2 - 1) * half;
      const h = sampler.heightAt(x, z);
      if (h < WORLD.waterLevel + 1.6) continue;
      if (h > minY) continue;
      if (sampler.slopeAt(x, z) > maxSlope) continue;
      return { x, z, h };
    }
    return null;
  }

  function place(count, type, minY, maxSlope, scaleLo, scaleHi) {
    let made = 0;
    for (let i = 0; i < count; i++) {
      const spot = findSpot(minY, maxSlope);
      if (!spot) continue;
      const pool = NAME_POOL[type] || ['Object'];
      out.push({
        type,
        name: pool[Math.floor(rng() * pool.length)],
        x: round2(spot.x),
        z: round2(spot.z),
        y: round2(spot.h),
        rotation: Math.floor(rng() * 4) * 90,
        scale: round2(scaleLo + rng() * (scaleHi - scaleLo))
      });
      made++;
    }
    return made;
  }

  place(Math.round(150 * density), 'tree', 26, 0.66, 0.8, 1.6);
  place(Math.round(38 * density), 'rock', 40, 1.5, 0.7, 1.9);
  place(Math.round(9 * density), 'building', 20, 0.4, 1, 1.35);
  place(Math.round(14 * density), 'enemy', 24, 0.9, 1, 1);
  place(Math.round(6 * density), 'npc', 18, 0.5, 1, 1);
  place(Math.round(12 * density), 'loot', 22, 0.9, 1, 1);

  /* One boss on the highest reasonable ground it can find. */
  let best = null;
  for (let i = 0; i < 260; i++) {
    const x = (rng() * 2 - 1) * half;
    const z = (rng() * 2 - 1) * half;
    const h = sampler.heightAt(x, z);
    if (h < WORLD.waterLevel + 3 || h > 30) continue;
    if (sampler.slopeAt(x, z) > 0.55) continue;
    if (!best || h > best.h) best = { x, z, h };
  }
  if (best) {
    out.push({
      type: 'boss',
      name: 'Ashen Titan',
      x: round2(best.x),
      z: round2(best.z),
      y: round2(best.h),
      rotation: 0,
      scale: 1
    });
  }

  return out;
}

function round2(v) { return Math.round(v * 100) / 100; }
