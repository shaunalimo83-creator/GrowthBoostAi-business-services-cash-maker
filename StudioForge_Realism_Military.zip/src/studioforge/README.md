# StudioForge — Film Maker + FPS Open-World Studio

One browser app, two workspaces:

* 🎬 **Film** — the AI Film Maker shell: prompt, storyboard, timeline, cinema
  playback, continuity bible, shot inspector, storyboard JSON export.
* 🎮 **FPS World** — a real first-person open world: procedural 600×600 m
  terrain, seeded scatter, pointer-lock mouse look, WASD + sprint + jump +
  crouch, gravity, prop collision, hitscan shooting, hostile AI with contact
  damage, ammo/reload, health regen, respawn, and a full HUD.

Switch between them with the 🎬 Film / 🎮 FPS World tabs in the top bar.

## Run it

A module-based app must be served over http:// — opening index.html by
double-clicking (file://) will NOT work, because ES modules and the service
worker are blocked on that protocol.

    cd studioforge
    python3 -m http.server 8080

Then open http://localhost:8080/index.html

Requires a WebGL2-capable browser (current Chrome, Edge, Firefox or Safari).

## Controls

| Input | Action |
| --- | --- |
| Click viewport | Lock pointer, enter first person |
| W A S D / arrows | Move |
| Shift | Sprint |
| Space | Jump |
| C | Crouch |
| Mouse | Aim |
| LMB | Fire |
| RMB or R | Reload |
| Esc | Release pointer / leave play |
| Tab | Toggle Edit ↔ Play |
| Ctrl+Z / Ctrl+Y | Undo / redo |
| Ctrl+S | Save project |

**Edit mode:** left-drag orbits, Shift+middle/right-drag pans, wheel zooms,
click an object to select it, drag it to move it across the terrain. The
right-hand inspector edits name, X/Z/Y, rotation and scale.

## What is real vs. what is not

**Real and working:** terrain generation from a seed (same seed → same world),
terrain and water meshes, prop scatter, all object editing, undo/redo,
localStorage save, project JSON export/import, the full first-person runtime,
raycast shooting, enemy/boss AI, the wish parser, and film storyboard
planning with playback and JSON export.

**Not implemented:** there is no backend and no model call anywhere. Terrain,
scatter, enemies and the film planner are local and deterministic. The AI
Director is a rule-based parser, not an LLM. The Film workspace does not
render real frames or video — it plans and animates a storyboard. Frames
counts are 24 fps estimates from shot durations, not rendered images.

## Files

    index.html                 both workspaces + import map
    css/studio.css             all styling
    js/app.js                  hub: scene, object store, wiring, main loop
    js/noise.js                seeded Perlin/fBm terrain maths
    js/terrain.js              terrain, water, sky, lights, relief scaling
    js/world.js                prop factories + seeded scatter
    js/editor.js               edit-mode camera and pointer interaction
    js/play.js                 first-person player, weapons, hostile AI
    js/film.js                 film workspace planner and playback
    vendor/three.module.js     three.js r160 (vendored, works offline)
    sw.js                      offline app-shell cache
    manifest.webmanifest       PWA metadata
    icons/                     app icons

## Plugin system

Every studio capability runs as a plugin behind a shared event bus. Manage
them in-app via the 🧩 button (connect/disconnect per plugin, live event log).

| Plugin id | Name | What it does |
| --- | --- | --- |
| world-forge | WorldForge · Terrain & Scatter | Seeded terrain, water, slope-aware scattering |
| asset-palette | Asset Palette · Props & Actors | Places enemies, buildings, trees, rocks, loot, NPCs, bosses |
| wish-engine | Wish Engine · Natural Commands | Parses wish-bar commands (create/move/resize/delete) |
| fps-runtime | FPS Runtime · Player & Ballistics | First-person controller, weapons, hostile AI, HUD |
| film-planner | Film Planner · AI Storyboard | Prompt → scenes → shots → timeline |
| cinema-playback | Cinema Playback | Storyboard playback with captions |
| continuity-bible | Continuity Bible · AI Director | Characters/locations/style carried between shots |
| voice-narrator | Voice Narrator · Audio & Voices | Web Speech narration during playback |
| publish-link | Publish Link · Export Pipeline | Live export status in the Publish panel |
| storage-sync | Storage Sync · Save & Restore | Auto-save and project restore |
| pwa-installer | PWA Installer · Offline Shell | Install + offline service-worker cache |
| bridge | Studio Bridge · Film ⇄ Game | Cross-workspace event linking |

Bus events: `world:generated`, `object:added`, `object:removed`, `object:moved`,
`wish:processed`, `mode:changed`, `film:generated`, `shot:selected`,
`cinema:state`, `project:saved`, `project:exported`, `app:installed`.
