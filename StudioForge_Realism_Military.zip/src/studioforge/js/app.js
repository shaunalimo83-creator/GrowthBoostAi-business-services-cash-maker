/* ==========================================================================
   StudioForge — app.js
   The hub. Owns the Three.js scene, the object store, the FPS editor and
   the play mode, the wish parser, project save/load/export, and wires the
   🎬 Film workspace (film.js) in alongside the 🎮 FPS World workspace.

   There is no backend and no model call anywhere in this app: terrain,
   scatter, enemies and the film planner are all local and deterministic.
   ========================================================================== */

import * as THREE from 'three';
import { WORLD, makeHeightSampler, mulberry32 } from './noise.js';
import { buildTerrain, buildWater, buildSky, buildLights, scaleSampler } from './terrain.js';
import { PROPS, buildPropMesh, scatterWorld } from './world.js';
import { Editor } from './editor.js';
import { Player } from './play.js';
import { FilmStudio } from './film.js';
import { PluginSystem, buildPluginDefs } from './plugins.js';
import { DesignAssistant } from './designer.js';
import { createComposer, applyGoldenHour, addInstancedGrass } from './realism.js';

const $ = (id) => document.getElementById(id);
const STORAGE_KEY = 'studioforge.project.v1';

/* ------------------------------------------------------------- the app */

class StudioForge {
  constructor() {
    this.WORLD_SIZE = WORLD.size;
    this.waterY = WORLD.waterLevel;

    this.mode = 'edit';
    this.workspace = 'game';
    this.objects = [];
    this.nextId = 1;
    this.selectedId = null;

    this.seed = 482917;
    this.relief = 32;
    this.gameType = 'FPS';

    this.fps = 0;
    this._frames = 0;
    this._fpsT = 0;

    this.history = { past: [], future: [], limit: 60 };
    this.lastSnap = '';

    this.els = {};
    this.collectElements();

    /* Plugin layer — every module below talks through this bus. */
    this.plugins = new PluginSystem(this, buildPluginDefs());

    /* Shared HUD handle — play.js reads every live readout through this. */
    this.hud = {
      root: this.els.gameHud,
      crosshair: this.els.crosshair,
      overlay: this.els.playOverlay,
      objective: this.els.hudObjective,
      health: this.els.hudHealth,
      healthBar: this.els.healthBar,
      kills: this.els.hudKills,
      pos: this.els.hudPos,
      fps: this.els.hudFps,
      ammo: this.els.hudAmmo,
      reserve: this.els.hudReserve,
      hitMarker: this.els.hitMarker,
      vignette: this.els.damageVignette,
      reloadHint: this.els.reloadHint
    };

    this.initThree();
    this.initObjects();

    /* Film workspace first: it is self-contained and needs no GL. */
    this.film = new FilmStudio({
      toast: (m) => this.toast(m),
      save: (silent) => this.saveProject(silent),
      emit: (evt, data) => { if (this.plugins) this.plugins.emit(evt, data); }
    });

    this.editor = new Editor(this);
    this.player = new Player(this);

    /* 🎨 Design assistant — request → generate → sandbox/archive/publish. */
    this.designer = new DesignAssistant({ app: this, toast: (m) => this.toast(m) });

    /* Wire every plugin in — connect/disconnect per-plugin in 🧩 Plugins. */
    this.plugins.connectAll();

    this.bindUI();
    this.restoreOrSeed();
    this.publishWorld();

    this.applyPanel('game');
    this.refreshHistoryButtons();
    this.setStatus('Ready');
    this.loop();
  }

  /* ------------------------------------------------------------ elements */

  collectElements() {
    const ids = [
      'undoBtn', 'redoBtn', 'saveBtn', 'exportBtn', 'importInput', 'installBtn',
      'workspaceTabs',
      'gameType', 'worldSeed', 'worldRelief', 'generateWorld',
      'editMode', 'playMode', 'status', 'engineLabel',
      'gameViewport', 'gameCanvas', 'crosshair', 'playOverlay', 'gameHud',
      'hudObjective', 'hudHealth', 'healthBar', 'hudKills', 'hudPos', 'hudFps',
      'hudAmmo', 'hudReserve', 'hitMarker', 'damageVignette', 'reloadHint',
      'wishInput', 'wishButton', 'activityText',
      'emptyInspector', 'inspector', 'objectName', 'objectType',
      'objectX', 'objectZ', 'objectY', 'objectRotation', 'objectScale',
      'duplicateObject', 'deleteObject',
      'aiMessage', 'objectCount', 'seedDisplay', 'modeDisplay',
      'debugView', 'renderStats', 'toast'
    ];
    ids.forEach((id) => { this.els[id] = $(id); });
  }

  /* -------------------------------------------------------------- render */

  initThree() {
    const canvas = this.els.gameCanvas;

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance'
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.06;

    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.Fog(0xa9c6e2, 220, 780);

    this.camera = new THREE.PerspectiveCamera(72, 1, 0.1, 4000);

    this.scene.add(buildSky());
    this.lights = buildLights();
    this.scene.add(this.lights);

    this.terrainGroup = new THREE.Group();
    this.terrainGroup.name = 'terrainGroup';
    this.scene.add(this.terrainGroup);

    this.objGroup = new THREE.Group();
    this.objGroup.name = 'objects';
    this.scene.add(this.objGroup);

    this.terrain = null;
    this.water = null;
    this.selHelper = null;

    /* Cinematic post-processing chain (bloom + ACES output). */
    this.composer = createComposer(this);

    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  resize() {
    const vp = this.els.gameViewport;
    if (!vp) return;
    const w = Math.max(1, vp.clientWidth);
    const h = Math.max(1, vp.clientHeight);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    if (this.composer) this.composer.setSize(w, h);
  }

  initObjects() {
    /* An empty store; the world (or a restored project) fills it. */
    this.objects = [];
    this.nextId = 1;
  }

  /* -------------------------------------------------------- world build */

  buildWorld(seed, relief) {
    this.seed = (seed >>> 0) || 482917;
    this.relief = Math.max(6, Math.min(80, relief || 32));

    const base = makeHeightSampler(this.seed);
    this.sampler = scaleSampler(base, this.relief / 32);

    /* Terrain */
    if (this.terrain) {
      this.terrainGroup.remove(this.terrain);
      this.terrain.geometry.dispose();
      this.terrain.material.dispose();
      this.terrain = null;
    }
    this.terrain = buildTerrain(this.sampler, { size: WORLD.size, segments: WORLD.segments });
    this.terrainGroup.add(this.terrain);

    /* Water */
    if (this.water) {
      this.terrainGroup.remove(this.water);
      this.water.geometry.dispose();
      this.water.material.dispose();
      this.water = null;
    }
    this.water = buildWater();
    this.water.position.y = this.waterY;
    this.terrainGroup.add(this.water);

    /* Golden-hour grading + instanced vegetation for this seed. */
    applyGoldenHour(this);
    addInstancedGrass(this);

    this.els.seedDisplay.textContent = String(this.seed);
  }

  /* Instantiate meshes for every object record. */
  publishWorld() {
    while (this.objGroup.children.length) {
      this.objGroup.remove(this.objGroup.children[0]);
    }
    this.objects.forEach((o) => this.spawnMesh(o));
    this.refreshCounts();
    this.updateDebug();
  }

  spawnMesh(o) {
    const rng = mulberry32(((this.seed >>> 0) ^ (o.id * 2654435761)) >>> 0);
    const mesh = buildPropMesh(o.type, rng);
    mesh.userData.objId = o.id;
    mesh.traverse && mesh.traverse((c) => { c.userData.objId = o.id; });

    o.mesh = mesh;
    o.solid = !!(PROPS[o.type] && PROPS[o.type].solid);
    o.radius = (PROPS[o.type] && PROPS[o.type].radius) || 1;

    this.objGroup.add(mesh);
    this.applyObjectTransform(o);
    return mesh;
  }

  applyObjectTransform(o) {
    if (!o.mesh) return;
    o.mesh.position.set(o.x, o.y, o.z);
    o.mesh.rotation.y = (o.rotation || 0) * Math.PI / 180;
    o.mesh.scale.setScalar(o.scale || 1);
  }

  /* -------------------------------------------------------- object model */

  findObject(id) {
    return this.objects.find((o) => o.id === id) || null;
  }

  selected() {
    return this.selectedId == null ? null : this.findObject(this.selectedId);
  }

  addObject(spec) {
    const type = PROPS[spec.type] ? spec.type : 'building';
    const o = {
      id: this.nextId++,
      type,
      name: spec.name || PROPS[type].label,
      x: round2(spec.x != null ? spec.x : 0),
      z: round2(spec.z != null ? spec.z : 0),
      y: round2(spec.y != null ? spec.y : this.sampler.heightAt(spec.x || 0, spec.z || 0)),
      rotation: spec.rotation != null ? spec.rotation : 0,
      scale: spec.scale != null ? clamp(spec.scale, 0.2, 6) : 1
    };
    if (spec.stats) Object.assign(o, spec.stats);

    this.objects.push(o);
    this.spawnMesh(o);
    this.refreshCounts();
    if (this.plugins) this.plugins.emit('object:added', { name: o.name, type: o.type, id: o.id });
    return o;
  }

  removeObject(id, opts) {
    opts = opts || {};
    const i = this.objects.findIndex((o) => o.id === id);
    if (i === -1) return;

    const o = this.objects[i];
    if (o.mesh) {
      this.objGroup.remove(o.mesh);
      o.mesh.traverse && o.mesh.traverse((c) => {
        if (c.geometry && c.geometry.dispose) { /* shared geometry: keep */ }
      });
    }
    this.objects.splice(i, 1);

    if (this.selectedId === id) this.selectedId = null;
    if (this.plugins) this.plugins.emit('object:removed', { name: o.name, id });
    this.refreshCounts();
    this.renderInspector();

    if (!opts.silent) {
      this.markChange();
      if (!opts.keepHistory) this.setActivity('Deleted ' + o.name + '.');
    } else if (!opts.keepHistory) {
      this.markChange();
    }
    this.updateDebug();
  }

  selectObject(id) {
    this.selectedId = id;
    this.renderInspector();

    /*
      Selection outline is drawn with a BoxHelper, NOT by tinting materials:
      prop materials are cached and shared between every instance of a type,
      so tinting one would light up all of them at once.
    */
    const o = this.selected();

    if (o && o.mesh) {
      if (!this.selHelper) {
        this.selHelper = new THREE.BoxHelper(o.mesh, 0x4cc2ff);
        this.selHelper.material.depthTest = false;
        this.selHelper.material.transparent = true;
        this.scene.add(this.selHelper);
      } else {
        this.selHelper.setFromObject(o.mesh);
      }
      this.selHelper.visible = true;
    } else if (this.selHelper) {
      this.selHelper.visible = false;
    }

    if (o) {
      this.setStatus('Selected: ' + o.name);
      this.setActivity('Inspector is showing ' + o.name + '.');
    }
    this.updateDebug();
  }

  refreshCounts() {
    this.els.objectCount.textContent = String(this.objects.length);
    this.els.seedDisplay.textContent = String(this.seed);
  }

  /* ------------------------------------------------------------ inspector */

  renderInspector() {
    const o = this.selected();
    if (!o) {
      this.els.inspector.classList.add('hidden');
      this.els.emptyInspector.classList.remove('hidden');
      return;
    }
    this.els.emptyInspector.classList.add('hidden');
    this.els.inspector.classList.remove('hidden');
    this.syncInspectorValues();
  }

  syncInspectorValues() {
    const o = this.selected();
    if (!o) return;
    this.els.objectName.value = o.name;
    this.els.objectType.value = PROPS[o.type].label + ' (' + o.type + ')';
    this.els.objectX.value = o.x;
    this.els.objectZ.value = o.z;
    this.els.objectY.value = o.y;
    this.els.objectRotation.value = o.rotation || 0;
    this.els.objectScale.value = o.scale;
  }

  /* -------------------------------------------------------------- history */

  snapshot() {
    return JSON.stringify({
      objects: this.objects.map((o) => ({
        id: o.id, type: o.type, name: o.name,
        x: o.x, y: o.y, z: o.z, rotation: o.rotation, scale: o.scale
      })),
      selectedId: this.selectedId,
      seed: this.seed,
      relief: this.relief,
      gameType: this.gameType,
      nextId: this.nextId
    });
  }

  markChange() {
    this.history.past.push(this.lastSnap || this.snapshot());
    if (this.history.past.length > this.history.limit) this.history.past.shift();
    this.history.future.length = 0;
    this.lastSnap = this.snapshot();
    this.refreshHistoryButtons();
    this.updateDebug();
  }

  applySnapshot(str) {
    const d = JSON.parse(str);

    this.objects.forEach((o) => { if (o.mesh) this.objGroup.remove(o.mesh); });
    this.objects = [];
    this.nextId = d.nextId || 1;
    this.selectedId = null;

    (d.objects || []).forEach((s) => {
      const o = {
        id: s.id, type: s.type, name: s.name,
        x: s.x, y: s.y, z: s.z,
        rotation: s.rotation || 0, scale: s.scale != null ? s.scale : 1
      };
      this.objects.push(o);
      this.spawnMesh(o);
    });

    this.gameType = d.gameType || this.gameType;
    this.els.gameType.value = this.gameType;

    this.refreshCounts();
    this.renderInspector();
    this.updateDebug();
  }

  undo() {
    if (!this.history.past.length) return;
    this.history.future.push(this.snapshot());
    this.applySnapshot(this.history.past.pop());
    this.lastSnap = this.snapshot();
    this.refreshHistoryButtons();
    this.setActivity('Undid the last change.');
  }

  redo() {
    if (!this.history.future.length) return;
    this.history.past.push(this.snapshot());
    this.applySnapshot(this.history.future.pop());
    this.lastSnap = this.snapshot();
    this.refreshHistoryButtons();
    this.setActivity('Redid the change.');
  }

  refreshHistoryButtons() {
    this.els.undoBtn.disabled = this.history.past.length === 0;
    this.els.redoBtn.disabled = this.history.future.length === 0;
  }

  resetHistory() {
    this.history.past.length = 0;
    this.history.future.length = 0;
    this.lastSnap = this.snapshot();
    this.refreshHistoryButtons();
  }

  /* ----------------------------------------------------------------- copy */

  setStatus(s) { this.els.status.textContent = s; }
  setActivity(s) { this.els.activityText.textContent = s; }
  setAI(s) { this.els.aiMessage.textContent = s; }

  toast(msg) {
    const t = this.els.toast;
    t.textContent = msg;
    t.classList.remove('hidden');
    clearTimeout(this._toast);
    this._toast = setTimeout(() => t.classList.add('hidden'), 2600);
  }

  /* --------------------------------------------------------------- panels */

  applyPanel(name) {
    Array.prototype.forEach.call(
      document.querySelectorAll('.menu[data-panel]'),
      (b) => b.classList.toggle('active', b.dataset.panel === name)
    );

    Array.prototype.forEach.call(
      document.querySelectorAll('[data-panel-section]'),
      (sec) => {
        const key = sec.dataset.panelSection;
        const show = key === name ||
          (name === 'game' && key === 'game') ||
          (name === 'assets' && (key === 'assets' || key === 'game'));
        sec.style.display = show ? '' : 'none';
      }
    );

    const info = {
      game: ['Project ready', 'Game panel — pick a genre, then generate and explore a world.'],
      world: ['World panel', 'World panel — set a seed and relief, then press Generate World.'],
      assets: ['Asset palette', 'Asset panel — add props, hostiles, NPCs, loot or a boss.'],
      ai: ['AI Director ready', 'AI Director — describe what you want in the wish bar below.'],
      debug: ['Debug view', 'Debug panel — live object, history and framebuffer state.']
    }[name] || ['StudioForge', 'Panel ready.'];

    this.setStatus(info[0]);
    this.setActivity(info[1]);
    this.updateDebug();
  }

  updateDebug() {
    const o = this.selected();
    const data = {
      workspace: this.workspace,
      mode: this.mode,
      seed: this.seed,
      relief: this.relief,
      gameType: this.gameType,
      objects: this.objects.length,
      hostiles: this.objects.filter((x) => x.type === 'enemy' || x.type === 'boss').length,
      selected: o ? { id: o.id, name: o.name, type: o.type, x: o.x, y: o.y, z: o.z, scale: o.scale } : null,
      history: { undo: this.history.past.length, redo: this.history.future.length }
    };
    this.els.debugView.textContent = JSON.stringify(data, null, 2);
    this.els.aiMessage.textContent = this.els.aiMessage.textContent || 'Monitoring game state.';
  }

  /* ------------------------------------------------------------ wish parser */

  interpretWish(raw) {
    const text = String(raw || '').toLowerCase().trim();
    if (!text) return 'Type a wish first — try "create a giant castle".';

    const TYPE_WORDS = [
      [/castle|fortress|keep|palace/, 'castle'],
      [/tower|house|building|hut|village|storehouse|barracks/, 'building'],
      [/enem|monster|raider|stalker|wraith|ghoul|marauder|hostile/, 'enemy'],
      [/boss|dragon|titan|leviathan|behemoth/, 'boss'],
      [/tree|forest|pine|oak|birch|foliage/, 'tree'],
      [/rock|boulder|stone|crag|mountain/, 'rock'],
      [/loot|chest|treasure|relic|cache/, 'loot'],
      [/npc|villager|merchant|healer|scout|trader/, 'npc']
    ];

    const detect = (t) => {
      for (const p of TYPE_WORDS) if (p[0].test(t)) return p[1];
      return null;
    };

    const count = (() => {
      const w = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10 };
      const m = text.match(/\b(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\b/);
      if (!m) return 1;
      return w[m[1]] || clamp(parseInt(m[1], 10) || 1, 1, 20);
    })();

    const findTarget = (t) => {
      if (/selected|this|it\b/.test(t)) { const s = this.selected(); if (s) return s; }
      const named = this.objects.find((o) => t.includes(o.name.toLowerCase()) && o.name.length > 3);
      if (named) return named;
      const type = detect(t);
      if (type) return this.objects.find((o) => o.type === type) || null;
      return null;
    };

    /* 1 — regenerate the world */
    if (/world|terrain|map|landscape/.test(text) &&
        /generate|new|random|rebuild|regenerate|fresh/.test(text)) {
      const random = /random|fresh|new/.test(text);
      const seed = random ? Math.floor(Math.random() * 900000) + 100000
                          : parseInt(this.els.worldSeed.value, 10) || this.seed;
      this.generateWorld(seed, true);
      return 'Generated a fresh open world with seed ' + this.seed + '.';
    }

    /* 2 — delete */
    if (/\b(delete|remove|destroy|clear|erase)\b/.test(text)) {
      if (/all|everything|world/.test(text)) {
        const n = this.objects.length;
        this.objects.slice().forEach((o) => this.removeObject(o.id, { silent: true }));
        this.markChange();
        this.publishWorld();
        this.setAI('World cleared — ' + n + ' objects removed.');
        return 'Removed every object (' + n + ' deleted).';
      }
      const type = detect(text);
      if (type && !/selected|this|it\b/.test(text)) {
        const doomed = this.objects.filter((o) => o.type === type);
        doomed.forEach((o) => this.removeObject(o.id, { silent: true }));
        this.markChange();
        this.setAI('Deleted ' + doomed.length + ' ' + type + ' object(s).');
        return doomed.length ? 'Deleted ' + doomed.length + ' ' + type + ' object(s).'
                             : 'There were no ' + type + ' objects to delete.';
      }
      const target = findTarget(text.replace(/\b(delete|remove|destroy|clear|erase)\b/g, ''));
      if (target) {
        const name = target.name;
        this.removeObject(target.id, { silent: true });
        this.markChange();
        return 'Deleted ' + name + '.';
      }
      return 'Nothing matched — select an object or name a type to delete.';
    }

    /* 3 — move */
    if (/\b(move|put|place|position|shift|send)\b/.test(text) || /\bbehind\b/.test(text)) {
      const target = findTarget(text);
      if (!target) return 'I could not tell which object you mean — select one or name it.';

      const player = this.objects.find((o) => o.type === 'player') || null;

      if (/behind/.test(text) && player) {
        target.x = player.x; target.z = player.z - 14;
      } else if (/cent(er|re)|middle/.test(text)) {
        target.x = 0; target.z = 0;
      } else if (/\bleft\b/.test(text)) {
        target.x = -30;
      } else if (/\bright\b/.test(text)) {
        target.x = 30;
      } else if (/\b(north|far|back|top)\b/.test(text)) {
        target.z = -60;
      } else if (/\b(south|near|front|bottom|close)\b/.test(text)) {
        target.z = 60;
      } else {
        const spot = this.editor.spotInFront(24);
        target.x = spot.x; target.z = spot.z;
      }

      target.y = round2(this.sampler.heightAt(target.x, target.z));
      this.applyObjectTransform(target);
      this.markChange();
      this.selectObject(target.id);
      return 'Moved ' + target.name + ' to X ' + target.x + ', Z ' + target.z + '.';
    }

    /* 4 — resize */
    if (/\b(bigger|larger|huge|giant|smaller|tiny|shrink|grow|scale|resize)\b/.test(text)) {
      const target = findTarget(text);
      if (!target) return 'Select an object first, then ask me to resize it.';
      let f = 1.35;
      if (/smaller|shrink|tiny|little/.test(text)) f = 0.75;
      if (/giant|huge|enormous|massive|colossal/.test(text)) f = 1.95;
      const before = target.scale;
      target.scale = clamp(round2(target.scale * f), 0.2, 6);
      this.applyObjectTransform(target);
      this.markChange();
      this.selectObject(target.id);
      return 'Resized ' + target.name + ' from ' + before + '× to ' + target.scale + '×.';
    }

    /* 5 — create */
    if (/\b(create|add|spawn|make|build|place|want|give)\b/.test(text)) {
      const type = detect(text);
      if (!type) {
        return 'I read the wish but not the thing — try castle, building, tree, rock, loot, NPC, enemy or boss.';
      }

      const giant = /giant|colossal|massive|huge|enormous/.test(text);
      const small = /tiny|small|little|mini/.test(text);
      const scale = giant ? (type === 'castle' ? 1.9 : 2.4) : small ? 0.6 : PROPS[type].label ? 1 : 1;

      const made = [];
      for (let i = 0; i < count; i++) {
        const spot = this.editor.spotInFront(20 + i * 4);
        made.push(this.addObject({
          type,
          name: count > 1 ? PROPS[type].label + ' ' + (i + 1) : (giant ? 'Giant ' : small ? 'Small ' : '') + PROPS[type].label,
          x: spot.x + (i - (count - 1) / 2) * 7,
          z: spot.z,
          y: this.sampler.heightAt(spot.x + (i - (count - 1) / 2) * 7, spot.z),
          scale,
          rotation: Math.floor(Math.random() * 4) * 90
        }));
      }

      this.markChange();
      this.selectObject(made[0].id);
      this.setAI('Placed ' + made.length + ' ' + type + ' object(s) in front of the camera.');
      return 'Created ' + made.length + ' ' + (giant ? 'giant ' : '') + type +
        (made.length > 1 ? ' objects' : ' object') + '.';
    }

    /* 6 — bare type */
    const bare = detect(text);
    if (bare) {
      const spot = this.editor.spotInFront(20);
      const o = this.addObject({
        type: bare,
        x: spot.x, z: spot.z,
        y: this.sampler.heightAt(spot.x, spot.z)
      });
      this.markChange();
      this.selectObject(o.id);
      return 'Created one ' + bare + '.';
    }

    return 'I could not map that wish. Try: "create a giant castle", "create three enemies", ' +
      '"put the castle at the centre", "move the selected object behind the player".';
  }

  submitWish() {
    const raw = this.els.wishInput.value;
    if (!raw.trim()) {
      this.setActivity('Type a wish first — try "Create a giant castle".');
      return;
    }
    const result = this.interpretWish(raw);
    this.els.wishInput.value = '';
    this.setActivity(result);
    this.setStatus('Wish forged');
    if (this.plugins) this.plugins.emit('wish:processed', { text: raw, result });
    this.updateDebug();
  }

  /* -------------------------------------------------------- world generate */

  generateWorld(seed, toast) {
    const s = seed != null ? seed : (parseInt(this.els.worldSeed.value, 10) || this.seed);
    const relief = parseInt(this.els.worldRelief.value, 10) || this.relief;

    this.buildWorld(s, relief);

    /* Drop the old props and scatter a seeded population. */
    this.objects.forEach((o) => { if (o.mesh) this.objGroup.remove(o.mesh); });
    this.objects = [];
    this.nextId = 1;
    this.selectedId = null;
    this.renderInspector();

    const density = this.gameType === 'Open World' || this.gameType === 'Sandbox' ? 1.3 : 1;
    const specs = scatterWorld(this.sampler, this.seed, { density });

    specs.forEach((spec) => {
      this.objects.push({
        id: this.nextId++,
        type: spec.type,
        name: spec.name,
        x: spec.x, z: spec.z, y: spec.y,
        rotation: spec.rotation,
        scale: spec.scale
      });
    });

    this.publishWorld();
    this.resetHistory();

    this.els.worldSeed.value = this.seed;
    this.els.seedDisplay.textContent = String(this.seed);
    this.setStatus('World generated · seed ' + this.seed);
    this.setActivity('Seeded world: ' + this.objects.length + ' objects placed across ' +
      WORLD.size + ' × ' + WORLD.size + ' metres.');
    this.setAI('Seed ' + this.seed + ' resolved. Terrain, water, scatter and ' +
      this.objects.filter((o) => o.type === 'enemy' || o.type === 'boss').length +
      ' hostiles handed to the runtime.');

    if (this.plugins) this.plugins.emit('world:generated', { seed: this.seed, objects: this.objects.length });

    if (toast) this.toast('World generated · seed ' + this.seed);
  }

  /* ------------------------------------------------------------- project io */

  project() {
    return {
      app: 'StudioForge',
      version: 1,
      savedAt: new Date().toISOString(),
      game: {
        seed: this.seed,
        relief: this.relief,
        gameType: this.gameType,
        nextId: this.nextId,
        objects: this.objects.map((o) => ({
          id: o.id, type: o.type, name: o.name,
          x: o.x, y: o.y, z: o.z, rotation: o.rotation, scale: o.scale
        }))
      },
      film: this.film ? this.film.serialize() : null
    };
  }

  saveProject(silent) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.project()));
      if (!silent) {
        this.setStatus('Project saved');
        this.setActivity('Saved to this browser\u2019s local storage.');
        this.toast('Project saved');
        if (this.plugins) this.plugins.emit('project:saved', {});
      }
      return true;
    } catch (err) {
      this.setStatus('Save failed');
      this.setActivity('Local storage is unavailable here — use Export instead.');
      return false;
    }
  }

  restoreOrSeed() {
    let restored = false;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const d = JSON.parse(raw);
        const g = d.game || {};

        this.buildWorld(g.seed || 482917, g.relief || 32);
        this.gameType = g.gameType || 'FPS';
        this.els.gameType.value = this.gameType;
        this.els.worldSeed.value = this.seed;
        this.els.worldRelief.value = this.relief;

        this.objects = (g.objects || []).map((o) => ({
          id: o.id, type: o.type, name: o.name,
          x: o.x, y: o.y, z: o.z,
          rotation: o.rotation || 0, scale: o.scale != null ? o.scale : 1
        }));
        this.nextId = g.nextId || (this.objects.reduce((m, o) => Math.max(m, o.id), 0) + 1);
        this.publishWorld();

        if (d.film && this.film) this.film.deserialize(d.film);

        restored = true;
        this.setActivity('Project restored — ' + this.objects.length + ' objects, seed ' + this.seed + '.');
      }
    } catch (err) {
      restored = false;
    }

    if (!restored) {
      this.generateWorld(482917, false);
      this.setActivity('New project — seed 482917 is live. Generate a world or add objects.');
    }

    this.resetHistory();
  }

  loadProjectFile(data) {
    if (!data || typeof data !== 'object') throw new Error('Not a project file');

    const g = data.game || data;
    if (!Array.isArray(g.objects)) throw new Error('No objects in file');

    this.buildWorld(Number(g.seed) || 482917, Number(g.relief) || 32);
    this.gameType = g.gameType || this.gameType;
    this.els.gameType.value = this.gameType;
    this.els.worldSeed.value = this.seed;
    this.els.worldRelief.value = this.relief;

    this.objects.forEach((o) => { if (o.mesh) this.objGroup.remove(o.mesh); });
    this.objects = g.objects.map((o) => ({
      id: Number(o.id) || this.nextId++,
      type: PROPS[o.type] ? o.type : 'building',
      name: String(o.name || 'Object'),
      x: Number(o.x) || 0,
      y: Number(o.y) || 0,
      z: Number(o.z) || 0,
      rotation: Number(o.rotation) || 0,
      scale: clamp(Number(o.scale) || 1, 0.2, 6)
    }));
    this.nextId = Number(g.nextId) || (this.objects.reduce((m, o) => Math.max(m, o.id), 0) + 1);
    this.selectedId = null;

    this.publishWorld();
    if (data.film && this.film) this.film.deserialize(data.film);

    this.resetHistory();
    this.renderInspector();
  }

  exportProject() {
    const blob = new Blob([JSON.stringify(this.project(), null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'studioforge-project.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    this.setStatus('Exported');
    this.setActivity('Exported studioforge-project.json (game world + film storyboard).');
    this.toast('Project exported');
    if (this.plugins) this.plugins.emit('project:exported', {});
  }

  /* ------------------------------------------------------------------ mode */

  enterPlay() {
    if (this.mode === 'play') return;
    this.mode = 'play';
    this.els.playMode.classList.add('active');
    this.els.editMode.classList.remove('active');
    this.els.modeDisplay.textContent = 'PLAY';
    this.els.engineLabel.textContent = 'First-Person Runtime';
    this.els.playOverlay.classList.remove('hidden');
    this.player.enter();
    if (this.plugins) this.plugins.emit('mode:changed', { mode: 'play' });
    this.setStatus('Playing — click the viewport to lock the pointer');
  }

  exitPlay() {
    if (this.mode !== 'play') return;
    this.mode = 'edit';
    this.els.editMode.classList.add('active');
    this.els.playMode.classList.remove('active');
    this.els.modeDisplay.textContent = 'EDIT';
    this.els.engineLabel.textContent = 'StudioForge Runtime';
    this.player.exit();
    this.editor.target.set(0, 6, 0);
    if (this.plugins) this.plugins.emit('mode:changed', { mode: 'edit' });
    this.setStatus('Ready');
    this.setActivity('Back in edit mode.');
    this.setAI('Monitoring game state.');
  }

  switchWorkspace(name) {
    this.workspace = name;
    Array.prototype.forEach.call(
      document.querySelectorAll('.mode-tab[data-workspace]'),
      (b) => b.classList.toggle('active', b.dataset.workspace === name)
    );

    const film = document.getElementById('ws-film');
    const game = document.getElementById('ws-game');
    const design = document.getElementById('ws-design');
    if (film) film.hidden = name !== 'film';
    if (game) game.hidden = name !== 'game';
    if (design) design.hidden = name !== 'design';

    if (name === 'film') {
      if (this.mode === 'play') this.exitPlay();
      if (this.film) this.film.setRuntime('planner ready');
      this.setStatus('Film Maker');
    } else if (name === 'design') {
      if (this.mode === 'play') this.exitPlay();
      this.setStatus('Design Studio');
      if (this.designer) this.designer.setStatus(this.designer.assets.length
        ? this.designer.assets.length + ' assets ready — send them to the sandbox'
        : 'ready — describe what to create');
    } else {
      this.resize();
      this.setStatus('Ready');
    }
  }

  /* ------------------------------------------------- gameplay templates */

  /*
    "Modern Military Conquest" — stages an arid compound like the AAA
    reference: barriers, shacks, supply crates, an allied squad and a
    hostile patrol around the spawn plateau, under the golden-hour rig.
  */
  applyTemplateMilitary() {
    this.gameType = 'FPS';
    this.els.gameType.value = 'FPS';

    const seed = Math.floor(Math.random() * 900000) + 100000;
    this.els.worldSeed.value = String(seed);
    this.els.worldRelief.value = '18';
    this.generateWorld(seed, false);

    const put = (type, name, x, z, scale, rot) => {
      this.addObject({
        type, name,
        x, z,
        y: this.sampler.heightAt(x, z),
        rotation: rot || 0,
        scale: scale || 1
      });
    };

    /* Perimeter barriers (rocks read as concrete blocks at this scale). */
    put('rock', 'Barrier North', 0, -26, 1.5, 12);
    put('rock', 'Barrier East', 26, 4, 1.4, 78);
    put('rock', 'Barrier West', -26, 2, 1.4, 31);

    /* Shacks + a watch structure around the compound. */
    put('building', 'Outpost Shack A', -18, -18, 0.7, 15);
    put('building', 'Outpost Shack B', 20, -14, 0.65, -20);
    put('building', 'Watch Post', 2, -44, 0.9, 0);

    /* Supply crates (loot props double as interactable crates). */
    put('loot', 'Supply Crate 1', -8, -10, 1.1, 24);
    put('loot', 'Supply Crate 2', -6, -7, 0.9, 62);
    put('loot', 'Ammo Cache', 12, 14, 1, 8);

    /* Allied squad + hostile patrol. */
    put('npc', 'Squadmate Vega', -5, 8, 1, 180);
    put('npc', 'Squadmate Idris', 6, 10, 1, 200);
    put('enemy', 'Hostile Patrol 1', 30, -34, 1, 0);
    put('enemy', 'Hostile Patrol 2', 44, -22, 1, 0);
    put('enemy', 'Hostile Patrol 3', -42, -30, 1, 0);

    this.markChange();
    this.setAI('Modern Military Conquest template staged — golden-hour rig, ' +
      'compound props, allied squad and a three-man hostile patrol.');
    this.setActivity('Template applied — press ▶ Play to run the compound.');
    this.toast('🎯 Military Conquest template staged');
  }

  /* -------------------------------------------------------------- bindings */

  bindUI() {
    const e = this.els;

    Array.prototype.forEach.call(
      document.querySelectorAll('.mode-tab[data-workspace]'),
      (b) => b.addEventListener('click', () => this.switchWorkspace(b.dataset.workspace))
    );

    e.undoBtn.addEventListener('click', () => this.undo());
    e.redoBtn.addEventListener('click', () => this.redo());
    e.saveBtn.addEventListener('click', () => this.saveProject(false));
    e.exportBtn.addEventListener('click', () => this.exportProject());

    e.importInput.addEventListener('change', (ev) => {
      const file = ev.target.files && ev.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          this.loadProjectFile(JSON.parse(String(reader.result)));
          this.setStatus('Imported');
          this.setActivity('Imported ' + file.name + ' — ' + this.objects.length + ' objects.');
          this.toast('Project imported');
        } catch (err) {
          this.setStatus('Import failed');
          this.setActivity('That file is not a valid StudioForge project JSON.');
        }
        e.importInput.value = '';
      };
      reader.onerror = () => {
        this.setStatus('Import failed');
        this.setActivity('The file could not be read.');
        e.importInput.value = '';
      };
      reader.readAsText(file);
    });

    Array.prototype.forEach.call(
      document.querySelectorAll('.menu[data-panel]'),
      (b) => b.addEventListener('click', () => this.applyPanel(b.dataset.panel))
    );

    Array.prototype.forEach.call(
      document.querySelectorAll('.add-object[data-type]'),
      (btn) => btn.addEventListener('click', () => {
        const type = btn.dataset.type;
        const spot = this.editor.spotInFront(20);
        const o = this.addObject({
          type,
          x: spot.x, z: spot.z,
          y: this.sampler.heightAt(spot.x, spot.z),
          rotation: Math.floor(Math.random() * 4) * 90
        });
        this.markChange();
        this.selectObject(o.id);
        this.setActivity('Added ' + o.name + ' at X ' + o.x + ', Z ' + o.z + '.');
      })
    );

    Array.prototype.forEach.call(
      document.querySelectorAll('.quick-wish'),
      (btn) => btn.addEventListener('click', () => {
        e.wishInput.value = btn.textContent.trim();
        this.submitWish();
      })
    );

    e.editMode.addEventListener('click', () => this.exitPlay());
    e.playMode.addEventListener('click', () => this.enterPlay());

    e.wishButton.addEventListener('click', () => this.submitWish());
    e.wishInput.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter') { ev.preventDefault(); this.submitWish(); }
    });

    e.generateWorld.addEventListener('click', () => {
      const seed = parseInt(e.worldSeed.value, 10);
      this.generateWorld(isNaN(seed) ? Math.floor(Math.random() * 900000) + 100000 : seed, true);
    });

    e.worldSeed.addEventListener('change', () => {
      const v = parseInt(e.worldSeed.value, 10);
      if (!isNaN(v)) {
        this.setActivity('Seed set to ' + v + ' — press Generate World to rebuild.');
      }
    });

    e.worldRelief.addEventListener('change', () => {
      const r = parseInt(e.worldRelief.value, 10);
      if (isNaN(r)) return;
      this.relief = clamp(r, 6, 80);
      this.buildWorld(this.seed, this.relief);
      this.objects.forEach((o) => {
        o.y = round2(this.sampler.heightAt(o.x, o.z));
        this.applyObjectTransform(o);
      });
      this.setActivity('Terrain relief set to ' + this.relief + '. Heights resampled.');
      this.toast('Terrain relief updated');
    });

    e.gameType.addEventListener('change', () => {
      this.gameType = e.gameType.value;
      this.setActivity('Game type set to ' + this.gameType + '.');
      this.setAI(this.gameType + ' profile loaded — scatter density and pacing adjusted.');
    });

    /* inspector */
    e.objectName.addEventListener('input', () => {
      const o = this.selected();
      if (o) { o.name = e.objectName.value; }
    });
    e.objectName.addEventListener('change', () => { this.markChange(); this.updateDebug(); });

    const wireNumber = (input, key, lo, hi) => {
      input.addEventListener('input', () => {
        const o = this.selected();
        if (!o) return;
        const v = parseFloat(input.value);
        if (isNaN(v)) return;
        o[key] = clamp(v, lo, hi);
        this.applyObjectTransform(o);
      });
      input.addEventListener('change', () => {
        const o = this.selected();
        if (!o) return;
        const v = parseFloat(input.value);
        if (isNaN(v)) { this.syncInspectorValues(); return; }
        o[key] = clamp(v, lo, hi);
        input.value = o[key];
        this.applyObjectTransform(o);
        this.markChange();
      });
    };

    wireNumber(e.objectX, 'x', -290, 290);
    wireNumber(e.objectZ, 'z', -290, 290);
    wireNumber(e.objectY, 'y', -30, 240);
    wireNumber(e.objectRotation, 'rotation', -360, 360);
    wireNumber(e.objectScale, 'scale', 0.2, 6);

    e.duplicateObject.addEventListener('click', () => {
      const o = this.selected();
      if (!o) return;
      const copy = this.addObject({
        type: o.type,
        name: o.name + ' Copy',
        x: o.x + 6, z: o.z + 6,
        y: this.sampler.heightAt(o.x + 6, o.z + 6),
        rotation: o.rotation,
        scale: o.scale
      });
      this.markChange();
      this.selectObject(copy.id);
      this.setActivity('Duplicated ' + o.name + '.');
    });

    e.deleteObject.addEventListener('click', () => {
      const o = this.selected();
      if (!o) return;
      const name = o.name;
      this.removeObject(o.id, { silent: true });
      this.markChange();
      this.setActivity('Deleted ' + name + '.');
    });

    /* play overlay */
    e.playOverlay.addEventListener('click', () => {
      if (this.mode === 'play') this.player.lock();
    });

    /* global keys */
    window.addEventListener('keydown', (ev) => {
      const typing = /INPUT|SELECT|TEXTAREA/.test(
        document.activeElement ? document.activeElement.tagName : ''
      );

      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'z') {
        ev.preventDefault();
        if (ev.shiftKey) this.redo(); else this.undo();
        return;
      }
      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 'y') {
        ev.preventDefault(); this.redo(); return;
      }
      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 's') {
        ev.preventDefault(); this.saveProject(false); return;
      }

      if (typing) return;

      if (ev.key === 'Escape' && this.mode === 'play') {
        this.exitPlay();
        return;
      }

      if (ev.key === 'Tab') {
        ev.preventDefault();
        if (this.mode === 'play') this.exitPlay(); else this.enterPlay();
        return;
      }

      if ((ev.key === 'Delete' || ev.key === 'Backspace') && this.selectedId != null) {
        ev.preventDefault();
        e.deleteObject.click();
      }
    });

    const t = document.getElementById('templateMilitary');
    if (t) t.addEventListener('click', () => this.applyTemplateMilitary());

    /* Plugin manager */
    const pluginsBtn = document.getElementById('pluginsBtn');
    if (pluginsBtn) pluginsBtn.addEventListener('click', () => this.plugins.showModal());
    const pluginsClose = document.getElementById('pluginsClose');
    if (pluginsClose) pluginsClose.addEventListener('click', () => this.plugins.hideModal());
    const pluginsOv = document.getElementById('pluginsOverlay');
    if (pluginsOv) pluginsOv.addEventListener('click', (ev) => {
      if (ev.target === pluginsOv) this.plugins.hideModal();
    });

    /* PWA */
    let installEvent = null;
    window.addEventListener('beforeinstallprompt', (ev) => {
      ev.preventDefault();
      installEvent = ev;
      e.installBtn.classList.remove('hidden');
    });
    e.installBtn.addEventListener('click', () => {
      if (!installEvent) return;
      installEvent.prompt();
      installEvent.userChoice.then(() => {
        installEvent = null;
        e.installBtn.classList.add('hidden');
      });
    });
    window.addEventListener('appinstalled', () => {
      e.installBtn.classList.add('hidden');
      this.toast('StudioForge installed — it now opens like a native app.');
    });

    if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js').catch(() => {});
      });
    }
  }

  /* ------------------------------------------------------------- the loop */

  loop() {
    let last = performance.now();

    const frame = (now) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      this._frames++;
      this._fpsT += dt;
      if (this._fpsT >= 0.5) {
        this.fps = this._frames / this._fpsT;
        this._frames = 0;
        this._fpsT = 0;
        if (this.els.renderStats) {
          const info = this.renderer.info;
          this.els.renderStats.textContent =
            Math.round(this.fps) + ' FPS · ' + info.render.calls + ' draw calls · ' +
            info.render.triangles.toLocaleString() + ' triangles · ' +
            this.objects.length + ' objects';
        }
      }

      /* Film playback is advanced by the same clock, so only one rAF exists. */
      if (this.workspace === 'film' && this.film) {
        this.film.tick(dt);
      } else {
        if (this.mode === 'play') this.player.tick(dt);
        else this.editor.update();

        /* Idle animation for collectibles + swaying hostiles. */
        this.objects.forEach((o) => {
          if (!o.mesh) return;
          if (o.type === 'loot' && o.mesh.rotation) {
            o.mesh.rotation.y += dt * 1.1;
          }
          if (o.type === 'npc') {
            o.mesh.position.y = o.y + Math.sin(now / 700 + o.id) * 0.06;
          }
        });

        /* Keep the selection box glued to the object while it is dragged. */
        if (this.selHelper && this.selHelper.visible) {
          const so = this.selected();
          if (so && so.mesh) this.selHelper.setFromObject(so.mesh);
        }

        /* Cinematic chain: bloom + ACES output instead of a raw blit. */
        if (this.composer) this.composer.render();
        else this.renderer.render(this.scene, this.camera);
      }

      requestAnimationFrame(frame);
    };

    requestAnimationFrame(frame);
  }
}

/* --------------------------------------------------------------- helpers */

function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }
function round2(v) { return Math.round((Number(v) || 0) * 100) / 100; }

/* Visible failure instead of a silent blank canvas. */
try {
  window.STUDIOFORGE = new StudioForge();
} catch (err) {
  const vp = document.getElementById('gameViewport');
  if (vp) {
    vp.innerHTML =
      '<div style="padding:28px;color:#ff9aa5;font:13px/1.7 ui-monospace,monospace">' +
      'StudioForge failed to start.<br>' +
      'Serve this folder over http:// (not file://) so the ES modules can load.<br><br>' +
      String(err && err.message ? err.message : err) +
      '</div>';
  }
  throw err;
}
