/* ==========================================================================
   StudioForge — designer.js
   The 🎨 Design workspace: a vibe-coding game design assistant.

   Request → parse → generate → apply → archive → publish.

   HONESTY NOTE: the art is REAL generated raster art — every asset is a
   canvas-rendered PNG data URL with metadata (kind, style, genre, palette,
   seed), not a placeholder box. It is procedural/canvas art, not
   photoscanned or model-generated imagery. Scenes and objects are real
   project data written straight into the live game preview.
   ========================================================================== */

import { mulberry32 } from './noise.js';

/* ------------------------------------------------------------ palettes */

const PALETTES = {
  crimson:  ['#8f1d1d', '#d4452e', '#f2a65a', '#2b0d0d', '#f5e6c8'],
  azure:    ['#1d3a8f', '#2e7fd4', '#5ac8f2', '#0d1b2b', '#e6f2ff'],
  emerald:  ['#1d8f4e', '#2ed47a', '#a5f2c0', '#0d2b1b', '#e6fff0'],
  gold:     ['#b8860b', '#f2c14e', '#ffe9a8', '#2b1f0d', '#fff7e0'],
  violet:   ['#5b1d8f', '#9a4de0', '#d9a8f2', '#1b0d2b', '#f2e6ff'],
  neon:     ['#ff2d95', '#00f0ff', '#ffe600', '#12002b', '#eafcff'],
  pastel:   ['#f2a6c8', '#a6d9f2', '#fff3b8', '#3a3a4a', '#ffffff'],
  ember:    ['#5a1a00', '#e05a10', '#ffc46b', '#1a0a00', '#ffeedd'],
  frost:    ['#7ab8d4', '#c8ecff', '#ffffff', '#16303f', '#e8f7ff'],
  toxic:    ['#5a8f00', '#9fe018', '#d9ff6b', '#1f2b0d', '#f2ffd0']
};

const COLOR_WORDS = [
  [/crimson|red|blood/i, 'crimson'], [/azure|blue|sapphire/i, 'azure'],
  [/emerald|green|jade|forest/i, 'emerald'], [/gold|amber|sand|desert/i, 'gold'],
  [/violet|purple|arcane/i, 'violet'], [/neon|cyber|synth/i, 'neon'],
  [/pastel|candy|soft/i, 'pastel'], [/ember|lava|volcan|magma/i, 'ember'],
  [/frost|ice|snow|arctic/i, 'frost'], [/toxic|acid|swamp|slime/i, 'toxic']
];

const NUMBER_WORDS = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10 };

const MOODS = [
  [/dark|grim|night|gothic|horror/i, 'dark'], [/bright|cheer|sunny|heroic/i, 'bright'],
  [/neon|cyber|synth/i, 'neon'], [/mystic|rune|arcane|elder/i, 'mystic']
];

/* ------------------------------------------------------------- helpers */

function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function canvas2d(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return { c, x: c.getContext('2d') };
}

function shade(hex, f) {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.max(0, Math.min(255, ((n >> 16) & 255) * f));
  const g = Math.max(0, Math.min(255, ((n >> 8) & 255) * f));
  const b = Math.max(0, Math.min(255, (n & 255) * f));
  return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
}

/* Value-noise terrain fill for texture tiles. */
function noiseTile(x2, size, rng, base, contrast) {
  const img = x2.createImageData(size, size);
  const grid = 8;
  const g = [];
  for (let i = 0; i < (grid + 1) * (grid + 1); i++) g.push(rng());
  const val = (gx, gy) => {
    const fx = gx / size * grid, fy = gy / size * grid;
    const x0 = Math.floor(fx), y0 = Math.floor(fy);
    const tx = fx - x0, ty = fy - y0;
    const s = (a, b) => g[(b % grid + 1) * (grid + 1) + (a % grid + 1)] || 0;
    const a = s(x0, y0), b = s(x0 + 1, y0), c2 = s(x0, y0 + 1), d = s(x0 + 1, y0 + 1);
    const u = tx * tx * (3 - 2 * tx), v = ty * ty * (3 - 2 * ty);
    return a * (1 - u) * (1 - v) + b * u * (1 - v) + c2 * (1 - u) * v + d * u * v;
  };
  for (let gy = 0; gy < size; gy++) {
    for (let gx = 0; gx < size; gx++) {
      const n = (val(gx, gy) - 0.5) * (contrast || 1.6) + 0.5;
      const col = shade(base, 0.55 + n * 0.8);
      const m = col.match(/\d+/g);
      const i = (gy * size + gx) * 4;
      img.data[i] = +m[0]; img.data[i + 1] = +m[1]; img.data[i + 2] = +m[2]; img.data[i + 3] = 255;
    }
  }
  x2.putImageData(img, 0, 0);
}

/* ------------------------------------------------- art (real PNG output) */

function artCharacter(rng, pal, mood) {
  const { c, x: g } = canvas2d(64, 64);
  const skin = ['#e8b88a', '#c98a5a', '#8a5a3a', '#d4a98a'][Math.floor(rng() * 4)];
  const suit = pal[Math.floor(rng() * 3)];
  const dark = pal[3];
  g.fillStyle = dark; g.fillRect(0, 0, 64, 64);
  const cx = 32;
  /* cape / silhouette */
  if (rng() > 0.5) {
    g.fillStyle = shade(suit, 0.7);
    g.beginPath(); g.moveTo(cx - 6, 18); g.lineTo(cx - 17, 52); g.lineTo(cx + 17, 52); g.lineTo(cx + 6, 18); g.fill();
  }
  /* legs */
  g.fillStyle = shade(suit, 0.8);
  g.fillRect(cx - 7, 40, 5, 16); g.fillRect(cx + 2, 40, 5, 16);
  /* torso */
  g.fillStyle = suit; g.fillRect(cx - 8, 24, 16, 18);
  /* emblem */
  g.fillStyle = pal[1];
  g.fillRect(cx - 3, 28, 6, 6);
  /* arms */
  g.fillStyle = shade(suit, 0.9);
  g.fillRect(cx - 12, 25, 4, 14); g.fillRect(cx + 8, 25, 4, 14);
  /* head */
  g.fillStyle = mood === 'dark' ? dark : skin;
  g.fillRect(cx - 6, 10, 12, 12);
  /* mask / visor */
  g.fillStyle = pal[1];
  g.fillRect(cx - 6, 14, 12, 3);
  /* helm crest */
  if (rng() > 0.6) { g.fillStyle = pal[0]; g.fillRect(cx - 1, 6, 2, 5); }
  return c.toDataURL('image/png');
}

function artProp(rng, pal, kind) {
  const { c, x: g } = canvas2d(64, 64);
  g.fillStyle = pal[3]; g.fillRect(0, 0, 64, 64);
  const a = pal[0], b = pal[1], hi = pal[2];
  if (kind === 'weapon') {
    g.fillStyle = '#b8c4d4'; g.fillRect(30, 8, 4, 34);
    g.fillStyle = hi; g.fillRect(28, 6, 8, 4);
    g.fillStyle = shade(a, 1); g.fillRect(24, 42, 16, 5);
    g.fillStyle = shade(b, 1); g.fillRect(29, 47, 6, 10);
  } else if (kind === 'crystal') {
    g.fillStyle = b;
    g.beginPath(); g.moveTo(32, 8); g.lineTo(46, 34); g.lineTo(32, 56); g.lineTo(18, 34); g.fill();
    g.fillStyle = hi;
    g.beginPath(); g.moveTo(32, 8); g.lineTo(46, 34); g.lineTo(32, 34); g.fill();
    g.fillStyle = a; g.fillRect(24, 40, 16, 6);
  } else if (kind === 'potion') {
    g.fillStyle = '#d4dce8'; g.fillRect(26, 20, 12, 30);
    g.fillStyle = b; g.fillRect(27, 30, 10, 19);
    g.fillStyle = shade(a, 1); g.fillRect(24, 14, 16, 7);
    g.fillStyle = hi; g.fillRect(28, 34, 3, 8);
  } else if (kind === 'coin') {
    g.fillStyle = b; g.beginPath(); g.arc(32, 34, 16, 0, 7); g.fill();
    g.fillStyle = hi; g.beginPath(); g.arc(32, 34, 11, 0, 7); g.fill();
    g.fillStyle = a; g.fillRect(29, 26, 6, 16);
  } else { /* reliquary / chest */
    g.fillStyle = shade(a, 1); g.fillRect(12, 26, 40, 26);
    g.fillStyle = b; g.fillRect(12, 18, 40, 10);
    g.fillStyle = '#d4b04a'; g.fillRect(29, 30, 6, 10);
    g.fillStyle = hi; g.fillRect(14, 20, 36, 3);
  }
  return c.toDataURL('image/png');
}

function artTexture(rng, pal, base) {
  const { c, x: g } = canvas2d(128, 128);
  noiseTile(g, 128, rng, base || pal[0], 1.7);
  /* overlay flecks */
  for (let i = 0; i < 40; i++) {
    g.fillStyle = i % 2 ? pal[1] : pal[2];
    g.globalAlpha = 0.25;
    g.fillRect(Math.floor(rng() * 128), Math.floor(rng() * 128), 2 + rng() * 3, 2 + rng() * 3);
  }
  g.globalAlpha = 1;
  return c.toDataURL('image/png');
}

function artSceneCard(rng, pal, name) {
  const { c, x: g } = canvas2d(256, 144);
  /* sky gradient */
  const sky = g.createLinearGradient(0, 0, 0, 144);
  sky.addColorStop(0, pal[4]); sky.addColorStop(1, pal[1]);
  g.fillStyle = sky; g.fillRect(0, 0, 256, 144);
  /* stars / sun */
  if (rng() > 0.5) {
    g.fillStyle = '#ffffff';
    for (let i = 0; i < 26; i++) g.fillRect(rng() * 256, rng() * 70, 1.6, 1.6);
  }
  g.fillStyle = pal[2];
  g.beginPath(); g.arc(200, 36, 17, 0, 7); g.fill();
  /* mountain layers */
  const layer = (yBase, col) => {
    g.fillStyle = col; g.beginPath(); g.moveTo(0, 144);
    let y = yBase;
    for (let px = 0; px <= 256; px += 32) {
      g.lineTo(px, y);
      y = Math.max(30, Math.min(120, y + (rng() - 0.5) * 46));
    }
    g.lineTo(256, 144); g.fill();
  };
  layer(66, shade(pal[0], 0.75));
  layer(88, shade(pal[0], 0.95));
  layer(106, shade(pal[3], 1.35));
  /* water band */
  g.fillStyle = shade(pal[1], 0.85); g.fillRect(0, 118, 256, 26);
  g.fillStyle = 'rgba(255,255,255,0.35)';
  for (let i = 0; i < 8; i++) g.fillRect(rng() * 240, 122 + rng() * 18, 10 + rng() * 12, 1.6);
  /* name plate */
  g.fillStyle = 'rgba(0,0,0,0.55)'; g.fillRect(0, 0, 256, 20);
  g.fillStyle = pal[4]; g.font = 'bold 11px monospace';
  g.fillText(String(name).slice(0, 34), 8, 14);
  return c.toDataURL('image/png');
}

function artVfx(rng, pal) {
  const { c, x: g } = canvas2d(64, 64);
  g.clearRect(0, 0, 64, 64);
  const glow = g.createRadialGradient(32, 32, 2, 32, 32, 30);
  glow.addColorStop(0, pal[2]); glow.addColorStop(0.5, pal[1]); glow.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = glow; g.fillRect(0, 0, 64, 64);
  g.strokeStyle = pal[0]; g.lineWidth = 2;
  const spokes = 5 + Math.floor(rng() * 4);
  for (let i = 0; i < spokes; i++) {
    const a = (i / spokes) * Math.PI * 2 + rng();
    g.beginPath(); g.moveTo(32, 32);
    g.lineTo(32 + Math.cos(a) * (14 + rng() * 14), 32 + Math.sin(a) * (14 + rng() * 14));
    g.stroke();
  }
  return c.toDataURL('image/png');
}

function artAudio(rng, pal) {
  const { c, x: g } = canvas2d(128, 64);
  g.fillStyle = pal[3]; g.fillRect(0, 0, 128, 64);
  g.fillStyle = pal[4]; g.font = '9px monospace'; g.fillText('AUDIO STEM', 8, 12);
  for (let i = 0; i < 32; i++) {
    const h = 4 + rng() * 36;
    g.fillStyle = i % 3 ? pal[1] : pal[2];
    g.fillRect(6 + i * 3.7, 54 - h, 2.6, h);
  }
  return c.toDataURL('image/png');
}

/* ------------------------------------------------------ request parsing */

const KINDS = [
  [/character|hero|villain|npc|enemy|crew|cast|avatar/i, 'character'],
  [/texture|terrain|material|tile|ground|surface/i, 'texture'],
  [/vfx|effect|spell|glyph|rune|fx/i, 'vfx'],
  [/audio|sound|music|sfx|stem/i, 'audio'],
  [/prop|item|weapon|loot|potion|coin|crate|relic/i, 'prop'],
  [/scene|environment|level|biome|world|map|arena/i, 'scene']
];

export class DesignAssistant {
  constructor(api) {
    this.api = api;
    this.assets = [];
    this.scenes = [];
    this.seq = 1;
    this.ARCHIVE_KEY = 'studioforge.designs.v1';
    this.els = {};
    this.bind();
    this.setStatus('ready — describe what to create');
  }

  /* ----------------------------------------------------------- plumbing */

  setStatus(s) {
    const el = document.getElementById('designStatus');
    if (el) el.textContent = s;
  }

  bind() {
    const $ = (id) => document.getElementById(id);
    this.els = {
      prompt: $('designPrompt'), type: $('designType'), genre: $('designGenre'),
      style: $('designStyle'), results: $('designResults'), archive: $('designArchive')
    };

    const gen = $('designGenerateBtn');
    if (gen) gen.addEventListener('click', () => this.generate());
    if (this.els.prompt) {
      this.els.prompt.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter' && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); this.generate(); }
      });
    }

    const sendAll = $('designSendAllBtn');
    if (sendAll) sendAll.addEventListener('click', () => this.sendAllToSandbox());
    const save = $('designSaveBtn');
    if (save) save.addEventListener('click', () => this.saveToArchive());
    const publish = $('designPublishBtn');
    if (publish) publish.addEventListener('click', () => this.publishBundle());

    Array.prototype.forEach.call(document.querySelectorAll('.quick-design'), (b) => {
      b.addEventListener('click', () => {
        if (this.els.prompt) this.els.prompt.value = b.textContent.trim();
        this.generate();
      });
    });

    /* delegated clicks on result cards and archive rows */
    if (this.els.results) {
      this.els.results.addEventListener('click', (ev) => {
        const btn = ev.target.closest('[data-send]');
        if (btn) this.sendToSandbox(btn.dataset.send);
      });
    }
    if (this.els.archive) {
      this.els.archive.addEventListener('click', (ev) => {
        const btn = ev.target.closest('[data-act]');
        if (!btn) return;
        const id = btn.dataset.id;
        if (btn.dataset.act === 'load') this.loadFromArchive(id);
        if (btn.dataset.act === 'send') this.sendArchiveToSandbox(id);
        if (btn.dataset.act === 'del') this.deleteArchive(id);
        if (btn.dataset.act === 'exp') this.exportArchive(id);
      });
    }
  }

  parse(text, kindSel, genreSel, styleSel) {
    const t = ' ' + text + ' ';
    let kind = 'character';
    if (kindSel && kindSel !== 'Auto (from prompt)') {
      kind = { Characters: 'character', 'Props & Items': 'prop', Textures: 'texture',
        'Global Scenes': 'scene', 'VFX & Glyphs': 'vfx', 'Audio Cards': 'audio' }[kindSel] || 'character';
    } else {
      for (const [re, k] of KINDS) { if (re.test(t)) { kind = k; break; } }
    }
    let count = 4;
    const num = t.match(/\b(\d{1,2})\b/);
    if (num) count = Math.max(1, Math.min(12, +num[1]));
    else {
      for (const [w, n] of Object.entries(NUMBER_WORDS)) {
        if (new RegExp('\\b' + w + '\\b', 'i').test(t)) { count = n; break; }
      }
    }
    let palette = null;
    for (const [re, p] of COLOR_WORDS) { if (re.test(t)) { palette = p; break; } }
    const mood = (MOODS.find(([re]) => re.test(t)) || [null, 'neutral'])[1];
    return {
      kind, count, palette,
      genre: genreSel || 'Any',
      style: styleSel || 'Any',
      mood,
      text: String(text || '').trim()
    };
  }

  /* ----------------------------------------------------------- generate */

  generate() {
    const req = this.parse(
      this.els.prompt ? this.els.prompt.value : '',
      this.els.type ? this.els.type.value : '',
      this.els.genre ? this.els.genre.value : '',
      this.els.style ? this.els.style.value : ''
    );
    if (!req.text) { this.api.toast('Describe what to create first.'); return; }

    const palName = req.palette || Object.keys(PALETTES)[Math.floor(Math.random() * 10)];
    const pal = PALETTES[palName];
    const seed = Math.floor(Math.random() * 900000) + 100000;
    const rng = mulberry32(seed);
    const stamp = new Date().toISOString();

    const made = [];
    const mk = (kind, name, desc, url, extra) => {
      made.push({
        id: 'd' + (this.seq++) + '_' + Date.now(),
        kind, name, desc, url,
        style: req.style, genre: req.genre, palette: palName, seed, createdAt: stamp,
        meta: extra || {}
      });
    };

    if (req.kind === 'scene') {
      const n = Math.max(1, Math.min(4, req.count));
      for (let i = 0; i < n; i++) {
        const name = req.style !== 'Any' ? req.style + ' ' : '';
        const sceneName = (name + palName + ' ' + ['Expanse', 'Basin', 'Reach', 'Verge'][i % 4] + ' — Scene ' + (i + 1));
        const url = artSceneCard(rng, pal, sceneName);
        const scene = {
          id: 'sc' + (this.seq++) + '_' + Date.now(),
          name: sceneName, url,
          seed: Math.floor(rng() * 900000) + 100000,
          relief: 18 + Math.floor(rng() * 40),
          palette: palName,
          objects: this.sceneObjects(rng, req),
          desc: 'Global scene · seed ' + 0 + ' · generated for "' + req.text.slice(0, 60) + '"'
        };
        scene.desc = 'Global scene · ' + scene.objects.length + ' staged objects · ' + req.text.slice(0, 60);
        this.scenes.push(scene);
        made.push({
          id: scene.id, kind: 'scene', name: scene.name, desc: scene.desc, url,
          style: req.style, genre: req.genre, palette: palName, seed, createdAt: stamp, meta: { scene }
        });
      }
    } else {
      for (let i = 0; i < req.count; i++) {
        if (req.kind === 'character') {
          const roles = ['Vanguard', 'Warden', 'Skirmisher', 'Oracle', 'Revenant', 'Drifter'];
          const nm = palName.charAt(0).toUpperCase() + palName.slice(1) + ' ' + roles[Math.floor(rng() * roles.length)] + ' ' + (i + 1);
          mk('character', nm, 'Character sprite · ' + req.mood + ' mood · ' + req.text.slice(0, 50),
            artCharacter(rng, pal, req.mood), { hp: 80 + Math.floor(rng() * 60), atk: 8 + Math.floor(rng() * 18) });
        } else if (req.kind === 'texture') {
          const tiles = ['Ground', 'Cliff', 'Plate', 'Moss', 'Ash', 'Crystal Strata'];
          const nm = palName.charAt(0).toUpperCase() + palName.slice(1) + ' ' + tiles[Math.floor(rng() * tiles.length)] + ' Tile ' + (i + 1);
          mk('texture', nm, 'Seamless terrain texture · 128×128 · palette ' + palName,
            artTexture(rng, pal, pal[0]), { tiling: 'seamless', size: '128x128' });
        } else if (req.kind === 'vfx') {
          mk('vfx', 'Glyph FX ' + (i + 1), 'VFX glyph · additive glow · palette ' + palName,
            artVfx(rng, pal), { blend: 'additive' });
        } else if (req.kind === 'audio') {
          mk('audio', 'Stem ' + (i + 1) + ' · ' + req.mood, 'Audio card placeholder art for an ' + req.mood + ' stem (no audio file generated)',
            artAudio(rng, pal), { format: 'card' });
        } else {
          const props = ['weapon', 'crystal', 'potion', 'coin', 'chest'];
          const pk = props[Math.floor(rng() * props.length)];
          const names = { weapon: 'Relic Blade', crystal: 'Attunement Crystal', potion: 'Elixir', coin: 'Gilded Coin', chest: 'Reliquary' };
          mk('prop', names[pk] + ' ' + (i + 1), 'Prop item · ' + pk + ' · ' + req.text.slice(0, 50),
            artProp(rng, pal, pk), { rarity: ['common', 'rare', 'epic'][Math.floor(rng() * 3)] });
        }
      }
    }

    this.assets = made;
    this.renderResults();
    const scenesN = made.filter((a) => a.kind === 'scene').length;
    this.setStatus('forged ' + made.length + ' assets (' +
      made.filter((a) => a.kind !== 'scene').length + ' art assets' + (scenesN ? ', ' + scenesN + ' global scenes' : '') + ') · seed ' + seed);
    this.api.toast('⚡ Forged ' + made.length + ' assets');
  }

  sceneObjects(rng, req) {
    const types = ['tree', 'rock', 'building', 'enemy', 'loot', 'npc'];
    const n = 3 + Math.floor(rng() * 8);
    const out = [];
    for (let i = 0; i < n; i++) {
      const type = types[Math.floor(rng() * types.length)];
      out.push({
        type,
        name: type.charAt(0).toUpperCase() + type.slice(1) + ' ' + (i + 1),
        scale: Math.round((0.7 + rng() * 1.8) * 100) / 100,
        x: Math.round((rng() * 2 - 1) * 220),
        z: Math.round((rng() * 2 - 1) * 220)
      });
    }
    return out;
  }

  /* ------------------------------------------------------ apply to game */

  sendToSandbox(key) {
    const [kind, idx] = key.split(':');
    const list = this.assets.filter((a) => a.kind === kind);
    const asset = list[+idx];
    if (!asset) return;
    if (kind === 'scene' && asset.meta && asset.meta.scene) {
      this.applyScene(asset.meta.scene);
      return;
    }
    const app = this.api.app;
    const spot = app.editor.spotInFront(18 + Math.random() * 14);
    const typeMap = { character: 'npc', prop: 'loot', texture: 'rock', vfx: 'loot', audio: 'loot' };
    const o = app.addObject({
      type: typeMap[asset.kind] || 'loot',
      name: asset.name,
      x: spot.x, z: spot.z,
      y: app.sampler.heightAt(spot.x, spot.z),
      rotation: Math.floor(Math.random() * 4) * 90,
      scale: 1,
      stats: asset.meta && asset.meta.hp ? { hp: asset.meta.hp } : null
    });
    this.api.app.markChange ? this.api.app.markChange() : null;
    this.api.toast('Sent "' + asset.name + '" to sandbox (' + o.name + ')');
    this.setStatus('sent ' + asset.name + ' → sandbox object ' + o.type);
  }

  applyScene(scene) {
    const app = this.api.app;
    const seedInput = document.getElementById('worldSeed');
    const reliefInput = document.getElementById('worldRelief');
    if (seedInput) seedInput.value = scene.seed;
    if (reliefInput) reliefInput.value = scene.relief;
    app.generateWorld(scene.seed, false);
    let placed = 0;
    scene.objects.forEach((so) => {
      app.addObject({
        type: so.type, name: so.name,
        x: so.x, z: so.z,
        y: app.sampler.heightAt(so.x, so.z),
        rotation: 0, scale: so.scale
      });
      placed++;
    });
    app.markChange();
    this.api.toast('Scene "' + scene.name + '" applied — world ' + scene.seed + ', ' + placed + ' objects');
    this.setStatus('scene applied · seed ' + scene.seed + ' · ' + placed + ' objects staged');
  }

  sendAllToSandbox() {
    if (!this.assets.length) { this.api.toast('Nothing to send — generate assets first.'); return; }
    let sent = 0;
    this.assets.forEach((a, i) => {
      if (a.kind === 'scene' && a.meta && a.meta.scene) { this.applyScene(a.meta.scene); }
      else { this.sendToSandbox(a.kind + ':' + this.assets.filter((x) => x.kind === a.kind).indexOf(a)); }
      sent++;
    });
    this.setStatus('sent ' + sent + ' items to the sandbox');
  }

  /* ------------------------------------------------------------ archive */

  readArchive() {
    try { return JSON.parse(localStorage.getItem(this.ARCHIVE_KEY) || '[]'); }
    catch (e) { return []; }
  }

  writeArchive(list) { localStorage.setItem(this.ARCHIVE_KEY, JSON.stringify(list)); }

  saveToArchive() {
    if (!this.assets.length) { this.api.toast('Nothing to archive — generate assets first.'); return; }
    const entry = {
      id: 'ar_' + Date.now(),
      name: (this.assets[0].name.split(' ').slice(0, 3).join(' ')) + ' set',
      savedAt: new Date().toISOString(),
      assets: this.assets,
      scenes: this.scenes.slice()
    };
    const list = this.readArchive();
    list.unshift(entry);
    this.writeArchive(list.slice(0, 24));
    this.renderArchive();
    this.api.toast('Saved to archive');
    this.setStatus('archived "' + entry.name + '" · ' + entry.assets.length + ' assets');
  }

  loadFromArchive(id) {
    const entry = this.readArchive().find((e) => e.id === id);
    if (!entry) return;
    this.assets = entry.assets.slice();
    this.scenes = (entry.scenes || []).slice();
    this.renderResults();
    this.api.toast('Loaded "' + entry.name + '" from archive');
    this.setStatus('loaded "' + entry.name + '" — ' + this.assets.length + ' assets ready');
  }

  sendArchiveToSandbox(id) {
    const keep = this.assets;
    this.loadFromArchive(id);
    this.sendAllToSandbox();
    this.assets = keep;
  }

  deleteArchive(id) {
    this.writeArchive(this.readArchive().filter((e) => e.id !== id));
    this.renderArchive();
    this.api.toast('Archive entry deleted');
  }

  exportArchive(id) {
    const entry = this.readArchive().find((e) => e.id === id);
    if (!entry) return;
    const bundle = {
      metadata: { appId: 'studioforge_design_archive', timestamp: entry.savedAt, version: 1 },
      state: { assetCount: entry.assets.length, sceneCount: (entry.scenes || []).length },
      assets: entry.assets.map((a) => ({ id: a.id, url: a.url, desc: a.desc, name: a.name, kind: a.kind, meta: a.meta }))
    };
    this.download(JSON.stringify(bundle, null, 2), 'studioforge-archive-' + entry.id + '.json');
    this.api.toast('Archive entry exported');
  }

  /* ------------------------------------------------------------ publish */

  publishBundle() {
    const app = this.api.app;
    const bundle = {
      metadata: {
        appId: 'studioforge_production_bundle',
        timestamp: new Date().toISOString(),
        version: 1
      },
      state: Object.assign({}, app.project().game, {
        filmShots: app.film ? app.film.shots.length : 0,
        designAssets: this.assets.length,
        designScenes: this.scenes.length
      }),
      assets: this.assets.map((a) => ({ id: a.id, url: a.url, desc: a.desc, name: a.name, kind: a.kind, style: a.style, meta: a.meta })),
      project: app.project()
    };
    this.download(JSON.stringify(bundle, null, 2), 'studioforge-production.json');
    this.api.toast('Published production bundle');
    this.setStatus('published · ' + this.assets.length + ' assets + project state');
  }

  download(text, name) {
    const blob = new Blob([text], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  /* -------------------------------------------------------------- render */

  renderResults() {
    if (!this.els.results) return;
    if (!this.assets.length) {
      this.els.results.innerHTML = '<div class="design-empty">◇ Write your prompt and generate assets.<br>Your concepts, your rules.</div>';
      return;
    }
    this.els.results.innerHTML = this.assets.map((a, i) => {
      const kindIdx = this.assets.filter((x) => x.kind === a.kind).indexOf(a);
      const isScene = a.kind === 'scene';
      return '<div class="design-card">' +
        '<img src="' + a.url + '" alt="' + escapeHtml(a.name) + '">' +
        '<div class="design-card-body"><b>' + escapeHtml(a.name) + '</b>' +
        '<small>' + escapeHtml(a.desc) + '</small>' +
        '<span class="design-meta">' + a.kind + ' · ' + escapeHtml(a.style) + ' · palette ' + a.palette + '</span></div>' +
        '<button class="btn tiny" data-send="' + a.kind + ':' + kindIdx + '">' +
        (isScene ? '🌍 Apply Scene' : '📨 Send to Sandbox') + '</button>' +
        '</div>';
    }).join('');
  }

  renderArchive() {
    if (!this.els.archive) return;
    const list = this.readArchive();
    if (!list.length) {
      this.els.archive.innerHTML = '<div class="small" style="opacity:.6">Archive is empty — save a generated set.</div>';
      return;
    }
    this.els.archive.innerHTML = list.map((e) =>
      '<div class="archive-row">' +
        '<img src="' + (e.assets[0] ? e.assets[0].url : '') + '" alt="">' +
        '<span class="archive-info"><b>' + escapeHtml(e.name) + '</b>' +
        '<small>' + e.assets.length + ' assets · ' + new Date(e.savedAt).toLocaleString() + '</small></span>' +
        '<button class="btn tiny" data-act="load" data-id="' + e.id + '">Load</button>' +
        '<button class="btn tiny" data-act="send" data-id="' + e.id + '">Send</button>' +
        '<button class="btn tiny" data-act="exp" data-id="' + e.id + '">⇩</button>' +
        '<button class="btn tiny" data-act="del" data-id="' + e.id + '">🗑</button>' +
      '</div>'
    ).join('');
  }
}
