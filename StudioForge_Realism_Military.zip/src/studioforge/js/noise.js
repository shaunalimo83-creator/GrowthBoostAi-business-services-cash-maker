/* ==========================================================================
   StudioForge — noise.js
   Deterministic, dependency-free terrain maths.

   The SAME heightAt() drives the visible terrain mesh, prop placement,
   player collision and editor raycasts — so nothing ever floats or sinks.
   ========================================================================== */

/* Seeded PRNG — same seed always rebuilds the same world. */
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makePermutation(seed) {
  const rng = mulberry32(seed ^ 0x9e3779b9);
  const p = new Uint8Array(256);
  for (let i = 0; i < 256; i++) p[i] = i;
  for (let i = 255; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const t = p[i]; p[i] = p[j]; p[j] = t;
  }
  const perm = new Uint8Array(512);
  for (let i = 0; i < 512; i++) perm[i] = p[i & 255];
  return perm;
}

const fade = (t) => t * t * t * (t * (t * 6 - 15) + 10);
const lerp = (a, b, t) => a + t * (b - a);

function grad2(h, x, y) {
  const g = h & 7;
  const u = g < 4 ? x : y;
  const v = g < 4 ? y : x;
  return ((g & 1) ? -u : u) + ((g & 2) ? -2 * v : 2 * v);
}

/* Classic 2D Perlin noise, output roughly -1..1. */
export function perlin2(perm, x, y) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const X = xi & 255, Y = yi & 255;
  const xf = x - xi, yf = y - yi;
  const u = fade(xf), v = fade(yf);

  const A = perm[X] + Y;
  const B = perm[X + 1] + Y;

  return lerp(
    lerp(grad2(perm[A], xf, yf), grad2(perm[B], xf - 1, yf), u),
    lerp(grad2(perm[A + 1], xf, yf - 1), grad2(perm[B + 1], xf - 1, yf - 1), u),
    v
  ) * 0.7;
}

/* Fractal Brownian motion — stacked octaves. */
function fbm(perm, x, y, octaves, lacunarity, gain) {
  let amp = 1, freq = 1, sum = 0, norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += perlin2(perm, x * freq, y * freq) * amp;
    norm += amp;
    amp *= gain;
    freq *= lacunarity;
  }
  return sum / norm;
}

export const WORLD = {
  size: 600,          // metres across
  segments: 176,      // terrain grid resolution
  waterLevel: -2.5,
  seaFloor: -14
};

/*
  Returns { heightAt(x,z), biomeAt(x,z), spawn } for one seed.
  heightAt is smooth and cheap enough to call thousands of times.
*/
export function makeHeightSampler(seed) {
  const perm = makePermutation(seed >>> 0);

  // Rolling hills
  function hills(x, z) {
    return fbm(perm, x * 0.0032, z * 0.0032, 4, 2.15, 0.5) * 16;
  }

  // Ridged mountain spines, masked so the centre of the map stays playable
  function mountains(x, z) {
    const r = 1 - Math.abs(fbm(perm, x * 0.0016 + 40, z * 0.0016 + 40, 3, 2.0, 0.5));
    const mask = Math.max(0, Math.min(1, (Math.hypot(x, z) - 90) / 210));
    return Math.pow(r, 3.1) * 46 * mask;
  }

  // Broad basin / ocean carving
  function basin(x, z) {
    return fbm(perm, x * 0.0011 + 300, z * 0.0011 + 300, 2, 2.0, 0.5) * 9 - 4;
  }

  function heightAt(x, z) {
    let h = hills(x, z) + mountains(x, z) + basin(x, z);
    // Flatten a spawn plateau near the origin so the player always lands safely
    const d = Math.hypot(x, z);
    if (d < 46) {
      const t = d / 46;
      const ease = t * t * (3 - 2 * t);
      const base = 3.2;
      h = lerp(base, h, ease);
    }
    return h;
  }

  function slopeAt(x, z) {
    const e = 1.4;
    const dx = heightAt(x + e, z) - heightAt(x - e, z);
    const dz = heightAt(x, z + e) - heightAt(x, z - e);
    return Math.hypot(dx, dz) / (2 * e);
  }

  function biomeAt(x, z) {
    const h = heightAt(x, z);
    if (h < WORLD.waterLevel + 0.4) return 'shore';
    if (h > 30) return 'snow';
    if (h > 19 || slopeAt(x, z) > 0.62) return 'rock';
    return 'grass';
  }

  return {
    seed: seed >>> 0,
    heightAt,
    slopeAt,
    biomeAt,
    spawn: { x: 0, z: 0, y: heightAt(0, 0) }
  };
}

/* Colour ramp used for terrain vertex colours. */
export function terrainColor(h, slope, waterLevel) {
  const c = { r: 0.32, g: 0.52, b: 0.24 };

  if (h < waterLevel + 1.2) {          // wet sand
    c.r = 0.60; c.g = 0.54; c.b = 0.38;
  } else if (h < 6) {                   // arid ground
    c.r = 0.44; c.g = 0.46; c.b = 0.28;
  } else if (h < 19) {                  // dry highland scrub
    c.r = 0.38; c.g = 0.40; c.b = 0.26;
  } else if (h < 30) {                  // rock
    c.r = 0.40; c.g = 0.40; c.b = 0.42;
  } else {                              // snow
    c.r = 0.92; c.g = 0.94; c.b = 0.97;
  }

  // Steep faces always read as bare rock
  if (slope > 0.72 && h >= waterLevel) {
    const t = Math.min(1, (slope - 0.72) * 1.6);
    c.r = lerp(c.r, 0.38, t);
    c.g = lerp(c.g, 0.37, t);
    c.b = lerp(c.b, 0.38, t);
  }

  // Cheap micro-variation so large flats are not perfectly uniform
  const n = (perlin2(makePermutation(7), 0, 0) + 1) * 0.5;
  const j = 0.94 + n * 0.09;
  return [c.r * j, c.g * j, c.b * j];
}
