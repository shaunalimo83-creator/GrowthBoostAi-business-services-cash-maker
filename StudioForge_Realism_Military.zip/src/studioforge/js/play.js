/* ==========================================================================
   StudioForge — play.js
   First-person mode: pointer-lock look, WASD + sprint + jump + crouch,
   gravity, terrain following, prop collision, hitscan shooting, hostile
   AI with contact damage, ammo/reload, health and a live HUD.
   ========================================================================== */

import * as THREE from 'three';

const CFG = {
  eyeHeight: 1.72,
  crouchHeight: 1.05,
  walk: 6.2,
  sprint: 9.8,
  crouchSpeed: 3.1,
  accel: 34,
  gravity: 24,
  jump: 8.4,
  playerRadius: 0.55,
  mag: 30,
  reserve: 90,
  reloadTime: 1.5,
  fireRate: 0.105,
  damage: 34,
  regenDelay: 6,
  regenRate: 4.5,
  enemySpeed: 2.5,
  enemyRange: 2.3,
  enemyDamage: 7,
  enemyCooldown: 1.15,
  bossSpeed: 1.5,
  bossRange: 3.6,
  bossDamage: 15,
  bossCooldown: 1.5,
  enemyHP: 100,
  bossHP: 420,
  spread: 0.012
};

export class Player {
  constructor(app) {
    this.app = app;
    this.canvas = app.renderer.domElement;
    this.hud = app.hud;

    this.yaw = 0;
    this.pitch = 0;
    this.vel = new THREE.Vector3();
    this.onGround = true;
    this.crouching = false;
    this.position = new THREE.Vector3(0, 0, 0);

    this.hp = 100;
    this.ammo = CFG.mag;
    this.reserve = CFG.reserve;
    this.reloading = false;
    this.fireTimer = 0;
    this.lastHitTime = -99;
    this.time = 0;
    this.kills = 0;
    this.raf = null;

    this.keys = Object.create(null);
    /* Head-bob state — amount eases 0..1, phase advances with stride. */
    this.bobPhase = 0;
    this.bobAmp = 0;
    this.bobTarget = 0;
    this.sprinting = false;
    this.raycaster = new THREE.Raycaster();
    this.forward = new THREE.Vector3();
    this.right = new THREE.Vector3();

    this.muzzle = new THREE.PointLight(0xffd9a0, 0, 9, 2);
    this.muzzle.visible = false;
    app.scene.add(this.muzzle);

    this.bind();
  }

  /* ------------------------------------------------------------- binding */

  bind() {
    const c = this.canvas;

    this.onMouseMove = (e) => {
      if (!document.pointerLockElement) return;
      const sx = (e.movementX || 0) * 0.0022;
      const sy = (e.movementY || 0) * 0.0022;
      this.yaw -= sx;
      this.pitch = Math.max(-1.45, Math.min(1.45, this.pitch - sy));
    };

    this.onMouseDown = (e) => {
      if (this.app.mode !== 'play') return;
      if (!document.pointerLockElement) {
        this.lock();
        return;
      }
      if (e.button === 0) this.fire();
      if (e.button === 2) this.reload();
    };

    this.onKeyDown = (e) => {
      if (this.app.mode !== 'play') return;
      const k = e.key.toLowerCase();

      if (/^(w|a|s|d| |shift|control|c|arrowup|arrowdown|arrowleft|arrowright)$/.test(k)) {
        this.keys[k] = true;
        e.preventDefault();
      }
      if (k === 'r') { this.reload(); e.preventDefault(); }
      if (k === ' ') {
        if (this.onGround) {
          this.vel.y = CFG.jump;
          this.onGround = false;
        }
        e.preventDefault();
      }
    };

    this.onKeyUp = (e) => { this.keys[e.key.toLowerCase()] = false; };

    c.addEventListener('mousemove', this.onMouseMove);
    c.addEventListener('mousedown', this.onMouseDown);
    c.addEventListener('contextmenu', (e) => e.preventDefault());
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', () => { this.keys = Object.create(null); });

    /*
      The overlay is what the pointer clicks to lock, so it must be hidden
      the moment the lock takes hold and restored when the user escapes.
    */
    document.addEventListener('pointerlockchange', () => {
      const locked = document.pointerLockElement === c;
      if (this.app.mode !== 'play') return;
      this.hud.crosshair.classList.toggle('hidden', !locked);
      this.hud.overlay.classList.toggle('hidden', locked);
    });
  }

  lock() {
    const c = this.canvas;
    if (c.requestPointerLock) {
      const p = c.requestPointerLock();
      if (p && p.catch) p.catch(() => {});
    }
  }

  /* --------------------------------------------------------------- enter */

  enter() {
    const spawn = this.app.sampler.spawn;
    this.position.set(spawn.x, spawn.y + CFG.eyeHeight, spawn.z + 14);

    /* Make sure the spawn column is dry land. */
    let guard = 0;
    while (this.app.sampler.heightAt(this.position.x, this.position.z) < -1 && guard++ < 200) {
      this.position.z += 6;
    }

    this.yaw = Math.PI;
    this.pitch = -0.05;
    this.vel.set(0, 0, 0);
    this.onGround = true;
    this.reloading = false;
    this.fireTimer = 0;

    this.hp = 100;
    this.ammo = CFG.mag;
    this.reserve = CFG.reserve;
    this.kills = 0;

    this.hud.root.classList.remove('hidden');
    this.hud.crosshair.classList.remove('hidden');
    this.hud.overlay.classList.remove('hidden');
    this.updateHud();

    /* Wake the hostiles that already exist in the scene graph. */
    this.app.objects.forEach((o) => {
      if (o.type === 'enemy') o.hp = CFG.enemyHP;
      if (o.type === 'boss') o.hp = CFG.bossHP;
    });

    this.app.setActivity('Play mode — click to lock the pointer, WASD to move, LMB to fire.');
    this.app.setAI('Runtime attached. ' + this.hostiles().length + ' hostiles are tracking the player.');
  }

  exit() {
    if (document.pointerLockElement) {
      document.exitPointerLock && document.exitPointerLock();
    }
    this.keys = Object.create(null);
    this.hud.root.classList.add('hidden');
    this.hud.crosshair.classList.add('hidden');
    this.hud.overlay.classList.add('hidden');
    this.muzzle.visible = false;
  }

  hostiles() {
    return this.app.objects.filter((o) => o.type === 'enemy' || o.type === 'boss');
  }

  /* ---------------------------------------------------------------- tick */

  tick(dt) {
    dt = Math.min(0.05, dt);
    this.time += dt;

    this.move(dt);

    /* Head-bob dynamics — eases in/out, faster stride while sprinting. */
    this.bobAmp = Math.max(0, Math.min(1, this.bobAmp + (this.bobTarget ? dt * 5 : -dt * 5)));
    if (this.bobTarget) this.bobPhase += dt * (this.sprinting ? 11.5 : 8.2);

    this.hostileTick(dt);
    this.regen(dt);
    this.updateCamera();
    this.updateHud();
  }

  move(dt) {
    const k = this.keys;
    const sprinting = !!k.shift;
    this.crouching = !!k.c;

    let speed = this.crouching ? CFG.crouchSpeed : (sprinting ? CFG.sprint : CFG.walk);

    const f = (k.w || k.arrowup ? 1 : 0) - (k.s || k.arrowdown ? 1 : 0);
    const r = (k.d || k.arrowright ? 1 : 0) - (k.a || k.arrowleft ? 1 : 0);

    /* Movement basis from yaw only, so looking up never slows you down. */
    this.forward.set(Math.sin(this.yaw), 0, Math.cos(this.yaw)).multiplyScalar(-1);
    this.right.set(-this.forward.z, 0, this.forward.x);

    const wish = new THREE.Vector3()
      .addScaledVector(this.forward, f)
      .addScaledVector(this.right, r);

    if (wish.lengthSq() > 0) wish.normalize().multiplyScalar(speed);

    this.bobTarget = wish.lengthSq() > 0.1 ? 1 : 0;
    this.sprinting = sprinting && this.bobTarget === 1;

    /* Horizontal acceleration + drag. */
    this.vel.x += (wish.x - this.vel.x) * Math.min(1, CFG.accel * dt * 0.35);
    this.vel.z += (wish.z - this.vel.z) * Math.min(1, CFG.accel * dt * 0.35);

    /* Gravity. */
    this.vel.y -= CFG.gravity * dt;

    this.position.x += this.vel.x * dt;
    this.position.y += this.vel.y * dt;
    this.position.z += this.vel.z * dt;

    /* World bounds. */
    const lim = this.app.WORLD_SIZE / 2 - 6;
    this.position.x = Math.max(-lim, Math.min(lim, this.position.x));
    this.position.z = Math.max(-lim, Math.min(lim, this.position.z));

    /* Prop collision — push out of solid objects. */
    this.resolveCollisions();

    /* Terrain follow. */
    const ground = this.app.sampler.heightAt(this.position.x, this.position.z);
    const eye = this.crouching ? CFG.crouchHeight : CFG.eyeHeight;
    const floor = ground + eye;

    if (this.position.y <= floor) {
      this.position.y = floor;
      if (this.vel.y < 0) this.vel.y = 0;
      this.onGround = true;
    } else {
      this.onGround = false;
    }

    /* Never let the camera drop under the water surface. */
    const water = this.app.waterY + eye * 0.55;
    if (this.position.y < water) {
      this.position.y = water;
      this.onGround = true;
      if (this.vel.y < 0) this.vel.y = 0;
    }
  }

  resolveCollisions() {
    const objs = this.app.objects;
    for (let i = 0; i < objs.length; i++) {
      const o = objs[i];
      if (!o.solid || !o.mesh) continue;

      const dx = this.position.x - o.x;
      const dz = this.position.z - o.z;
      const d = Math.hypot(dx, dz);
      const min = o.radius * o.scale + CFG.playerRadius;
      if (d >= min || d === 0) continue;

      const nx = dx / d;
      const nz = dz / d;
      this.position.x = o.x + nx * min;
      this.position.z = o.z + nz * min;

      /* Cancel the velocity component pushing into the object. */
      const dot = this.vel.x * nx + this.vel.z * nz;
      if (dot < 0) {
        this.vel.x -= dot * nx;
        this.vel.z -= dot * nz;
      }
    }
  }

  hostileTick(dt) {
    const objs = this.app.objects;
    let touching = 0;

    for (let i = 0; i < objs.length; i++) {
      const o = objs[i];
      if (o.type !== 'enemy' && o.type !== 'boss') continue;
      if (o.dead) continue;

      const boss = o.type === 'boss';
      const speed = boss ? CFG.bossSpeed : CFG.enemySpeed;
      const range = boss ? CFG.bossRange : CFG.enemyRange;

      const dx = this.position.x - o.x;
      const dz = this.position.z - o.z;
      const d = Math.hypot(dx, dz);

      if (d > range) {
        const step = speed * dt;
        o.x += (dx / d) * step;
        o.z += (dz / d) * step;
        o.y = this.app.sampler.heightAt(o.x, o.z);
        this.app.applyObjectTransform(o);
        o.mesh.rotation.y = Math.atan2(dx, dz);
      } else {
        touching++;
        o.attackTimer = (o.attackTimer || 0) - dt;
        if (o.attackTimer <= 0) {
          o.attackTimer = boss ? CFG.bossCooldown : CFG.enemyCooldown;
          this.damage(boss ? CFG.bossDamage : CFG.enemyDamage);
        }
      }
    }

    this.hud.objective.textContent = touching
      ? 'OBJECTIVE: ' + touching + ' hostile' + (touching > 1 ? 's' : '') + ' engaging — fight or fall back'
      : (this.hostiles().length
          ? 'OBJECTIVE: ' + this.hostiles().length + ' hostiles active — hunt them down'
          : 'OBJECTIVE: Sector clear — explore the world');
  }

  damage(amount) {
    this.hp = Math.max(0, this.hp - amount);
    this.lastHitTime = this.time;

    this.hud.vignette.style.opacity = '1';
    clearTimeout(this._vig);
    this._vig = setTimeout(() => { this.hud.vignette.style.opacity = '0'; }, 190);

    if (this.hp <= 0) this.respawn();
  }

  respawn() {
    const spawn = this.app.sampler.spawn;
    this.position.set(spawn.x, this.app.sampler.heightAt(spawn.x, spawn.z) + CFG.eyeHeight, spawn.z + 14);
    this.vel.set(0, 0, 0);
    this.hp = 100;
    this.ammo = CFG.mag;
    this.reserve = CFG.reserve;
    this.app.toast('You went down — respawned at the LZ.');
    this.app.setActivity('Respawned. Health restored to 100.');
  }

  regen(dt) {
    if (this.time - this.lastHitTime > CFG.regenDelay && this.hp > 0) {
      this.hp = Math.min(100, this.hp + CFG.regenRate * dt);
    }
    if (this.fireTimer > 0) this.fireTimer -= dt;

    if (this.reloading) {
      this.reloadTimer -= dt;
      if (this.reloadTimer <= 0) {
        const need = CFG.mag - this.ammo;
        const take = Math.min(need, this.reserve);
        this.ammo += take;
        this.reserve -= take;
        this.reloading = false;
        this.hud.reloadHint.classList.add('hidden');
      }
    }
  }

  reload() {
    if (this.reloading || this.ammo >= CFG.mag || this.reserve <= 0) return;
    this.reloading = true;
    this.reloadTimer = CFG.reloadTime;
    this.hud.reloadHint.classList.remove('hidden');
  }

  /* --------------------------------------------------------------- firing */

  fire() {
    if (this.reloading || this.fireTimer > 0) return;

    if (this.ammo <= 0) {
      this.reload();
      return;
    }

    this.ammo--;
    this.fireTimer = CFG.fireRate;

    /* Recoil kick. */
    this.pitch = Math.min(1.45, this.pitch + 0.011);

    this.muzzle.position.copy(this.app.camera.position);
    this.muzzle.position.y -= 0.16;
    this.muzzle.visible = true;
    clearTimeout(this._muz);
    this._muz = setTimeout(() => { this.muzzle.visible = false; }, 52);

    const dir = new THREE.Vector3();
    this.app.camera.getWorldDirection(dir);
    dir.x += (Math.random() - 0.5) * CFG.spread;
    dir.y += (Math.random() - 0.5) * CFG.spread;
    dir.z += (Math.random() - 0.5) * CFG.spread;
    dir.normalize();

    this.raycaster.set(this.app.camera.position, dir);
    this.raycaster.far = 400;

    const candidates = this.hostiles().filter((o) => !o.dead).map((o) => o.mesh);
    const hits = this.raycaster.intersectObjects(candidates, true);

    let blockedByTerrain = false;
    if (this.app.terrain) {
      const th = this.raycaster.intersectObject(this.app.terrain, false);
      if (th.length && (!hits.length || th[0].distance < hits[0].distance)) blockedByTerrain = true;
    }

    if (hits.length && !blockedByTerrain) {
      let node = hits[0].object;
      while (node && !node.userData.objId) node = node.parent;
      const target = node ? this.app.findObject(node.userData.objId) : null;

      if (target) {
        target.hp = (target.hp == null ? CFG.enemyHP : target.hp) - CFG.damage;
        this.showHitMarker();
        this.app.setStatus('Hit ' + target.name + ' — ' + Math.max(0, Math.round(target.hp)) + ' HP');

        if (target.hp <= 0) this.kill(target);
      }
    }
  }

  showHitMarker() {
    const m = this.hud.hitMarker;
    m.classList.remove('pop');
    void m.offsetWidth;
    m.classList.add('pop');
  }

  kill(target) {
    target.dead = true;
    this.kills++;
    this.app.removeObject(target.id, { silent: true, keepHistory: true });
    this.app.setActivity('Eliminated ' + target.name + '. Kills: ' + this.kills);
    this.app.toast('Eliminated ' + target.name);
  }

  /* ---------------------------------------------------------------- view */

  updateCamera() {
    this.app.camera.position.copy(this.position);

    /* Head-bob + lateral camera inertia, tied to the player's stride. */
    const bob = Math.sin(this.bobPhase) * 0.05 * this.bobAmp;
    const sway = Math.cos(this.bobPhase * 0.5) * 0.03 * this.bobAmp;
    this.app.camera.position.y += bob;
    this.app.camera.position.x += sway * Math.cos(this.yaw);
    this.app.camera.position.z += sway * -Math.sin(this.yaw);

    this.app.camera.rotation.set(0, 0, 0, 'YXZ');
    this.app.camera.rotation.order = 'YXZ';
    this.app.camera.rotation.y = this.yaw;
    this.app.camera.rotation.x = this.pitch;
    this.app.camera.rotation.z = 0;
  }

  updateHud() {
    const h = this.hud;
    h.health.textContent = String(Math.round(this.hp));
    h.healthBar.style.width = Math.max(0, Math.min(100, this.hp)) + '%';
    h.ammo.textContent = String(this.ammo);
    h.reserve.textContent = String(this.reserve);
    h.kills.textContent = 'KILLS ' + this.kills;
    h.pos.textContent = 'X ' + this.position.x.toFixed(0) + '  Z ' + this.position.z.toFixed(0) +
      '  ALT ' + Math.round(this.position.y - this.app.sampler.heightAt(this.position.x, this.position.z));
    h.fps.textContent = Math.round(this.app.fps || 0) + ' FPS';
  }
}

export { CFG };
