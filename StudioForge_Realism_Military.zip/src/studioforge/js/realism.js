/* ==========================================================================
   StudioForge — realism.js
   Cinematic rendering layer that pushes the viewport toward the AAA
   reference look (golden-hour military FPS):

   • EffectComposer chain — RenderPass → UnrealBloom → OutputPass
     (ACES tone mapping + sRGB output in the OutputPass)
   • Golden-hour lighting rig — low warm sun, long shadows, warm haze fog
   • Instanced vegetation — thousands of grass tufts in one draw call

   HONESTY NOTE: this is real-time WebGL rendering. It raises the ceiling a
   long way (bloom, volumetric-feel fog, warm grading, soft shadows) but a
   browser canvas cannot match a AAA engine's PBR fidelity, screen-space
   reflections, or megatexture streaming. It is the same rendering family,
   not the same pixel output.
   ========================================================================== */

import * as THREE from 'three';
import { EffectComposer } from '../vendor/postprocessing/EffectComposer.js';
import { RenderPass } from '../vendor/postprocessing/RenderPass.js';
import { UnrealBloomPass } from '../vendor/postprocessing/UnrealBloomPass.js';
import { OutputPass } from '../vendor/postprocessing/OutputPass.js';
import { mulberry32, WORLD } from './noise.js';

/* --------------------------------------------- post-processing composer */

export function createComposer(app) {
  const size = new THREE.Vector2();
  app.renderer.getSize(size);

  const composer = new EffectComposer(app.renderer);
  composer.addPass(new RenderPass(app.scene, app.camera));

  /* Bloom tuned for a low sun: halo around the disc and bright horizons. */
  const bloom = new UnrealBloomPass(size.clone(), 0.38, 0.65, 0.86);
  composer.addPass(bloom);

  /* Applies ACES filmic tone mapping + sRGB conversion at the end. */
  composer.addPass(new OutputPass());

  return composer;
}

/* ------------------------------------------------ golden-hour light rig */

export function applyGoldenHour(app) {
  /* Fog — warm atmospheric haze so distant ridges read like the reference. */
  app.scene.fog = new THREE.Fog(0xd9a06b, 150, 880);

  /* Sky — warm horizon into dusk blue. */
  const sky = app.scene.children.find((c) => c.userData && c.userData.isSky);
  if (sky && sky.material && sky.material.uniforms) {
    sky.material.uniforms.topColor.value.set(0x39597f);
    sky.material.uniforms.bottomColor.value.set(0xffc07a);
  }

  /* Sun — low angle, warm, long shadows across the ground. */
  const lights = app.lights;
  if (!lights) return;
  const sun = lights.userData.sun;
  if (sun) {
    sun.color.set(0xffb469);
    sun.intensity = 2.7;
    sun.position.set(150, 46, -215);
  }
  lights.children.forEach((c) => {
    if (c.isHemisphereLight) {
      c.color.set(0xffd2a8);
      c.groundColor.set(0x54402c);
      c.intensity = 0.75;
    }
    if (c.isAmbientLight) {
      c.color.set(0x6b5a48);
      c.intensity = 0.3;
    }
  });
}

/* --------------------------------------------------- instanced vegetation */

/*
  One InstancedMesh holds every grass tuft — a single draw call even with
  thousands of instances. Placement is seeded and terrain-aware: only on
  dry, gentle ground, never in water or on rock/snow.
*/
export function addInstancedGrass(app) {
  /* Rebuild-safe: drop the previous field first. */
  const old = app.terrainGroup.getObjectByName('grass');
  if (old) {
    app.terrainGroup.remove(old);
    old.geometry.dispose();
    old.material.dispose();
  }

  const rng = mulberry32(((app.seed >>> 0) ^ 0x51ab7e) >>> 0);
  const geo = new THREE.ConeGeometry(0.09, 0.85, 4);
  const mat = new THREE.MeshStandardMaterial({
    color: 0x77803c,
    roughness: 1,
    metalness: 0,
    flatShading: true
  });

  const MAX = 1600;
  const dummy = new THREE.Object3D();
  const data = [];

  for (let i = 0; i < MAX * 3 && data.length < MAX; i++) {
    const x = (rng() * 2 - 1) * (WORLD.size / 2 - 20);
    const z = (rng() * 2 - 1) * (WORLD.size / 2 - 20);
    const h = app.sampler.heightAt(x, z);
    if (h < WORLD.waterLevel + 0.7) continue;            // no grass in water
    if (app.sampler.slopeAt(x, z) > 0.42) continue;      // none on cliffs
    const biome = app.sampler.biomeAt(x, z);
    if (biome === 'rock' || biome === 'snow') continue;
    data.push({ x, z, h, s: 0.6 + rng() * 1.15, r: rng() * Math.PI * 2 });
  }

  const mesh = new THREE.InstancedMesh(geo, mat, data.length);
  mesh.name = 'grass';
  mesh.receiveShadow = true;
  mesh.castShadow = false;

  for (let i = 0; i < data.length; i++) {
    const g = data[i];
    dummy.position.set(g.x, g.h + 0.32 * g.s, g.z);
    dummy.rotation.set(0, g.r, (rng() - 0.5) * 0.14);
    dummy.scale.set(g.s, g.s * (0.85 + rng() * 0.5), g.s);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
  }
  mesh.instanceMatrix.needsUpdate = true;

  app.terrainGroup.add(mesh);
  return mesh;
}
