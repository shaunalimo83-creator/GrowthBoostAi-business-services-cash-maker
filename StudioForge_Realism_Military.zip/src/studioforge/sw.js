/* StudioForge — service worker.
   Cache-first app shell so the studio reopens offline.
   Cache name is versioned: bump it whenever a shell file changes,
   otherwise clients keep serving the old copy. */

const CACHE = "studioforge-v7";

const SHELL = [
  "./",
  "./index.html",
  "./css/studio.css",
  "./js/app.js",
  "./js/noise.js",
  "./js/terrain.js",
  "./js/world.js",
  "./js/editor.js",
  "./js/play.js",
  "./js/film.js",
  "./js/plugins.js",
  "./js/designer.js",
  "./js/realism.js",
  "./vendor/three.module.js",
  "./vendor/shaders/CopyShader.js",
  "./vendor/shaders/LuminosityHighPassShader.js",
  "./vendor/shaders/OutputShader.js",
  "./vendor/postprocessing/EffectComposer.js",
  "./vendor/postprocessing/RenderPass.js",
  "./vendor/postprocessing/ShaderPass.js",
  "./vendor/postprocessing/MaskPass.js",
  "./vendor/postprocessing/Pass.js",
  "./vendor/postprocessing/UnrealBloomPass.js",
  "./vendor/postprocessing/OutputPass.js",
  "./vendor/postprocessing/shaders/CopyShader.js",
  "./vendor/postprocessing/shaders/LuminosityHighPassShader.js",
  "./vendor/postprocessing/shaders/OutputShader.js",
  "./manifest.webmanifest",
  "./icons/icon-192.png",
  "./icons/icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE)
      .then((cache) => cache.addAll(SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(req).then((hit) => {
      if (hit) return hit;

      return fetch(req).then((res) => {
        if (!res || res.status !== 200 || res.type === "opaque") return res;
        const copy = res.clone();
        caches.open(CACHE).then((cache) => cache.put(req, copy));
        return res;
      }).catch(() => caches.match("./index.html"));
    })
  );
});
