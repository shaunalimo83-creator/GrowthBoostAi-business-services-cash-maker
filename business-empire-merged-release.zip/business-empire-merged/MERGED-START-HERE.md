# Start here — Business Empire merged project

This ZIP is one source-code monorepo containing the CEO HQ, seven business applications, and the shared Vibe Coding Platform. It is not nine separately zipped applications.

## Local setup

1. Install Node.js 20 or newer and npm 10 or newer.
2. Extract this ZIP and open a terminal in `business-empire-merged` (the project root).
3. Run `npm ci`.
4. Copy `.env.example` to `.env` and fill in the required development values. Keep secrets private; do not commit `.env`.
5. Provision a PostgreSQL database and set `DATABASE_URL`.
6. Run `npm run db:validate`, then `npm run db:generate` and `npx prisma migrate deploy --schema packages/db/prisma/schema.prisma` after reviewing migrations.
7. Run `npm run release:verify`, `npm run typecheck`, and `npm test`.
8. Build and test the required workspace(s) before deploying. See `docs/deployment.md` and `RELEASE-STATUS.md`.

## Development ports

HQ 3000; GrowthBoost 3001; AI Magazine 3002; Trust Vault 3003; Stock Express 3004; Real Estate 3005; SUPERGPU 3006; DailyAccess 3007; Vibe Coding Platform 3008.

Use `npm run dev:all` to start all configured workspaces after dependencies and environment are ready. `npm run build:apps` builds the workspaces that expose build scripts.

## Do not skip the launch gates

A passing structural check is not a production certification. The release status and merge report explain which provider integrations, runtime tests, security tests, and regulated-service approvals are still outstanding.
