# Empire — Seven-Business Ecosystem with CEO Master Dashboard

Development monorepo foundation: **7 business apps + 1 CEO Master Dashboard**,
one shared TypeScript core, one PostgreSQL schema with company-level data
isolation, a double-entry ledger with financial controls, and honest,
labelled handling of every regulated capability.

| # | Company | App | Subdomain |
|---|---|---|---|
| 1 | GrowthBoost AI | `apps/growthboost` | growthboost.example.com |
| 2 | AI Magazine & Comic Book Studio | `apps/ai-magazine` | aimagazine.example.com |
| 3 | Trust Vault Bank | `apps/trust-vault` | trustvault.example.com |
| 4 | Stock Market Express | `apps/stock-express` | stockexpress.example.com |
| 5 | Real Estate Master Developments | `apps/real-estate` | realestate.example.com |
| 6 | SUPERGPU UNIVERSAL | `apps/supergpu` | supergpu.example.com |
| 7 | DailyAccess | `apps/dailyaccess` | dailyaccess.example.com |
| — | **CEO Master Dashboard (HQ)** | `apps/hq` | hq.example.com |

Reporting currency: **GBP** everywhere.

The integrated **Vibe Coding Platform** is an additional shared workspace at `apps/vibe-coding-platform` (local port 3008). It serves all seven business apps and CEO HQ; it is a platform service, not an eighth portfolio company.

## Implemented source foundations vs pending verification

The repository contains source for RBAC, money primitives, a double-entry ledger, intercompany authorisation, TOTP MFA, password hashing, nine app workspaces (seven business apps, HQ and the shared Vibe Coding Platform), a Prisma schema, RLS policies, documentation and an integration register. These are source-code components, not a claim that the complete system has passed production testing or is deployed. Run `npm run preflight`, then install dependencies and execute the full verification steps below.

- **Pending/unavailable (labelled, never faked)**: payment processing (PSP
  merchant accounts), Trust Vault financial services (needs an appropriately
  authorised partner — it is *not* an authorised bank), Stock Market Express
  live trading (paper trading only), market data feeds.

## Current implementation boundary

The HQ consolidated-reporting API deliberately returns HTTP 503 until a real
managed-auth adapter, mandatory MFA, CEO cross-company permission check and
live ledger query are configured. This is fail-closed behaviour, not a live
financial service. The HQ login, staff, reports and security pages are setup
scaffolds; do not expose them publicly as production controls yet.

For local development, the intended app ports are HQ 3000, GrowthBoost 3001,
AI Magazine 3002, Trust Vault 3003, Stock Express 3004, Real Estate 3005,
SUPERGPU 3006, DailyAccess 3007 and Vibe Coding Platform 3008. Production domains remain unregistered
until real domains, DNS records and TLS certificates are configured.

## Quick start

```bash
npm install
cp .env.example .env
# Do not run the legacy scaffold generator on this hardened source release.
npm run preflight         # structural source check
npx prisma validate --schema packages/db/prisma/schema.prisma
npm run typecheck
npm run vibe:typecheck   # Vibe app TypeScript check
npm test                  # Vitest suites (unit + ecosystem)
```

E2E (staging): `npx playwright test --config tests/playwright.config.ts`

## Local app ports

Run each app from its directory with `npm run dev`; ports are configured uniquely: HQ 3000, GrowthBoost 3001, AI Magazine 3002, Trust Vault 3003, Stock Express 3004, Real Estate 3005, SUPERGPU 3006, DailyAccess 3007 and Vibe Coding Platform 3008. Use `npm run vibe:dev` from the monorepo root for the shared Vibe platform.

## Verification status

The preflight is a structural check only. Dependency installation, full type-checking, unit and browser tests, production builds, database migrations, security review and deployment must still be completed in a controlled staging environment. See [docs/phase3-audit.md](docs/phase3-audit.md).

## Documentation

- [docs/architecture.md](docs/architecture.md) — platform, tenancy, isolation
- [docs/security.md](docs/security.md) — auth, permissions, financial controls
- [docs/deployment.md](docs/deployment.md) — staged rollout per business
- [docs/backup-recovery.md](docs/backup-recovery.md) — backups, RPO/RTO, runbook
- [docs/integration-register.md](docs/integration-register.md) — connected/pending/unavailable
- [docs/api/openapi.yaml](docs/api/openapi.yaml) — API documentation


## Latest implementation phase
See `docs/auth-database-foundation.md` for the CEO authentication, MFA-gated session, and database setup added in this version. Production deployment still requires secret provisioning, migrations, rate limiting and live integration testing.


## Phase 5 — first CEO account

The first HQ CEO is created through the one-time interactive terminal command `npm run bootstrap:ceo` after database migrations and secrets are configured. See `docs/phase5-owner-bootstrap.md` for prerequisites, authenticator verification, and security limitations. There is no public CEO signup endpoint.


## Phase 6 security additions
See `docs/phase6-session-recovery-hardening.md` for CEO session controls, recovery codes, login throttling, cleanup scheduling and mandatory deployment steps. Apply the reviewed Prisma migration before using the new throttle-backed login route.

## Phase 7 — tenant isolation hardening

Phase 7 corrects the PostgreSQL RLS policies to use Prisma's quoted camelCase
column names, adds forced RLS for tenant-owned tables and intercompany records,
and includes a static policy/migration consistency check. See
`docs/phase7-tenant-isolation.md` before applying the migration. This phase is
not production deployment: route-level transaction-scoped tenant context and
real PostgreSQL cross-tenant tests remain required.

## Phase 8 API tenant isolation

Phase 8 adds a transaction-scoped tenant session guard for all seven business apps, membership-gated Company discovery under RLS, fail-closed protected summary/export/admin routes, unit tests and an opt-in PostgreSQL RLS integration test. See `docs/phase8-api-tenant-context.md`. Business-app login remains unconfigured and protected data endpoints intentionally return 503 after authorisation until their data contracts are implemented; this ZIP is not a production deployment.


## Phase 9 — business workspaces

Phase 9 adds business-specific customer workspace and staff control-room layouts for all seven businesses. These pages are presentation scaffolds with explicit setup-pending disclosures; business-app authentication remains unavailable (HTTP 501) until managed identity, verified registration, MFA, recovery and session services are configured. No live customer records, balances or operational activity are fabricated. See [docs/phase9-customer-workspaces.md](docs/phase9-customer-workspaces.md).

## Phase 10 — customer identity foundation

Seven business applications now share the same User/Session identity store and expose fixed-company customer registration, sign-in, sign-out and session introspection endpoints. Registration is disabled by default and must remain disabled until verified-email delivery, abuse controls and customer MFA are implemented. See `docs/phase10-customer-identity.md` for security boundaries and outstanding production requirements.

## Phase 11 customer security

See `docs/phase11-customer-security.md` for customer email verification, TOTP MFA, one-time recovery codes, server-side email adapter configuration and outstanding launch gates.


## Phase 14 — Vibe Coding Platform

`apps/vibe-coding-platform` adds a shared project studio, existing-account sign-in, business-membership checks, CEO HQ project scope, project/file persistence, local sandboxed HTML preview, three-project free-plan enforcement and private marketplace draft listings. The Phase 14 migration adds tenant-scoped project/file/run/listing tables and an account-wide user entitlement table, all with PostgreSQL RLS. AI code generation is wired to Vercel AI Gateway when server-side credentials/model settings are supplied, but that integration has not been runtime-tested. Hosted sandbox execution, public deployment, custom-domain provisioning, paid plan checkout, listing publication, buyer checkout and seller payouts remain pending provider integrations and verification. See `docs/vibe-coding-platform.md`.

## Latest development phase

Phase 12 adds customer password-reset requests and confirmation, authenticated password changes, active-session listing and revocation across all seven customer applications. See `docs/phase12-account-recovery.md`. Apply the new database migration before enabling these endpoints in a live environment.
