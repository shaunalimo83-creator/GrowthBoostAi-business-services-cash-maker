const CONTROLS = ["Business profile & settings", "Staff roles and permissions", "Customer support queue", "Service configuration", "Security and audit events", "Integrations and provider status", "Operational reports"];
export default function Admin() {
  return <main style={{fontFamily:"system-ui",maxWidth:960,margin:"0 auto",padding:24}}>
    <h1>AI Magazine & Comic Book Studio — business control room</h1>
    <p>Administrative workspace layout. Staff authentication, MFA enforcement and live company data must be configured before operational use.</p>
    <p style={{background:"#fff7ed",padding:14,borderRadius:10}}><strong>Not connected:</strong> this page does not grant admin access or display live customer or financial data.</p>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:12}}>{CONTROLS.map(x=><section key={x} style={{border:"1px solid #ddd",borderRadius:10,padding:14}}><h2 style={{fontSize:17}}>{x}</h2><p style={{fontSize:13,color:"#64748b"}}>Requires configured admin identity and authorised data service.</p><b style={{fontSize:12,color:"#92400e"}}>SETUP PENDING</b></section>)}</div>
    <p style={{marginTop:24}}><a href="/login">Staff sign-in</a> · <a href="/support">Support</a></p>
  </main>;
}
