import { registerCustomer } from "../../../../lib/identity";
export async function POST(req: Request) { return registerCustomer(req); }
