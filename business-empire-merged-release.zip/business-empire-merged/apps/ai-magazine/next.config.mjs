export default {
  reactStrictMode: true,
  transpilePackages: ["@empire/core", "@empire/db"],
};
