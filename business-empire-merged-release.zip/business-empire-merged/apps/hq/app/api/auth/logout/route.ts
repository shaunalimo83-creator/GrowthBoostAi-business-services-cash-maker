import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@empire/db";
import { sha256, isSameOriginRequest } from "@empire/core";
import { SESSION_COOKIE } from "../session";
export async function POST(request: Request) {
  if (!isSameOriginRequest(request.headers)) return NextResponse.json({ error: "Invalid request origin" }, { status: 403, headers: { "Cache-Control": "no-store" } });
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (token) await prisma.session.updateMany({ where: { tokenHash: sha256(token), revokedAt: null }, data: { revokedAt: new Date() } });
  const response = NextResponse.json({ ok: true });
  response.cookies.set(SESSION_COOKIE, "", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", maxAge: 0 });
  response.headers.set("Cache-Control", "no-store"); return response;
}
