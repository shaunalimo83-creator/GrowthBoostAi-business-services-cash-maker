'use client';
import { FormEvent, useState } from 'react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(''); setBusy(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, code }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Sign-in failed');
      window.location.assign('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign-in failed');
    } finally { setBusy(false); }
  }

  return (
    <main style={{ fontFamily: 'system-ui', maxWidth: 420, margin: '80px auto', padding: 24 }}>
      <h1>CEO sign-in</h1>
      <p>Sign in with your authorised CEO account and authenticator code.</p>
      <form onSubmit={submit} style={{ display: 'grid', gap: 12 }}>
        <label>Email<input autoComplete="username" type="email" required value={email} onChange={e => setEmail(e.target.value)} style={{ display: 'block', width: '100%', padding: 10 }} /></label>
        <label>Password<input autoComplete="current-password" type="password" required value={password} onChange={e => setPassword(e.target.value)} style={{ display: 'block', width: '100%', padding: 10 }} /></label>
        <label>Authenticator code<input inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} required value={code} onChange={e => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))} style={{ display: 'block', width: '100%', padding: 10 }} /></label>
        {error && <p role="alert" style={{ color: '#b42318' }}>{error}</p>}
        <button disabled={busy} type="submit" style={{ padding: 12 }}>{busy ? 'Signing in…' : 'Sign in securely'}</button>
      </form>
      <p style={{ fontSize: 12, color: '#555' }}>CEO access is restricted to provisioned accounts with MFA enrolled. Public registration is disabled.</p>
    </main>
  );
}
