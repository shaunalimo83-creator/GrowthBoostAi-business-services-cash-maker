const CONTENT = "<main style={{padding:24,whiteSpace:\"pre-wrap\"}}># Privacy policy — Trust Vault Bank\n\n> TEMPLATE — must be reviewed by qualified counsel before production use.\n\nWe process personal data under UK GDPR. Data controller: Trust Vault Bank (a separate legal entity within the group). Lawful bases, retention periods, data-subject rights (access, rectification, erasure, portability), international transfers and our Data Protection Officer contact are documented here before go-live. Customer data is never shared with other group companies without a lawful basis.\n</main>";

export default function LegalDocument() {
  return <main style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}><pre style={{ whiteSpace: "pre-wrap", fontFamily: "inherit", lineHeight: 1.6 }}>{CONTENT}</pre></main>;
}
