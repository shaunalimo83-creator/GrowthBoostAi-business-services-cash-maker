# Vibe Coding Platform

Integrated website and application builder workspace for the Business Empire ecosystem.

- Runs locally on port `3008`.
- Reuses the shared Empire user/session store and company membership records.
- CEO projects are stored in the HQ tenant and tagged to one of the seven business targets.
- Other users can create projects only in a business where they already hold a membership.
- Project records, files, runs, plan records and marketplace drafts are protected by PostgreSQL row-level security.
- The free plan permits three website projects. Paid plan codes are reserved in the schema, but checkout and plan upgrades are not active.
- Marketplace listings can be saved as drafts. Publishing, checkout, ownership transfer and seller payouts remain disabled until moderation, hosting transfer and regulated payment-provider flows are implemented and tested.
- The project workspace creates a local starter HTML file and README. AI code generation can be enabled through a server-side Vercel AI Gateway key and configured model; isolated remote sandbox execution, hosted preview, custom-domain provisioning and one-click deployment remain pending.

See `docs/vibe-coding-platform.md` for integration boundaries and deployment requirements.
