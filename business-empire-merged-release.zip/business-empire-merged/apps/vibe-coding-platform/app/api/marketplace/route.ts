import { NextResponse } from "next/server";
import { prisma } from "@empire/db";
import { NO_STORE } from "../../../lib/security";

/** Only explicitly published listing metadata is public; project files are never returned here. */
export async function GET() {
  try {
    const listings = await prisma.vibeMarketplaceListing.findMany({
      where: { status: "published" },
      orderBy: { createdAt: "desc" },
      take: 40,
      select: { id: true, title: true, description: true, priceMinor: true, currency: true, createdAt: true },
    });
    return NextResponse.json({ listings }, { headers: NO_STORE });
  } catch {
    return NextResponse.json({ error: "marketplace_unavailable" }, { status: 503, headers: NO_STORE });
  }
}
