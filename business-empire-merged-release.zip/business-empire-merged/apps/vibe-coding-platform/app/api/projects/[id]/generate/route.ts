import { NextResponse } from "next/server";
import { isSafeVibeProjectPath, isVibeBusinessSlug } from "@empire/core";
import { getVibeSession, withVibeTenant, type VibeSession } from "../../../../../lib/auth";
import { NO_STORE, rejectVibeOrigin, vibeRateLimited } from "../../../../../lib/security";

export const runtime = "nodejs";

const GATEWAY_URL = "https://ai-gateway.vercel.sh/v1/chat/completions";
const MAX_FILES = 30;
const MAX_FILE_CHARS = 250_000;
const MAX_TOTAL_CHARS = 1_500_000;
const ALLOWED_EXTENSIONS = new Set(["html", "css", "js", "jsx", "ts", "tsx", "json", "md", "txt", "svg"]);
const BLOCKED_SEGMENTS = new Set(["node_modules", ".next", ".git", "dist", "build", "vendor"]);

type GeneratedFile = { path: string; language?: string; content: string };

function parseGeneratedFiles(value: unknown): GeneratedFile[] | null {
  if (!value || typeof value !== "object" || !Array.isArray((value as { files?: unknown }).files)) return null;
  const rawFiles = (value as { files: unknown[] }).files;
  if (rawFiles.length < 1 || rawFiles.length > MAX_FILES) return null;
  const seen = new Set<string>();
  let total = 0;
  const files: GeneratedFile[] = [];
  for (const raw of rawFiles) {
    if (!raw || typeof raw !== "object") return null;
    const item = raw as Record<string, unknown>;
    const path = item.path;
    const content = item.content;
    if (!isSafeVibeProjectPath(path) || typeof content !== "string" || content.length > MAX_FILE_CHARS) return null;
    const segments = path.split("/");
    if (segments.some(segment => BLOCKED_SEGMENTS.has(segment) || segment.toLowerCase().startsWith(".env"))) return null;
    const extension = path.split(".").pop()?.toLowerCase() || "";
    if (!ALLOWED_EXTENSIONS.has(extension) || seen.has(path)) return null;
    seen.add(path); total += content.length;
    if (total > MAX_TOTAL_CHARS) return null;
    const language = typeof item.language === "string" && item.language.length <= 32 ? item.language : extension;
    files.push({ path, language, content });
  }
  if (!seen.has("index.html")) return null;
  return files;
}

function extractJson(text: string): unknown {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  return JSON.parse(cleaned);
}

type RunUpdateData = {
  status?: string;
  errorCode?: string;
  finishedAt?: Date;
  inputTokens?: number | null;
  outputTokens?: number | null;
  totalTokens?: number | null;
};

async function updateRun(session: VibeSession, target: string, projectId: string, runId: string, data: RunUpdateData) {
  if (!isVibeBusinessSlug(target)) return;
  await withVibeTenant(session, target, async ({ tx }) => {
    await tx.vibeProjectRun.updateMany({ where: { id: runId, projectId }, data });
  });
}

export async function POST(request: Request, context: { params: { id: string } }) {
  const blocked = rejectVibeOrigin(request);
  if (blocked) return blocked;
  const session = await getVibeSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const body = await request.json().catch(() => null);
  const target = body?.businessSlug;
  if (!isVibeBusinessSlug(target)) return NextResponse.json({ error: "invalid_business_target" }, { status: 400, headers: NO_STORE });
  if (await vibeRateLimited(request, "ai-generation", session.userId, false)) {
    return NextResponse.json({ error: "generation_rate_limit_reached" }, { status: 429, headers: NO_STORE });
  }

  const apiKey = process.env.AI_GATEWAY_API_KEY;
  const model = process.env.VIBE_AI_MODEL;
  if (!apiKey || !model) {
    return NextResponse.json({
      error: "generation_provider_not_configured",
      message: "AI generation is not configured yet. Add a server-side AI Gateway key and a supported provider/model identifier before generating code.",
      required: ["AI_GATEWAY_API_KEY", "VIBE_AI_MODEL"],
    }, { status: 503, headers: NO_STORE });
  }
  const maxTokens = Math.min(16000, Math.max(1000, Number.parseInt(process.env.VIBE_AI_MAX_TOKENS || "10000", 10) || 10000));

  const prepared = await withVibeTenant(session, target, async ({ tx, companyId }) => {
    const project = await tx.vibeProject.findFirst({
      where: { id: context.params.id, companyId, ownerUserId: session.userId },
      select: { id: true, name: true, prompt: true },
    });
    if (!project) return null;
    const run = await tx.vibeProjectRun.create({
      data: { projectId: project.id, status: "running", provider: "vercel-ai-gateway", model, startedAt: new Date() },
      select: { id: true },
    });
    await tx.vibeProject.update({ where: { id: project.id }, data: { status: "building" } });
    return { project, runId: run.id };
  });
  if (!prepared.ok) return NextResponse.json({ error: prepared.error }, { status: prepared.status, headers: NO_STORE });
  if (!prepared.value) return NextResponse.json({ error: "project_not_found_or_not_owned" }, { status: 404, headers: NO_STORE });

  const { project, runId } = prepared.value;
  try {
    const response = await fetch(GATEWAY_URL, {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        temperature: 0.2,
        max_tokens: maxTokens,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: "You are a senior full-stack website and application engineer. Return only valid JSON with one top-level key named files. The files value must be an array of objects with path, language and content strings. Always include index.html as a polished, responsive, accessible, self-contained website preview. You may add CSS, JS, TypeScript, TSX, JSON and README files as useful. Do not include secrets, credentials, .env files, node_modules, build output, binary files, external deployment claims or instructions to run unsafe commands. Keep the result focused on the user's brief. Do not use markdown fences." },
          { role: "user", content: `Create the website/application source files for this project. Project name: ${project.name}\nBusiness target: ${target}\nBuild brief:\n${project.prompt}\n\nReturn JSON only in this exact shape: {"files":[{"path":"index.html","language":"html","content":"..."}]}.` },
        ],
      }),
      signal: AbortSignal.timeout(90_000),
      cache: "no-store",
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      await updateRun(session, target, project.id, runId, { status: "failed", errorCode: `gateway_http_${response.status}`, finishedAt: new Date() });
      await withVibeTenant(session, target, async ({ tx, companyId }) => {
        await tx.vibeProject.updateMany({ where: { id: project.id, companyId, ownerUserId: session.userId }, data: { status: "draft" } });
      });
      return NextResponse.json({ error: "ai_gateway_request_failed", message: "The AI model provider rejected the generation request. Check the server-side gateway key, model access and usage limits." }, { status: 502, headers: NO_STORE });
    }

    const modelText = payload?.choices?.[0]?.message?.content;
    if (typeof modelText !== "string") throw new Error("model_output_missing");
    const generated = parseGeneratedFiles(extractJson(modelText));
    if (!generated) throw new Error("model_output_invalid_or_too_large");

    const usage = payload?.usage || {};
    const saved = await withVibeTenant(session, target, async ({ tx, companyId }) => {
      const ownedProject = await tx.vibeProject.findFirst({ where: { id: project.id, companyId, ownerUserId: session.userId }, select: { id: true } });
      if (!ownedProject) throw new Error("project_access_changed");
      for (const file of generated) {
        const existing = await tx.vibeProjectFile.findUnique({ where: { projectId_path: { projectId: project.id, path: file.path } }, select: { id: true } });
        if (existing) {
          await tx.vibeProjectFile.update({ where: { id: existing.id }, data: { content: file.content, language: file.language || "text", version: { increment: 1 } } });
        } else {
          await tx.vibeProjectFile.create({ data: { projectId: project.id, path: file.path, language: file.language || "text", content: file.content } });
        }
      }
      if (!generated.some(file => file.path === "README.md")) {
        const readme = `# ${project.name}\n\n## Original brief\n\n${project.prompt}\n\n## Generation status\n\nSource files generated through the configured AI Gateway. This does not mean the application has been executed, security-reviewed, hosted or deployed. Remote sandbox execution, public hosting, custom domains and marketplace publishing remain separate setup steps.\n`;
        const existingReadme = await tx.vibeProjectFile.findUnique({ where: { projectId_path: { projectId: project.id, path: "README.md" } }, select: { id: true } });
        if (existingReadme) await tx.vibeProjectFile.update({ where: { id: existingReadme.id }, data: { content: readme, language: "markdown", version: { increment: 1 } } });
        else await tx.vibeProjectFile.create({ data: { projectId: project.id, path: "README.md", language: "markdown", content: readme } });
      }
      await tx.vibeProject.update({ where: { id: project.id }, data: { status: "generated" } });
      await tx.vibeProjectRun.update({ where: { id: runId }, data: {
        status: "succeeded", finishedAt: new Date(),
        inputTokens: Number.isInteger(usage.prompt_tokens) ? usage.prompt_tokens : null,
        outputTokens: Number.isInteger(usage.completion_tokens) ? usage.completion_tokens : null,
        totalTokens: Number.isInteger(usage.total_tokens) ? usage.total_tokens : null,
      } });
      await tx.auditLog.create({ data: { actorId: session.userId, companyId, action: "vibe.project.ai_generated", subject: project.id } });
      return { fileCount: generated.length };
    });
    if (!saved.ok) throw new Error(saved.error);
    return NextResponse.json({ ok: true, fileCount: generated.length, message: `Generated ${generated.length} source files. Review and edit them before publishing or deployment.` }, { headers: NO_STORE });
  } catch (error) {
    const code = error instanceof Error ? error.message : "generation_failed";
    await updateRun(session, target, project.id, runId, { status: "failed", errorCode: code.slice(0, 120), finishedAt: new Date() });
    await withVibeTenant(session, target, async ({ tx, companyId }) => {
      await tx.vibeProject.updateMany({ where: { id: project.id, companyId, ownerUserId: session.userId }, data: { status: "draft" } });
    });
    return NextResponse.json({ error: "generation_failed", message: "The model did not return valid project files. Your original brief and existing files have been retained." }, { status: 502, headers: NO_STORE });
  }
}
