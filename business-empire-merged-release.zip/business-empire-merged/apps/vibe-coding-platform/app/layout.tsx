import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Vibe Coding Platform | Business Empire",
  description: "Build, manage and prepare websites and applications for the Business Empire ecosystem.",
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en-GB"><body style={{ margin: 0, background: "#0b1020", color: "#eef2ff", fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif" }}>{children}</body></html>;
}
