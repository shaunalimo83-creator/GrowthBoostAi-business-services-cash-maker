'use client';
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mfaCode, setMfaCode] = useState("");
  const [recoveryCode, setRecoveryCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const response = await fetch("/api/auth/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email, password, mfaCode, recoveryCode }) });
      const data = await response.json();
      if (!response.ok) { setError(data.error || "Sign-in failed."); return; }
      router.push("/projects");
    } catch { setError("The sign-in service is unavailable. Please try again."); }
    finally { setBusy(false); }
  }
  return <main style={{ maxWidth: 440, margin: "8vh auto", padding: 24 }}>
    <Link href="/" style={{ color: "#b9a5ff" }}>← Vibe Coding Platform</Link>
    <section style={{ marginTop: 28, background: "#121a30", border: "1px solid #26314d", borderRadius: 20, padding: 28 }}>
      <h1 style={{ marginTop: 0 }}>Sign in</h1>
      <p style={{ color: "#aeb9d3", lineHeight: 1.5 }}>Use your existing Business Empire account. New account registration is not opened from this platform.</p>
      <form onSubmit={submit} style={{ display: "grid", gap: 13 }}>
        <label>Email address<input type="email" required value={email} onChange={e => setEmail(e.target.value)} style={fieldStyle} autoComplete="username" /></label>
        <label>Password<input type="password" required value={password} onChange={e => setPassword(e.target.value)} style={fieldStyle} autoComplete="current-password" /></label>
        <label>Authenticator code (if enabled)<input inputMode="numeric" value={mfaCode} onChange={e => setMfaCode(e.target.value)} style={fieldStyle} placeholder="6-digit code" /></label>
        <label>Recovery code (instead of authenticator)<input value={recoveryCode} onChange={e => setRecoveryCode(e.target.value)} style={fieldStyle} placeholder="One-time recovery code" /></label>
        {error && <p role="alert" style={{ color: "#fca5a5", margin: 0 }}>{error}</p>}
        <button disabled={busy} style={primaryButton}>{busy ? "Signing in…" : "Sign in securely"}</button>
      </form>
    </section>
  </main>;
}
const fieldStyle: React.CSSProperties = { display: "block", width: "100%", boxSizing: "border-box", marginTop: 7, padding: 12, borderRadius: 9, border: "1px solid #35405d", background: "#0b1020", color: "#fff" };
const primaryButton: React.CSSProperties = { border: 0, borderRadius: 10, background: "#8b5cf6", color: "white", padding: 14, fontWeight: 700, cursor: "pointer" };
