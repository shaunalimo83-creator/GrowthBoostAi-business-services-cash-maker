# Phase 13 — customer account security centre

## Added across all seven business applications

- Functional account-recovery request page that calls the generic password-reset endpoint.
- Password-reset page that reads the one-time token from the link and submits a new password.
- Security centre now combines authenticator enrolment, recovery-code generation, password change and active-session management.
- Session centre lists only safe session metadata and supports signing out other devices.
- Customer dashboards link to account security and password recovery.
- The UI calls the Phase 12 endpoints; it does not claim that email delivery is active without a configured provider.

## Verification and limitations

- Static checks verify all seven apps contain the recovery and security pages and the relevant API routes.
- TypeScript syntax transpilation is performed for changed pages and handlers.
- Full Next.js production builds, dependency installation, live email delivery, database migration execution and end-to-end browser tests remain outstanding.
- The password-change form reuses the authenticator-code field when MFA is enabled. Customers should keep access to their authenticator app before changing credentials.
- Customer account controls remain separate from CEO HQ access and do not provide Trust Vault banking permissions.
