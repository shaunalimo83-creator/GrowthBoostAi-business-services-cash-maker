# Phase 4 — CEO session request hardening

Date: 16 November 2026

## Changes

- Added a reusable same-origin guard for browser requests that use the CEO's cookie session.
- Applied the guard to CEO login and logout POST endpoints. Missing Origin/Host headers and cross-origin requests are rejected before authentication or session mutation.
- Added focused unit tests for valid same-origin requests, absent/malformed origins, cross-origin requests, unsafe host syntax and credential-bearing origins.
- Kept the session cookie HttpOnly, SameSite=Strict and Secure in production; server-side session lookup still checks expiry, revocation, active user status and HQ CEO membership.

## Deployment requirement

The guard compares `Origin` with the request `Host`. A reverse proxy must preserve the externally requested Host header. Do not change this to trust arbitrary `X-Forwarded-Host` values. If a deployment architecture rewrites Host, configure a strict allow-list of canonical HQ origins and test it before release.

## Limits and outstanding security work

This phase does not add distributed login throttling, password reset/recovery, owner bootstrap, MFA enrolment, session cleanup jobs, device/session management, database migration, full dependency audit, penetration testing, or production deployment. A process-local rate limiter was deliberately not presented as sufficient for a multi-instance deployment. Use a shared Redis/database-backed limiter before exposing login publicly.

No credentials, owner identity, company registrations, bank accounts, payment services, domains, or live integrations were created. CEO access must remain unavailable until the first owner is provisioned securely and authenticator MFA is enrolled.
