# Phase 6 — CEO session, recovery and login protection

## Added
- Authenticated CEO session listing (`GET /api/auth/sessions`) with current-session indicator.
- Revoke a selected other session (`DELETE /api/auth/sessions`) and revoke all other sessions (`POST /api/auth/sessions/revoke-others`). The current session cannot be revoked through the selected-session endpoint; use sign-out for that.
- Ten one-time recovery codes can be generated/rotated through `POST /api/auth/recovery-codes`, requiring the current TOTP. Only hashes are stored; plaintext codes are returned once.
- Login accepts a recovery code in place of TOTP and atomically marks it used. A code has the form `XXXX-XXXX-XXXX-XXXX`.
- Shared PostgreSQL login throttling keyed by a hash of normalized email and client IP: eight attempts per 15-minute window trigger a 15-minute lock.
- `npm run auth:cleanup` removes expired/revoked session records older than the retention threshold and stale throttle records. Schedule it through the deployment platform's trusted scheduler.

## Required deployment steps
1. Install dependencies and generate Prisma Client.
2. Apply a reviewed database migration for `AuthThrottle` (`npx prisma migrate dev --schema packages/db/prisma/schema.prisma` in development; use reviewed `migrate deploy` migrations in production).
3. Configure the trusted reverse proxy to strip inbound spoofed `X-Real-IP`/`X-Forwarded-For` and set authoritative client IP headers. If this cannot be guaranteed, replace the IP source with the platform's trusted request-IP facility before production.
4. Configure rate-limit monitoring and alerting; this database throttle is a baseline, not a substitute for WAF/bot controls.
5. Schedule `npm run auth:cleanup` using the deployment scheduler.
6. Test recovery code one-time use, session revocation, multi-instance throttling and concurrent requests before release.

## Security boundaries
- Recovery codes are displayed only once and should be stored offline. Rotating codes invalidates all previous codes.
- The recovery-code endpoint requires an authenticated CEO session and a fresh TOTP.
- Session APIs operate only on the authenticated user's sessions.
- Login throttling is keyed by email and IP. Do not trust client-supplied forwarding headers unless a trusted proxy sanitizes them.
- No password reset by email is added: that requires a verified email delivery provider, single-use expiring reset tokens, delivery abuse controls and a separately tested workflow.
- No production deployment, DB migration, dependency install, typecheck, automated test, browser test or penetration test is claimed by this source package.
