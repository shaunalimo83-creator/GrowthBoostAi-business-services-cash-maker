# Phase 7 — database tenant isolation hardening

## Changes

- Corrected RLS policy column names to match Prisma's default quoted camelCase identifiers (`companyId`, `userId`, `fromCompanyId`, `toCompanyId`).
- Added `FORCE ROW LEVEL SECURITY` so table owners are subject to policies (superusers and roles with `BYPASSRLS` still bypass RLS and must never be used by the application).
- Added explicit isolation for Company, all ordinary company-owned tables, UserCompany, AuditLog and IntercompanyAuthorisation.
- Kept Session, RecoveryCode and AuthThrottle outside company-scoped RLS because they are identity/security records; access must remain narrowly filtered by user/key in the identity service.
- Added this SQL as a Prisma migration and retained it as the canonical policy file.

## Required runtime contract

Every tenant database operation must execute inside a transaction that first sets the verified tenant context with `SELECT set_config('app.company_id', $1, true)`. The third argument must be `true` so the value is transaction-local and cannot leak through pooled connections. Membership lookups must use a separate, narrowly privileged identity path and set `app.user_id` only after authenticating the user. Never accept either setting directly from an untrusted request parameter or header.

The application database role must be a non-owner role with no `SUPERUSER` or `BYPASSRLS` attribute. Migration credentials must be separate from runtime credentials. Do not run the application as the schema/table owner. Verify grants independently before production.

## Important limitations

This phase repairs and strengthens the policy SQL; it does not prove that every existing API route has been converted to transaction-scoped tenant context. The existing app routes still require a route-by-route review and migration to the runtime contract. The HQ consolidated reporting path needs its own least-privilege, audited aggregate-only role and must not bypass Trust Vault protections. Do not deploy this migration until a staging database has been backed up and the identity/membership bootstrap flow has been tested with the intended database roles.

## Staging validation checklist

1. Apply migrations to a disposable PostgreSQL database using a migration-only role.
2. Confirm all policy tables exist and RLS is both enabled and forced.
3. Connect as the real runtime role and verify it is neither owner nor `BYPASSRLS`.
4. With tenant A context, confirm tenant B rows are invisible and cross-tenant inserts/updates fail.
5. Confirm missing context returns no tenant rows and rejects writes.
6. Verify user membership queries are limited to the authenticated `app.user_id`.
7. Verify intercompany reads work for either participant but only the originating company can create/change authorisations.
8. Test all eight applications and HQ reporting before release.

## Phase 8 follow-on

Phase 8 connects verified business-app sessions to transaction-local `app.user_id` and `app.company_id` settings. See `docs/phase8-api-tenant-context.md` and migration `20261116170000_phase8_tenant_api_context`. The Phase 8 migration changes Company row visibility to membership-based discovery before tenant context is selected; it must be applied after Phase 7.
