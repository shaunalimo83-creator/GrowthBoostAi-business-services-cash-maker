# Phase 9 — customer workspaces and business control-room UI

## Delivered in source

- Added a distinct customer workspace layout for each of the seven businesses, with service tiles reflecting that business's planned product scope.
- Added consistent business control-room layouts for staff/admin workflows.
- Added clear setup-pending labels so unfinished services are not presented as live.
- Updated login pages to distinguish an unavailable authentication service (HTTP 501) from invalid credentials. The page tells the user when sign-in is not connected rather than incorrectly claiming their password was wrong.
- Preserved the shared tenant API gate and fail-closed protected data endpoints from Phase 8.

## Not delivered / not live

- No customer registration, email verification, password reset, identity-provider integration, or business-app session creation is live.
- Business-app `/api/auth/login` endpoints intentionally return HTTP 501 until a managed identity provider and MFA policy are configured. No password is accepted or stored by these endpoints.
- Customer and admin dashboards are presentation scaffolds. They do not show live orders, balances, documents, portfolios, bookings, or analytics.
- Protected summary, export and admin APIs continue to fail closed until their authorised data contracts and persistence services are implemented.
- Trust Vault is not an authorised bank; Stock Market Express is not connected to a live broker. Those boundaries remain unchanged.

## Required next steps before activation

1. Select and configure a managed identity provider with verified-email enrolment, MFA, rate limits, secure session rotation and account recovery.
2. Define separate customer and workforce identity policies; require stronger MFA for staff/admin access.
3. Implement invitations or verified registration and provision company membership only through a trusted server-side workflow.
4. Implement customer-owned data contracts and route handlers within the Phase 8 `withTenantSession` transaction boundary.
5. Add per-business integration tests, PostgreSQL RLS tests, browser tests, accessibility checks and a security review.
6. Configure provider credentials, secrets, domains, TLS, monitoring, backups and production deployment only after staging sign-off.

## Verification

`node scripts/preflight.mjs` now checks the eight workspaces, Phase 8 tenant gates, seven business dashboard/control-room pages, their honest setup-pending disclosures and login-service-unavailable messaging. This remains a structural source check; it does not prove runtime security or production readiness.
