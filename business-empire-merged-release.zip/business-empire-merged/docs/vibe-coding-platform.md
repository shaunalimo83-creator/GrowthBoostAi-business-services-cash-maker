# Phase 14 — Vibe Coding Platform integration

## Position in the group

The Vibe Coding Platform is a shared technology service, not an eighth portfolio company. It runs as `apps/vibe-coding-platform` on local port `3008` and is linked from all seven business home pages/customer dashboards and CEO Headquarters. Set `NEXT_PUBLIC_VIBE_PLATFORM_URL` to its deployed HTTPS origin; the local default is `http://localhost:3008`.

## Included in this source phase

- Existing Business Empire account sign-in; there is no separate public signup or user store.
- Eight-hour HttpOnly, Secure-in-production, SameSite=Strict session cookie; passwords are verified against the shared user store and MFA is checked when enrolled.
- CEO HQ users must have the HQ `ceo` membership and verified TOTP MFA. Their Vibe projects are stored in the HQ tenant and tagged to one of the seven business targets.
- Other users can create and edit projects only for business tenants where they already have a customer, staff or admin membership. The selected business is re-checked inside the project transaction; request-supplied company IDs and roles are never trusted.
- Project creation saves the original brief, a starter `index.html` and a `README.md`. HTML is escaped when inserting the supplied project name and prompt into the starter page.
- The editor saves files with version counters and an audit record. The HTML preview is rendered in a browser sandboxed iframe; it is local to the user's editor and is not a public deployment.
- The free plan is enforced at three website projects per user account across all seven business targets; an account-wide entitlement counter is incremented atomically so parallel requests cannot bypass the limit. The schema reserves Starter, Pro, Business and Unlimited plan codes, but paid plan changes are not enabled.
- Sellers can save private draft marketplace listings with an asking price stored as integer pence. Public API reads are limited by RLS to records marked `published`.

## Explicitly not live yet

The generation endpoint is wired to the Vercel AI Gateway OpenAI-compatible Chat Completions endpoint. It runs only when server-side `AI_GATEWAY_API_KEY` and `VIBE_AI_MODEL` values are configured. Model identifiers use the gateway's `provider/model` format. The endpoint validates the returned JSON, file paths, file count, extensions and output size before storing generated source; it records run status and token usage. No API key is included in this source archive, and the generation path has not been runtime-tested against a configured gateway.

Do not describe the following as connected or operational:

1. AI generation until a real gateway key/model is provisioned and staging tests pass; multi-model routing and per-user billing/quotas are not configured by this source alone.
2. Isolated remote code execution, build logs, dependency installation, hosted preview URLs or live app hosting. The current preview is a local sandboxed HTML iframe only.
3. Custom-domain registration, DNS, TLS, public deployment or one-click deployment.
4. Paid plan checkout, subscription upgrades, proration or cancellation.
5. Marketplace moderation/publishing, buyer checkout, ownership transfer, refunds, disputes, chargebacks or seller payouts.

These capabilities require real provider accounts, server-side credentials, enforced usage and cost budgets, sandbox isolation, output scanning, approval gates and integration tests. Marketplace payments must use an appropriate regulated PSP/marketplace product with seller verification, correct proceeds allocation, transparent fees, payout tracking and dispute handling. Do not claim escrow or guaranteed loss prevention unless the provider contract explicitly supports it.

## Database and security

Apply `packages/db/prisma/migrations/20261117170000_phase14_vibe_coding_platform/migration.sql` only after reviewing it against the target PostgreSQL environment. It adds:

- `VibeProject` — owner, tenant, target business, prompt and lifecycle status.
- `VibeProjectFile` — tenant-owned source files with version counters.
- `VibeProjectRun` — generation run metadata, provider/model, status and token usage.
- `VibePlanSubscription` — account-wide user plan entitlement and website usage counter.
- `VibeMarketplaceListing` — private drafts and explicitly published listing metadata.

All five tables have forced row-level security. Project, file and run records are tenant-scoped; plan entitlements are user-scoped across the account; marketplace listing metadata is public only when status is `published`, while draft rows are owner-scoped. Runtime database roles must not own these tables and must not have `SUPERUSER` or `BYPASSRLS`. Verify the policies with real PostgreSQL tests using separate users and company memberships before enabling customer traffic.

## Local development

```bash
npm install
cp .env.example .env
# Configure DATABASE_URL and DIRECT_URL, then apply reviewed migrations.
npx prisma generate --schema packages/db/prisma/schema.prisma
npm run vibe:dev
```

Open `http://localhost:3008`. Sign in with an existing verified Business Empire user account. CEO access requires an HQ CEO account with MFA enrolled. Ordinary users see only business memberships already assigned to their account.

Set `AI_GATEWAY_API_KEY` and `VIBE_AI_MODEL` in the server-side secret store to enable source generation. Use a supported model identifier such as `openai/gpt-6.1-sol` only after checking current model access and billing in your gateway account. Run `npm run preflight`, `npm run security:rls-check`, `npm run release:check`, `npm test`, `npm run typecheck` and the Prisma validation/build checks before staging. Static checks do not replace database migration execution, RLS runtime tests, type-checking, builds, browser tests, penetration testing or deployment acceptance.

## Follow-on implementation order

1. Complete PostgreSQL migration, tenant-isolation tests and app build/type checks.
2. Provision and verify the AI Gateway key/model in staging; add per-user quotas, spend caps, secret isolation and code/output scanning, then integrate an isolated sandbox.
3. Add hosted preview URLs with expiry, network egress restrictions, resource limits and abuse controls.
4. Add custom-domain verification, DNS/TLS automation and deployment rollback.
5. Add payment-provider-backed subscription upgrades and enforce paid entitlements from verified webhooks.
6. Add marketplace moderation, buyer checkout, transfer checks, refunds/disputes and seller payout reconciliation.
