/**
 * Browser-origin guard for cookie-authenticated state-changing endpoints.
 * Requires an Origin header matching the request Host. Configure trusted
 * reverse proxies to preserve the public Host header; never trust arbitrary
 * client-supplied forwarded-host values here.
 */
export function isSameOriginRequest(headers: Pick<Headers, "get">): boolean {
  const origin = headers.get("origin");
  const host = headers.get("host");
  if (!origin || !host) return false;
  try {
    const parsed = new URL(origin);
    if (parsed.username || parsed.password || parsed.pathname !== "/" || parsed.search || parsed.hash) return false;
    const requestHost = host.trim().toLowerCase();
    if (!requestHost || /[\s/@\\]/.test(requestHost)) return false;
    return parsed.host.toLowerCase() === requestHost &&
      (parsed.protocol === "https:" || parsed.protocol === "http:");
  } catch {
    return false;
  }
}
