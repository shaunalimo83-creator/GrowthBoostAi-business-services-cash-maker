-- Ensure the seven tenant records exist before customer registration is enabled.
INSERT INTO "Company" ("id", "slug", "name", "currency", "createdAt") VALUES
  (gen_random_uuid()::text, 'growthboost', 'GrowthBoost AI', 'GBP', NOW()),
  (gen_random_uuid()::text, 'ai-magazine', 'AI Magazine & Comic Book Studio', 'GBP', NOW()),
  (gen_random_uuid()::text, 'trust-vault', 'Trust Vault Bank', 'GBP', NOW()),
  (gen_random_uuid()::text, 'stock-express', 'Stock Market Express', 'GBP', NOW()),
  (gen_random_uuid()::text, 'real-estate', 'Real Estate Master Developments', 'GBP', NOW()),
  (gen_random_uuid()::text, 'supergpu', 'SUPERGPU UNIVERSAL', 'GBP', NOW()),
  (gen_random_uuid()::text, 'dailyaccess', 'DailyAccess', 'GBP', NOW())
ON CONFLICT ("slug") DO NOTHING;

-- Phase 10: allow lookup of the seven public business tenant records during
-- registration. Only public company metadata is exposed; all tenant-owned rows
-- remain protected by their company_id policies. Membership writes still
-- require app.user_id and the company ID must be selected by the server route.
DROP POLICY IF EXISTS company_tenant_isolation ON "Company";
CREATE POLICY company_tenant_isolation ON "Company"
  FOR SELECT
  USING (
    "id" = NULLIF(current_setting('app.company_id', true), '')
    OR EXISTS (
      SELECT 1 FROM "UserCompany" membership
      WHERE membership."companyId" = "Company"."id"
        AND membership."userId" = NULLIF(current_setting('app.user_id', true), '')
    )
    OR "slug" IN ('growthboost','ai-magazine','trust-vault','stock-express','real-estate','supergpu','dailyaccess')
  );
CREATE POLICY company_tenant_insert_update_delete_block ON "Company"
  FOR ALL
  USING ("id" = NULLIF(current_setting('app.company_id', true), ''))
  WITH CHECK ("id" = NULLIF(current_setting('app.company_id', true), ''));
