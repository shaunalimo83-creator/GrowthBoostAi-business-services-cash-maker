import { beforeEach, describe, expect, it, vi } from "vitest";

const { prismaMock, txMock } = vi.hoisted(() => {
  const tx = {
    $queryRaw: vi.fn(),
    userCompany: { findFirst: vi.fn() },
  };
  return {
    txMock: tx,
    prismaMock: {
      session: { findUnique: vi.fn() },
      $transaction: vi.fn(async (callback: (client: typeof tx) => Promise<unknown>) => callback(tx)),
    },
  };
});

vi.mock("./client", () => ({ prisma: prismaMock }));
import { withTenantSession } from "./tenant";

const validSession = {
  id: "session-1",
  userId: "user-1",
  expiresAt: new Date(Date.now() + 60_000),
  revokedAt: null,
  user: { isActive: true },
};

describe("withTenantSession", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    prismaMock.session.findUnique.mockResolvedValue(validSession);
    txMock.$queryRaw.mockResolvedValue(1);
  });

  it("fails closed when there is no session token", async () => {
    const run = vi.fn();
    const result = await withTenantSession({ token: null, companySlug: "growthboost", allowedRoles: ["customer"] }, run);
    expect(result).toEqual({ ok: false, status: 401, error: "authentication_required" });
    expect(prismaMock.session.findUnique).not.toHaveBeenCalled();
    expect(run).not.toHaveBeenCalled();
  });

  it("rejects revoked, expired or inactive sessions before opening tenant work", async () => {
    prismaMock.session.findUnique.mockResolvedValue({ ...validSession, revokedAt: new Date() });
    const result = await withTenantSession({ token: "x".repeat(40), companySlug: "growthboost", allowedRoles: ["customer"] }, async () => "never");
    expect(result).toEqual({ ok: false, status: 401, error: "authentication_required" });
    expect(prismaMock.$transaction).not.toHaveBeenCalled();
  });

  it("denies a user without a membership in the requested business", async () => {
    txMock.userCompany.findFirst.mockResolvedValue(null);
    const run = vi.fn();
    const result = await withTenantSession({ token: "x".repeat(40), companySlug: "trust-vault", allowedRoles: ["customer"] }, run);
    expect(result).toEqual({ ok: false, status: 403, error: "tenant_access_denied" });
    expect(txMock.$queryRaw).toHaveBeenCalledTimes(1);
    expect(run).not.toHaveBeenCalled();
  });

  it("sets user and company scope inside the same transaction before running tenant work", async () => {
    txMock.userCompany.findFirst.mockResolvedValue({ companyId: "company-a", role: "admin", company: { slug: "growthboost" } });
    const run = vi.fn(async ({ companyId }: { companyId: string }) => ({ companyId }));
    const result = await withTenantSession({ token: "x".repeat(40), companySlug: "growthboost", allowedRoles: ["admin"] }, run);
    expect(result).toMatchObject({ ok: true, value: { companyId: "company-a" }, companyId: "company-a", role: "admin" });
    expect(txMock.$queryRaw).toHaveBeenCalledTimes(2);
    expect(run).toHaveBeenCalledWith(expect.objectContaining({ userId: "user-1", companyId: "company-a", companySlug: "growthboost", role: "admin" }));
  });

  it("does not let an admin role satisfy a customer-only endpoint", async () => {
    txMock.userCompany.findFirst.mockResolvedValue({ companyId: "company-a", role: "admin", company: { slug: "growthboost" } });
    const run = vi.fn();
    const result = await withTenantSession({ token: "x".repeat(40), companySlug: "growthboost", allowedRoles: ["customer"] }, run);
    expect(result).toEqual({ ok: false, status: 403, error: "tenant_access_denied" });
    expect(run).not.toHaveBeenCalled();
  });
});
