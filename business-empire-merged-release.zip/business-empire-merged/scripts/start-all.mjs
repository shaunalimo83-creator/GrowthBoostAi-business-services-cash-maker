import { spawn } from 'node:child_process';

const apps = [
  ['hq', 3000], ['growthboost', 3001], ['ai-magazine', 3002],
  ['trust-vault', 3003], ['stock-express', 3004],
  ['real-estate', 3005], ['supergpu', 3006], ['dailyaccess', 3007],
  ['vibe-coding-platform', 3008],
];
const children = [];
let stopping = false;

function stop(signal = 'SIGTERM') {
  if (stopping) return;
  stopping = true;
  for (const child of children) if (!child.killed) child.kill(signal);
}
process.on('SIGINT', () => stop('SIGINT'));
process.on('SIGTERM', () => stop('SIGTERM'));

for (const [app, port] of apps) {
  const child = spawn('npm', ['run', 'dev', '--workspace', `@empire/app-${app}`], {
    stdio: 'inherit',
    env: { ...process.env, PORT: String(port) },
    shell: process.platform === 'win32',
  });
  children.push(child);
  child.on('exit', (code, signal) => {
    if (!stopping && code !== 0) {
      console.error(`${app} stopped unexpectedly (code=${code}, signal=${signal ?? 'none'}). Stopping the stack.`);
      stop();
    }
  });
}
console.log('Started all nine development workspaces:');
for (const [app, port] of apps) console.log(`  ${app}: http://localhost:${port}`);
console.log('Press Ctrl+C to stop all applications.');
