# Empire Backend — Unified API for the 7-Business Ecosystem + CEO HQ

A runnable Node.js + Express + SQLite backend that implements **every endpoint the
Empire frontends call** (seven business apps + HQ dashboard), replacing the
deliberate `503 tenant_endpoint_not_implemented` / `LEDGER_NOT_CONFIGURED` stubs
with real, working data contracts.

- **Company scoping**: every request resolves to one company via the
  `x-company-slug` header (or the Host subdomain). Sessions, data and audit
  rows are always scoped to that fixed company — the client can never choose
  a company or role from the request.
- **Reporting currency**: GBP (minor units, `*_minor` integers) everywhere.
- **Security posture kept from the source repo**: scrypt password hashing,
  httpOnly SameSite=Strict session cookies, server-side session revocation,
  database-backed throttling on auth actions, same-origin checks on mutations,
  TOTP MFA (RFC 6238, ±1 step window), MFA secrets AES-256-GCM encrypted at
  rest, hashed one-time recovery codes, generic anti-enumeration responses,
  double-entry ledger with balance validation, audit logging.

## Quick start

```bash
npm install
npm run seed     # creates data/empire.db with demo companies, ledger + CEO account
npm start        # http://localhost:4000
```

Demo CEO login (HQ): `ceo@hq.example.com` / `Change-me-ceo-2026!`

Copy `.env.example` to `.env` to configure port, registration gate, session
lifetime, MFA encryption key and CORS origins.

## Selecting a company

Every request must carry `x-company-slug: <slug>`:

`growthboost` · `ai-magazine` · `trust-vault` · `stock-express` · `real-estate` · `supergpu` · `dailyaccess` · `hq`

Alternatively, point the frontend at a subdomain host
(`growthboost.localhost:4000`) and the backend resolves the company from it.

## Universal Business Group integration (directory, workspaces, live-service gate)

The `Universal Business Group` directory module lives in `src/config/businesses.js`
and is served over these endpoints:

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/businesses` | public | Full directory (7 businesses in canonical order) + HQ config |
| GET | `/api/businesses/:businessId` | public | Single business record |
| GET | `/api/businesses/:businessId/tools` | public | Tool list for one business |
| POST | `/api/workspaces` | session | Create a per-user workspace for a business (409 on duplicate) |
| GET | `/api/workspaces` | session | List the signed-in user's workspaces |
| GET | `/api/hq/config` | public | Headquarters capabilities/settings + SECURITY_SETTINGS |
| GET | `/api/hq/live-services` | ceo | Live-service gate status incl. which credentials are missing |

**Live-service safety boundary.** The integration snippet wrote `real tru` for
`liveBanking`, `livePayments`, `livePayouts`, `paidThirdPartyServices` and
`automaticProductionChanges`. That is invalid syntax, and if it meant `true`, it
would fake regulated capabilities as operational — so each is implemented as an
environment flag that defaults to **false** and only activates when the matching
real provider credentials are present in the environment:

| Capability | Flag | Also requires |
|---|---|---|
| Live banking (Trust Vault) | `LIVE_BANKING_ENABLED` | `BANK_PARTNER_API_KEY` from an appropriately authorised banking partner |
| Live payments | `LIVE_PAYMENTS_ENABLED` | `PSP_SECRET_KEY` (e.g. a Stripe/Adyen merchant account per legal entity) |
| Live payouts | `LIVE_PAYOUTS_ENABLED` | `PAYOUTS_API_KEY` with completed KYB/onboarding |
| Paid third-party services | `PAID_THIRD_PARTY_ENABLED` | `THIRD_PARTY_BILLING_KEY` |
| Automatic production changes | `AUTOMATIC_PRODUCTION_CHANGES` | `PROD_CHANGE_TOKEN` **and** `PROD_CHANGE_APPROVED=true` |

Trust Vault stays `restricted: true` and `liveBankingEnabled: false` — it is not
an authorised bank, and no capability here is enabled by default.

## Endpoints (all match the fetch() calls in the seven apps + HQ)

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/api/health` | public | Liveness + resolved company |
| POST | `/api/auth/register` | public | Fixed-company customer registration (gated by `CUSTOMER_REGISTRATION_ENABLED`) |
| POST | `/api/auth/login` | public | Sign-in with optional `mfaCode` / `recoveryCode` |
| POST | `/api/auth/logout` | session | Revoke current session, clear cookie |
| GET | `/api/auth/me` | session | Current user, role, company, expiry |
| POST | `/api/auth/mfa/start` | session | Generate TOTP secret + `otpauth://` URI |
| POST | `/api/auth/mfa/confirm` | session | Verify code, enroll MFA, return one-time recovery codes |
| POST | `/api/auth/recovery-codes` | session | Regenerate recovery codes |
| POST | `/api/auth/password/change` | session | Authenticated password change (revokes other sessions) |
| POST | `/api/auth/password-reset/request` | public | Generic anti-enumeration reset request |
| POST | `/api/auth/password-reset/confirm` | public | Consume token, set password, revoke sessions |
| POST | `/api/auth/email/verification/request` | public | Request verification email token |
| POST | `/api/auth/email/verification/confirm` | public | Confirm verification token |
| GET | `/api/auth/sessions` | session | List active sessions (current flagged) |
| DELETE | `/api/auth/sessions` | session | Revoke one (`sessionId`) or all other sessions |
| POST | `/api/auth/sessions/revoke-others` | session | HQ convenience alias |
| POST | `/api/enquiry` | public | Marketing enquiry, stored per company |
| GET | `/api/me/summary` | customer+ | Subscriptions + recent payments + totals |
| GET | `/api/me/export` | session | GDPR-style JSON data export (download) |
| GET | `/api/admin/summary` | staff/admin/ceo | Customer counts, revenue/expenses, recent enquiries |
| GET | `/api/consolidated` | **ceo** @ HQ | Per-business P&L, cash balances, customers, group totals, double-entry balance check |

## Example

```bash
# Sign in to GrowthBoost
curl -s -X POST localhost:4000/api/auth/login -H 'Content-Type: application/json' \
  -H 'x-company-slug: growthboost' -c cookies.txt \
  -d '{"email":"customer1@growthboost.example.com","password":"<set via register>"}'

# CEO consolidated view (uses seeded CEO account)
curl -s -X POST localhost:4000/api/auth/login -H 'Content-Type: application/json' \
  -H 'x-company-slug: hq' -c ceo.txt \
  -d '{"email":"ceo@hq.example.com","password":"Change-me-ceo-2026!"}'
curl -s localhost:4000/api/consolidated -H 'x-company-slug: hq' -b ceo.txt
```

## Connecting the Next.js frontends

The frontends call these APIs with **relative** paths, so put the backend behind
each app's dev server (Next rewrites) or a reverse proxy:

```js
// next.config.mjs of each app
async rewrites() {
  return [{ source: '/api/:path*', destination: 'http://localhost:4000/api/:path*' }];
}
```

Then set `x-company-slug` via a middleware in each app
(`next/server` middleware that forwards `x-company-slug: '<fixed-slug>'`),
or run each app on a `<slug>.localhost` hostname.

## Honest limitations (kept from the source repo's discipline)

- No live payment processing, broker integration, market data or email
  delivery. While `DEV_EXPOSE_TOKENS=true`, verification/reset tokens are
  returned in API responses for local testing — set it to `false` and wire an
  email webhook before anything public.
- Registration defaults per `.env.example`; keep it disabled until verified
  email + abuse controls are live.
- Tenant isolation here is app-level (company-scoped queries + fixed company
  per request), not PostgreSQL RLS. For production, port the schema to the
  repo's Prisma migration with forced RLS.
- Trust Vault is not a bank; Stock Market Express is paper-only; no regulated
  capability is simulated as operational.
