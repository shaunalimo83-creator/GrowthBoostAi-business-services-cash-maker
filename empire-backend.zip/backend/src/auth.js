'use strict';
/* Company resolution + session auth middleware + rate limiting. */
const { sha256 } = require('./util');

const SESSION_COOKIE = (slug) => `empire_${slug}_session`;
const NO_STORE = { 'Cache-Control': 'no-store' };

function json(res, status, body, headers = {}) {
  const h = { ...NO_STORE, ...headers };
  if (status === 401 || status === 403 || status === 429) h['Cache-Control'] = 'no-store';
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...h });
  res.end(JSON.stringify(body));
}

function readCookies(req) {
  const out = {};
  const raw = req.headers.cookie || '';
  for (const part of raw.split(';')) {
    const i = part.indexOf('=');
    if (i > -1) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

/** Same-origin check for mutations (Origin header must be absent or match Host). */
function isSameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try {
    const host = req.headers.host;
    return new URL(origin).host === host;
  } catch { return false; }
}

function rateLimited(store, key, { limit = 8, windowMs = 15 * 60 * 1000 } = {}) {
  const now = Date.now();
  const rec = store.get(key);
  if (rec?.lockedUntil && rec.lockedUntil > now) return true;
  const attempts = (!rec || now - rec.windowStartedAt >= windowMs) ? 1 : rec.attempts + 1;
  const lockedUntil = attempts >= limit ? now + windowMs : null;
  store.set(key, { attempts, windowStartedAt: (!rec || now - rec.windowStartedAt >= windowMs) ? now : rec.windowStartedAt, lockedUntil });
  return Boolean(lockedUntil);
}

/** Resolve which company this request is for: x-company-slug header or host subdomain. */
function resolveCompany(db, req) {
  let slug = req.headers['x-company-slug'];
  if (!slug) {
    const host = String(req.headers.host || '').split(':')[0];
    const sub = host.split('.')[0];
    if (host.includes('.') && sub && sub !== 'localhost' && sub !== 'www') slug = sub;
  }
  if (!slug) slug = process.env.DEFAULT_COMPANY_SLUG || 'growthboost';
  return db.prepare('SELECT * FROM companies WHERE slug = ?').get(slug) || null;
}

/** Require a valid session cookie scoped to the given company; returns session+user+membership or null. */
function requireSession(db, req, company, roles) {
  const cookies = readCookies(req);
  const token = cookies[SESSION_COOKIE(company.slug)];
  if (!token) return { error: () => json(null, 401, { error: 'unauthorised' }) };
  const session = db.prepare(
    `SELECT s.*, uc.role AS role, u.email, u.id AS user_id, u.mfa_enrolled
     FROM sessions s JOIN users u ON u.id = s.user_id
     JOIN user_companies uc ON uc.user_id = u.id AND uc.company_id = s.company_id
     WHERE s.token_hash = ? AND s.revoked_at IS NULL AND s.expires_at > ?`
  ).get(sha256(token), new Date().toISOString());
  if (!session || session.company_id !== company.id) return { error: () => json(null, 401, { error: 'unauthorised' }) };
  if (roles && !roles.includes(session.role)) return { error: () => json(null, 403, { error: 'forbidden_role' }) };
  return { session };
}

function audit(db, actorId, companyId, action, subject) {
  db.prepare('INSERT INTO audit_logs (id, actor_id, company_id, action, subject, created_at) VALUES (?,?,?,?,?,?)')
    .run(require('crypto').randomUUID(), actorId || null, companyId || null, action, subject || null, new Date().toISOString());
}

module.exports = { SESSION_COOKIE, NO_STORE, json, readCookies, isSameOrigin, rateLimited, resolveCompany, requireSession, audit };
