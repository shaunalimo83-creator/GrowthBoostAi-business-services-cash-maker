'use strict';
/* UNIVERSAL BUSINESS GROUP — directory, headquarters and security configuration.
 * Module form of the user-supplied integration spec, adapted to this backend:
 *  - the seven businesses are kept in the order the user listed;
 *  - LIVE_SERVICE_SETTINGS is a safety boundary, NOT a literal paste: each
 *    "real" capability is an environment flag that defaults to FALSE and only
 *    activates when real provider credentials are configured (see /src/live-services.js).
 */

const BUSINESS_DIRECTORY = [
  {
    id: 'growthboost-ai',
    name: 'GrowthBoost AI',
    slug: 'growthboost',
    tools: [
      'AI Business Builder', 'Advertising Campaign Builder', 'Social Media Content Creator',
      'Business Growth Planner', 'AI Business Importer', 'AI Staff Manager',
      'Marketing Results Tracker', 'Customer Help Centre', 'Fraud and Scam Protection',
      'Contracts and Agreements', 'Business Backup and Recovery', 'Business Integrations',
      'Business Academy', 'International Trade Assistant', 'Customer Satisfaction Monitor',
      'AI Daily Business Manager', 'Customer Dashboard',
    ],
  },
  {
    id: 'dailyaccess',
    name: 'DailyAccess',
    slug: 'dailyaccess',
    tools: [
      'Accessible Service Directory', 'Service Provider Profiles', 'Appointment Booking',
      'Customer Support', 'Accessibility Preferences', 'Notifications',
      'Customer Feedback', 'Customer Dashboard',
    ],
  },
  {
    id: 'trust-vault-bank',
    name: 'Trust Vault Bank',
    slug: 'trust-vault',
    tools: [
      'Financial Information', 'Financial Education', 'Secure Customer Enquiries',
      'Identity Verification Workflow', 'Compliance Management', 'Customer Dashboard',
    ],
    restricted: true,
    liveBankingEnabled: false, // hard-coded false; no authorised banking partner is configured
  },
  {
    id: 'ai-magazine-comic-studio',
    name: 'AI Magazine & Comic Book Studio',
    slug: 'ai-magazine',
    tools: [
      'AI Magazine Creator', 'AI Comic Book Creator', 'AI Article Writer', 'AI Image Generator',
      'Article Illustrations', 'Comic Page Generator', 'Comic Panel Generator', 'Character Creator',
      'Character Consistency', 'Magazine Cover Designer', 'Comic Cover Designer', 'Page Layout Editor',
      'Image Library', 'Publication Preview', 'PDF Export', 'Creator Portfolio', 'Creator Shop',
      'Creator Analytics', 'Collaboration Tools', 'Customer Dashboard',
    ],
  },
  {
    id: 'website-builder-marketplace',
    name: 'Website Builder Marketplace',
    slug: 'website-builder-marketplace',
    tools: [
      'AI Website Builder', 'Website Templates', 'Page Editor', 'Component Library',
      'Website Preview', 'Marketplace Listings', 'Seller Profiles', 'Accessibility Checker',
      'Domain Management', 'Customer Dashboard',
    ],
  },
  {
    id: 'business-empire-ceo-simulator',
    name: 'Business Empire: CEO Simulator',
    slug: 'business-empire-ceo-simulator',
    tools: [
      'Business Simulator', 'Company Setup', 'Business Strategy Planner', 'Finance Simulator',
      'Team Management', 'Business Missions', 'Achievements', 'Learning Centre',
      'Progress Analytics', 'Customer Dashboard',
    ],
  },
  {
    id: 'supergpu-universal',
    name: 'SuperGPU Universal',
    slug: 'supergpu',
    tools: [
      'GPU Catalogue', 'GPU Comparison', 'Computing Resource Planner', 'Hardware Compatibility Checker',
      'Resource Monitoring', 'Provider Directory', 'Technical Support', 'Customer Dashboard',
    ],
  },
];

const HEADQUARTERS = {
  name: 'Universal Business Group',
  dashboard: 'universal-business-group-hq',
  capabilities: [
    'Central Business Dashboard', 'Seven Business Workspaces', 'Universal Customer Accounts',
    'Business Management', 'Staff and Team Management', 'Customer Support', 'Notifications',
    'Analytics', 'Document Management', 'Integration Management', 'Security and Permissions',
    'Audit Logs', 'Data Backup', 'Customer Data Export', 'Account Recovery',
  ],
  settings: {
    sharedLogin: true,
    separateBusinessWorkspaces: true,
    isolateCustomerData: true,
    roleBasedPermissions: true,
    auditLogging: true,
    requireAuthentication: true,
  },
};

const SECURITY_SETTINGS = {
  authenticationRequired: true,
  customerDataIsolation: true,
  businessDataIsolation: true,
  roleBasedAccess: true,
  auditLogging: true,
  secureFileStorage: true,
  privateCustomerDocuments: true,
  preventUnauthorisedAccess: true,
};

/**
 * Live-service gate. The user's snippet wrote `real tru` for every capability;
 * that syntax is invalid and, if it meant `true`, would fake regulated
 * capabilities as operational. Instead each is an env flag, default FALSE,
 * which only becomes true when BOTH the flag is set AND the matching real
 * provider credentials exist in the environment.
 */
const LIVE_SERVICE_SETTINGS = {
  liveBanking: {
    enabled: process.env.LIVE_BANKING_ENABLED === 'true',
    requires: 'An appropriately authorised banking partner (Trust Vault is NOT an authorised bank). Credentials: BANK_PARTNER_API_KEY.',
    credentialsPresent: Boolean(process.env.BANK_PARTNER_API_KEY),
  },
  livePayments: {
    enabled: process.env.LIVE_PAYMENTS_ENABLED === 'true',
    requires: 'A payment service provider merchant account per legal entity. Credentials: PSP_SECRET_KEY.',
    credentialsPresent: Boolean(process.env.PSP_SECRET_KEY),
  },
  livePayouts: {
    enabled: process.env.LIVE_PAYOUTS_ENABLED === 'true',
    requires: 'A payouts provider with completed KYB/onboarding. Credentials: PAYOUTS_API_KEY.',
    credentialsPresent: Boolean(process.env.PAYOUTS_API_KEY),
  },
  paidThirdPartyServices: {
    enabled: process.env.PAID_THIRD_PARTY_ENABLED === 'true',
    requires: 'Signed contracts and billing for each paid provider. Credentials: THIRD_PARTY_BILLING_KEY.',
    credentialsPresent: Boolean(process.env.THIRD_PARTY_BILLING_KEY),
  },
  automaticProductionChanges: {
    enabled: process.env.AUTOMATIC_PRODUCTION_CHANGES === 'true',
    requires: 'Approved change-management process with rollback and human sign-off. Credentials: PROD_CHANGE_TOKEN + PROD_CHANGE_APPROVED=true.',
    credentialsPresent: Boolean(process.env.PROD_CHANGE_TOKEN) && process.env.PROD_CHANGE_APPROVED === 'true',
  },
};
// A capability is live ONLY when flag AND credentials are both present.
for (const cap of Object.values(LIVE_SERVICE_SETTINGS)) cap.enabled = cap.enabled && cap.credentialsPresent;

function getBusiness(businessId) {
  return BUSINESS_DIRECTORY.find(b => b.id === businessId) || null;
}
function getAllBusinesses() {
  return BUSINESS_DIRECTORY;
}
function getBusinessTools(businessId) {
  const business = getBusiness(businessId);
  if (!business) { const e = new Error('Business not found.'); e.status = 404; throw e; }
  return business.tools;
}
function createWorkspaceConfiguration({ userId, businessId, displayName }) {
  if (!userId) { const e = new Error('A signed-in customer is required.'); e.status = 401; throw e; }
  const business = getBusiness(businessId);
  if (!business) { const e = new Error('Business not found.'); e.status = 404; throw e; }
  return {
    userId,
    businessId,
    businessName: business.name,
    displayName: displayName || 'My Workspace',
    status: 'active',
    settings: {},
    createdAt: new Date().toISOString(),
  };
}

module.exports = {
  BUSINESS_DIRECTORY, HEADQUARTERS, SECURITY_SETTINGS, LIVE_SERVICE_SETTINGS,
  getBusiness, getAllBusinesses, getBusinessTools, createWorkspaceConfiguration,
};
