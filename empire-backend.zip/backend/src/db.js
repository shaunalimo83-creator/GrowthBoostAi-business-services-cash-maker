'use strict';
/* Empire backend — SQLite schema + demo seed.
 * One shared database with company-scoped rows (app-level tenant isolation).
 */
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const { hashPassword, encryptMfaSecret } = require('./util');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'empire.db');

function open() {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  const db = new Database(DB_PATH);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  migrate(db);
  return db;
}

function migrate(db) {
  db.exec(`
CREATE TABLE IF NOT EXISTS companies (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  is_hq INTEGER NOT NULL DEFAULT 0,
  restricted INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  mfa_enrolled INTEGER NOT NULL DEFAULT 0,
  mfa_secret_enc TEXT,
  email_verified_at TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user_companies (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('customer','staff','admin','ceo')),
  created_at TEXT NOT NULL,
  UNIQUE (user_id, company_id)
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  company_id TEXT REFERENCES companies(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  revoked_at TEXT
);
CREATE TABLE IF NOT EXISTS recovery_codes (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code_hash TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS email_verification_tokens (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS auth_throttle (
  key TEXT PRIMARY KEY,
  attempts INTEGER NOT NULL DEFAULT 0,
  window_started_at TEXT NOT NULL,
  locked_until TEXT
);
CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT,
  company_id TEXT,
  action TEXT NOT NULL,
  subject TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS workspaces (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id TEXT NOT NULL,
  company_id TEXT REFERENCES companies(id) ON DELETE SET NULL,
  display_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  settings TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  UNIQUE (user_id, business_id)
);
CREATE TABLE IF NOT EXISTS enquiries (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  name TEXT,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  price_minor INTEGER NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'GBP',
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS subscriptions (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  customer_id TEXT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  product_id TEXT REFERENCES products(id) ON DELETE SET NULL,
  plan TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  amount_minor INTEGER NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'GBP',
  started_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  customer_id TEXT REFERENCES customers(id) ON DELETE SET NULL,
  amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'GBP',
  status TEXT NOT NULL DEFAULT 'settled',
  reference TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS expenses (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'GBP',
  note TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS ledger_accounts (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('asset','liability','equity','income','expense')),
  UNIQUE (company_id, code)
);
CREATE TABLE IF NOT EXISTS journal_entries (
  id TEXT PRIMARY KEY,
  company_id TEXT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  entry_date TEXT NOT NULL,
  memo TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS journal_lines (
  id TEXT PRIMARY KEY,
  entry_id TEXT NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
  account_id TEXT NOT NULL REFERENCES ledger_accounts(id) ON DELETE RESTRICT,
  direction TEXT NOT NULL CHECK (direction IN ('debit','credit')),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0)
);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_uc_user ON user_companies(user_id);
`);
}

/* The seven businesses, in the Universal Business Group directory order. */
const COMPANIES = [
  { slug: 'growthboost', name: 'GrowthBoost AI' },
  { slug: 'dailyaccess', name: 'DailyAccess' },
  { slug: 'trust-vault', name: 'Trust Vault Bank', restricted: true },
  { slug: 'ai-magazine', name: 'AI Magazine & Comic Book Studio' },
  { slug: 'website-builder-marketplace', name: 'Website Builder Marketplace' },
  { slug: 'business-empire-ceo-simulator', name: 'Business Empire: CEO Simulator' },
  { slug: 'supergpu', name: 'SuperGPU Universal' },
  { slug: 'hq', name: 'Universal Business Group HQ', hq: true },
];

function seed(db) {
  const uuid = () => require('crypto').randomUUID();
  const now = new Date().toISOString();
  const insertCompany = db.prepare('INSERT INTO companies (id, slug, name, is_hq, restricted, created_at) VALUES (?,?,?,?,?,?)');
  const insertUser = db.prepare('INSERT INTO users (id, email, password_hash, is_active, email_verified_at, created_at) VALUES (?,?,?,?,?,?)');
  const insertUC = db.prepare('INSERT INTO user_companies (id, user_id, company_id, role, created_at) VALUES (?,?,?,?,?)');
  const insertAccount = db.prepare('INSERT INTO ledger_accounts (id, company_id, code, name, type) VALUES (?,?,?,?,?)');
  const insertEntry = db.prepare('INSERT INTO journal_entries (id, company_id, entry_date, memo, created_at) VALUES (?,?,?,?,?)');
  const insertLine = db.prepare('INSERT INTO journal_lines (id, entry_id, account_id, direction, amount_minor) VALUES (?,?,?,?,?)');
  const insertPayment = db.prepare('INSERT INTO payments (id, company_id, customer_id, amount_minor, currency, status, reference, created_at) VALUES (?,?,?,?,?,?,?,?)');
  const insertCustomer = db.prepare('INSERT INTO customers (id, company_id, user_id, name, email, created_at) VALUES (?,?,?,?,?,?)');
  const insertProduct = db.prepare('INSERT INTO products (id, company_id, name, price_minor, currency, active) VALUES (?,?,?,?,?,?)');
  const insertExpense = db.prepare('INSERT INTO expenses (id, company_id, category, amount_minor, currency, note, created_at) VALUES (?,?,?,?,?,?,?)');

  const run = db.transaction(() => {
    const ceoId = uuid();
    insertUser.run(ceoId, 'ceo@hq.example.com', hashPassword(process.env.SEED_CEO_PASSWORD || 'Change-me-ceo-2026!'), 1, now, now);

    for (const c of COMPANIES) {
      const cid = uuid();
      insertCompany.run(cid, c.slug, c.name, c.hq ? 1 : 0, c.restricted ? 1 : 0, now);
      if (c.hq) insertUC.run(uuid(), ceoId, cid, 'ceo', now);
      else insertUC.run(uuid(), ceoId, cid, 'admin', now);

      if (c.hq) continue;

      // Ledger chart: 1000 Cash (asset), 1100 Receivables (asset), 4000 Revenue (income), 5000 Expenses (expense), 3000 Equity (equity)
      const cash = uuid(), rev = uuid(), exp = uuid(), eq = uuid();
      insertAccount.run(cash, cid, '1000', 'Cash', 'asset');
      insertAccount.run(uuid(), cid, '1100', 'Receivables', 'asset');
      insertAccount.run(rev, cid, '4000', 'Revenue', 'income');
      insertAccount.run(exp, cid, '5000', 'Operating Expenses', 'expense');
      insertAccount.run(eq, cid, '3000', 'Owner Equity', 'equity');

      // Opening equity + 6 months of revenue/expense double-entry
      let e = uuid();
      insertEntry.run(e, cid, '2026-01-01', 'Opening equity', now);
      insertLine.run(uuid(), e, cash, 'debit', 5000000);
      insertLine.run(uuid(), e, eq, 'credit', 5000000);

      const months = ['2026-06', '2026-07', '2026-08', '2026-09', '2026-10', '2026-11'];
      months.forEach((m, i) => {
        const revMinor = 120000 + i * 25000 + Math.floor(Math.random() * 40000);
        const expMinor = 60000 + i * 8000 + Math.floor(Math.random() * 20000);
        let eid = uuid();
        insertEntry.run(eid, cid, m + '-15', 'Monthly customer revenue', now);
        insertLine.run(uuid(), eid, cash, 'debit', revMinor);
        insertLine.run(uuid(), eid, rev, 'credit', revMinor);
        eid = uuid();
        insertEntry.run(eid, cid, m + '-28', 'Operating costs', now);
        insertLine.run(uuid(), eid, exp, 'debit', expMinor);
        insertLine.run(uuid(), eid, cash, 'credit', expMinor);
        insertPayment.run(uuid(), cid, null, revMinor, 'GBP', 'settled', 'INV-' + m.replace('-', ''), m + '-15T10:00:00.000Z');
        insertExpense.run(uuid(), cid, 'operations', expMinor, 'GBP', m + ' operating costs', m + '-28T10:00:00.000Z');
      });

      // Demo customers + product + subscription
      insertProduct.run(uuid(), cid, c.name + ' Standard plan', 4900, 'GBP', 1);
      for (let i = 1; i <= 3; i++) {
        const custId = uuid();
        insertCustomer.run(custId, cid, null, `Customer ${i}`, `customer${i}@${c.slug}.example.com`, now);
        insertPayment.run(uuid(), cid, custId, 4900 + i * 1000, 'GBP', 'settled', 'DEMO-' + i, now);
      }
    }
  });
  run();
}

module.exports = { open, seed, DB_PATH, COMPANIES };

if (require.main === module) {
  if (process.argv.includes('--seed')) {
    const db = open();
    try { seed(db); console.log('Seeded', DB_PATH); }
    catch (e) { if (!/UNIQUE/.test(e.message)) throw e; console.log('Already seeded.'); }
    finally { db.close(); }
  }
}
