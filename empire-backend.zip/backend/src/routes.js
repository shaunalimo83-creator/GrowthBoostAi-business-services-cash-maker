'use strict';
/* All API routes: mirrors the endpoints the seven Next.js frontends + HQ call. */
const crypto = require('crypto');
const { open } = require('./db');
const {
  sha256, hashPassword, verifyPassword, newSessionToken,
  verifyTotp, generateTotpSecret, encryptMfaSecret, decryptMfaSecret,
} = require('./util');
const {
  SESSION_COOKIE, NO_STORE, json, readCookies, isSameOrigin,
  rateLimited, resolveCompany, requireSession, audit,
} = require('./auth');

const {
  BUSINESS_DIRECTORY, HEADQUARTERS, SECURITY_SETTINGS, LIVE_SERVICE_SETTINGS,
  getBusiness, getAllBusinesses, getBusinessTools, createWorkspaceConfiguration,
} = require('./config/businesses');

const db = open();
const throttles = new Map();
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const HOUR = 60 * 60 * 1000;
const sessionHours = Number(process.env.SESSION_MAX_AGE_HOURS || 8);
const devTokens = process.env.DEV_EXPOSE_TOKENS !== 'false';
const registrationEnabled = process.env.CUSTOMER_REGISTRATION_ENABLED === 'true';

/* ---------- helpers ---------- */
function setSessionCookie(res, slug, token, maxAgeSec) {
  res.setHeader('Set-Cookie',
    `${SESSION_COOKIE(slug)}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAgeSec}${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`);
}
function clearSessionCookie(res, slug) {
  res.setHeader('Set-Cookie', `${SESSION_COOKIE(slug)}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`);
}
async function readJson(req) {
  let raw = '';
  for await (const chunk of req) raw += chunk;
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}
function issueSession(userId, companyId) {
  const token = newSessionToken();
  db.prepare('INSERT INTO sessions (id, user_id, token_hash, company_id, created_at, expires_at) VALUES (?,?,?,?,?,?)')
    .run(crypto.randomUUID(), userId, sha256(token), companyId, new Date().toISOString(),
      new Date(Date.now() + sessionHours * HOUR).toISOString());
  return token;
}
function customerRole(db, userId, companyId) {
  return db.prepare('SELECT role FROM user_companies WHERE user_id = ? AND company_id = ?').get(userId, companyId)?.role || null;
}
function newToken() { return crypto.randomBytes(24).toString('hex'); }

/* ---------- route handlers ---------- */
const routes = [];
function route(method, pattern, handler) { routes.push({ method, pattern, handler }); }

route('GET', '/api/health', (ctx) =>
  json(ctx.res, 200, { ok: true, service: 'empire-backend', company: ctx.company ? ctx.company.slug : null, time: new Date().toISOString() }));

/* ── registration (customer, fixed company) ── */
route('POST', '/api/auth/register', async (ctx) => {
  const { req, res, company } = ctx;
  if (company.is_hq) return json(res, 403, { error: 'no_public_signup' });
  if (!registrationEnabled) return json(res, 503, { error: 'registration_not_enabled' });
  if (!isSameOrigin(req)) return json(res, 403, { error: 'origin_check_failed' });
  if (rateLimited(throttles, 'register:' + (req.headers['x-real-ip'] || req.socket.remoteAddress)))
    return json(res, 429, { error: 'too_many_attempts_try_again_later' });
  const body = await readJson(req);
  const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : '';
  const password = typeof body?.password === 'string' ? body.password : '';
  const name = typeof body?.name === 'string' ? body.name.trim().slice(0, 200) : '';
  if (!EMAIL.test(email) || email.length > 254 || password.length < 12 || password.length > 256)
    return json(res, 400, { error: 'valid_email_and_password_minimum_12_characters_required' });
  try {
    const existing = db.prepare('SELECT id, password_hash, is_active FROM users WHERE email = ?').get(email);
    if (existing && (!existing.is_active || !existing.password_hash || !verifyPassword(password, existing.password_hash)))
      return json(res, 401, { error: 'invalid_credentials' });
    let userId;
    const tx = db.transaction(() => {
      if (!existing) {
        userId = crypto.randomUUID();
        db.prepare('INSERT INTO users (id, email, password_hash, is_active, email_verified_at, created_at) VALUES (?,?,?,?,?,?)')
          .run(userId, email, hashPassword(password), 1, new Date().toISOString(), new Date().toISOString());
      } else userId = existing.id;
      const dup = db.prepare('SELECT id FROM user_companies WHERE user_id = ? AND company_id = ?').get(userId, company.id);
      if (dup) return { duplicate: true };
      db.prepare('INSERT INTO user_companies (id, user_id, company_id, role, created_at) VALUES (?,?,?,?,?)')
        .run(crypto.randomUUID(), userId, company.id, 'customer', new Date().toISOString());
      db.prepare('INSERT INTO customers (id, company_id, user_id, name, email, created_at) VALUES (?,?,?,?,?,?)')
        .run(crypto.randomUUID(), company.id, userId, name || email.split('@')[0], email, new Date().toISOString());
      audit(db, userId, company.id, existing ? 'customer.business_access_added' : 'customer.registered', userId);
      return { duplicate: false };
    });
    const result = tx();
    if (result.duplicate) return json(res, 409, { error: 'business_account_already_exists_use_sign_in' });
    return json(res, 201, { ok: true, userId, company: company.slug, notice: 'Account created for ' + company.name + '. Email verification is enforced at sign-in once an email provider is configured.' });
  } catch { return json(res, 503, { error: 'registration_unavailable' }); }
});

/* ── login (customer + HQ, TOTP MFA + recovery codes) ── */
route('POST', '/api/auth/login', async (ctx) => {
  const { req, res, company } = ctx;
  if (!isSameOrigin(req)) return json(res, 403, { error: 'origin_check_failed' });
  if (rateLimited(throttles, 'login:' + (req.headers['x-real-ip'] || req.socket.remoteAddress)))
    return json(res, 429, { error: 'invalid_credentials' });
  const body = await readJson(req);
  const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : '';
  const password = typeof body?.password === 'string' ? body.password : '';
  if (!EMAIL.test(email) || !password || password.length > 256)
    return json(res, 401, { error: 'invalid_credentials' });
  try {
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user?.is_active || !user.password_hash || !verifyPassword(password, user.password_hash))
      return json(res, 401, { error: 'invalid_credentials' });
    if (user.mfa_enrolled) {
      let verified = false;
      if (body?.mfaCode && user.mfa_secret_enc) {
        try { verified = verifyTotp(decryptMfaSecret(user.mfa_secret_enc), String(body.mfaCode)); } catch { verified = false; }
      }
      if (!verified && body?.recoveryCode) {
        const hash = sha256(String(body.recoveryCode).trim());
        const saved = db.prepare('SELECT id FROM recovery_codes WHERE user_id = ? AND code_hash = ? AND used_at IS NULL').get(user.id, hash);
        if (saved) {
          const consumed = db.prepare('UPDATE recovery_codes SET used_at = ? WHERE id = ? AND used_at IS NULL').run(new Date().toISOString(), saved.id);
          verified = consumed.changes === 1;
        }
      }
      if (!verified) return json(res, 401, { error: 'invalid_credentials' });
    }
    const membership = db.prepare('SELECT role FROM user_companies WHERE user_id = ? AND company_id = ?').get(user.id, company.id);
    if (!membership) return json(res, 403, { error: 'business_access_not_found' });
    const token = issueSession(user.id, company.id);
    audit(db, user.id, company.id, 'session.created');
    setSessionCookie(res, company.slug, token, sessionHours * 3600);
    return json(res, 200, { ok: true, company: company.slug, role: membership.role, user: { id: user.id, email: user.email } });
  } catch { return json(res, 503, { error: 'identity_service_unavailable' }); }
});

route('POST', '/api/auth/logout', (ctx) => {
  const { req, res, company } = ctx;
  const token = readCookies(req)[SESSION_COOKIE(company.slug)];
  if (token) {
    db.prepare('UPDATE sessions SET revoked_at = ? WHERE token_hash = ?').run(new Date().toISOString(), sha256(token));
    audit(db, null, company.id, 'session.revoked.self');
  }
  clearSessionCookie(res, company.slug);
  return json(res, 200, { ok: true });
});

route('GET', '/api/auth/me', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const user = db.prepare('SELECT id, email, mfa_enrolled, email_verified_at FROM users WHERE id = ?').get(session.user_id);
  return json(ctx.res, 200, {
    user: { id: user.id, email: user.email, mfaEnrolled: !!user.mfa_enrolled, emailVerified: !!user.email_verified_at },
    company: ctx.company.slug, companyName: ctx.company.name, role: session.role,
    sessionId: session.id, expiresAt: session.expires_at,
  });
});

/* ── MFA enrolment ── */
route('POST', '/api/auth/mfa/start', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const secret = generateTotpSecret();
  // Stash pending secret in an encrypted form on the user row (not yet enrolled).
  db.prepare('UPDATE users SET mfa_secret_enc = ? WHERE id = ?').run(encryptMfaSecret(secret), session.user_id);
  const label = encodeURIComponent(session.email);
  return json(ctx.res, 200, {
    ok: true, secret,
    otpauthUri: `otpauth://totp/Empire:${label}?secret=${secret}&issuer=Empire&algorithm=SHA1&digits=6&period=30`,
    notice: 'Add this secret to your authenticator app, then confirm with a current 6-digit code.',
  });
});

route('POST', '/api/auth/mfa/confirm', async (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const body = await readJson(ctx.req);
  const user = db.prepare('SELECT mfa_secret_enc, mfa_enrolled FROM users WHERE id = ?').get(session.user_id);
  if (!user?.mfa_secret_enc) return json(ctx.res, 400, { error: 'mfa_not_started' });
  if (!body?.code || !verifyTotp(decryptMfaSecret(user.mfa_secret_enc), String(body.code)))
    return json(ctx.res, 401, { error: 'invalid_code' });
  db.prepare('UPDATE users SET mfa_enrolled = 1 WHERE id = ?').run(session.user_id);
  // Issue one-time recovery codes
  const codes = [];
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM recovery_codes WHERE user_id = ? AND used_at IS NULL').run(session.user_id);
    for (let i = 0; i < 8; i++) {
      const code = crypto.randomBytes(5).toString('hex'); // 10 hex chars
      codes.push(code);
      db.prepare('INSERT INTO recovery_codes (id, user_id, code_hash, created_at) VALUES (?,?,?,?)')
        .run(crypto.randomUUID(), session.user_id, sha256(code), new Date().toISOString());
    }
  });
  tx();
  audit(db, session.user_id, ctx.company.id, 'mfa.enrolled');
  return json(ctx.res, 200, { ok: true, mfaEnrolled: true, recoveryCodes: codes, notice: 'Store these one-time recovery codes safely. They are shown only once.' });
});

route('POST', '/api/auth/recovery-codes', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const user = db.prepare('SELECT mfa_enrolled FROM users WHERE id = ?').get(session.user_id);
  if (!user?.mfa_enrolled) return json(ctx.res, 400, { error: 'mfa_not_enrolled' });
  const codes = [];
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM recovery_codes WHERE user_id = ? AND used_at IS NULL').run(session.user_id);
    for (let i = 0; i < 8; i++) {
      const code = crypto.randomBytes(5).toString('hex');
      codes.push(code);
      db.prepare('INSERT INTO recovery_codes (id, user_id, code_hash, created_at) VALUES (?,?,?,?)')
        .run(crypto.randomUUID(), session.user_id, sha256(code), new Date().toISOString());
    }
  });
  tx();
  audit(db, session.user_id, ctx.company.id, 'recovery_codes.regenerated');
  return json(ctx.res, 200, { ok: true, recoveryCodes: codes });
});

/* ── password change / reset ── */
route('POST', '/api/auth/password/change', async (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const body = await readJson(ctx.req);
  const current = typeof body?.currentPassword === 'string' ? body.currentPassword : '';
  const next = typeof body?.newPassword === 'string' ? body.newPassword : '';
  if (next.length < 12 || next.length > 256) return json(ctx.res, 400, { error: 'password_minimum_12_characters_required' });
  const user = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(session.user_id);
  if (!user?.password_hash || !verifyPassword(current, user.password_hash))
    return json(ctx.res, 401, { error: 'invalid_credentials' });
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(next), session.user_id);
  db.prepare('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND id != ? AND revoked_at IS NULL')
    .run(new Date().toISOString(), session.user_id, session.id);
  audit(db, session.user_id, ctx.company.id, 'password.changed');
  return json(ctx.res, 200, { ok: true, notice: 'Password changed. Other sessions were revoked.' });
});

route('POST', '/api/auth/password-reset/request', async (ctx) => {
  const { req, res } = ctx;
  if (rateLimited(throttles, 'pwreset:' + (req.headers['x-real-ip'] || req.socket.remoteAddress)))
    return json(res, 429, { error: 'too_many_attempts_try_again_later' });
  const body = await readJson(req);
  const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : '';
  // Generic response prevents account enumeration.
  const user = EMAIL.test(email) ? db.prepare('SELECT id FROM users WHERE email = ?').get(email) : null;
  let devToken;
  if (user) {
    const token = newToken();
    devToken = token;
    db.prepare('INSERT INTO password_reset_tokens (id, user_id, token_hash, expires_at, created_at) VALUES (?,?,?,?,?)')
      .run(crypto.randomUUID(), user.id, sha256(token), new Date(Date.now() + HOUR).toISOString(), new Date().toISOString());
    audit(db, user.id, ctx.company.id, 'password_reset.requested');
  }
  const payload = { ok: true, message: 'If the account exists, a reset link will be sent when email delivery is configured.' };
  if (devTokens && devToken) payload.devResetToken = devToken;
  return json(res, 200, payload);
});

route('POST', '/api/auth/password-reset/confirm', async (ctx) => {
  const body = await readJson(ctx.req);
  const token = typeof body?.token === 'string' ? body.token.trim() : '';
  const password = typeof body?.password === 'string' ? body.password : '';
  if (!token || password.length < 12 || password.length > 256)
    return json(ctx.res, 400, { error: 'valid_token_and_password_minimum_12_characters_required' });
  const row = db.prepare('SELECT * FROM password_reset_tokens WHERE token_hash = ?').get(sha256(token));
  if (!row || row.used_at || row.expires_at < new Date().toISOString())
    return json(ctx.res, 400, { error: 'invalid_or_expired_token' });
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(password), row.user_id);
  db.prepare('UPDATE password_reset_tokens SET used_at = ? WHERE id = ?').run(new Date().toISOString(), row.id);
  db.prepare('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND revoked_at IS NULL').run(new Date().toISOString(), row.user_id);
  audit(db, row.user_id, ctx.company.id, 'password_reset.confirmed');
  return json(ctx.res, 200, { ok: true, notice: 'Password reset. Sign in again.' });
});

/* ── email verification ── */
route('POST', '/api/auth/email/verification/request', async (ctx) => {
  const { req, res } = ctx;
  if (rateLimited(throttles, 'emailverify:' + (req.headers['x-real-ip'] || req.socket.remoteAddress)))
    return json(res, 429, { error: 'too_many_attempts_try_again_later' });
  const body = await readJson(req);
  const email = typeof body?.email === 'string' ? body.email.trim().toLowerCase() : '';
  const user = EMAIL.test(email) ? db.prepare('SELECT id, email_verified_at FROM users WHERE email = ?').get(email) : null;
  let devToken;
  if (user && !user.email_verified_at) {
    const token = newToken();
    devToken = token;
    db.prepare('INSERT INTO email_verification_tokens (id, user_id, token_hash, expires_at, created_at) VALUES (?,?,?,?,?)')
      .run(crypto.randomUUID(), user.id, sha256(token), new Date(Date.now() + 24 * HOUR).toISOString(), new Date().toISOString());
    audit(db, user.id, ctx.company.id, 'email_verification.requested');
  }
  const payload = { ok: true, message: 'If the account needs verification, an email will be sent when delivery is configured.' };
  if (devTokens && devToken) payload.devVerificationToken = devToken;
  return json(res, 200, payload);
});

route('POST', '/api/auth/email/verification/confirm', async (ctx) => {
  const body = await readJson(ctx.req);
  const token = typeof body?.token === 'string' ? body.token.trim() : '';
  const row = token ? db.prepare('SELECT * FROM email_verification_tokens WHERE token_hash = ?').get(sha256(token)) : null;
  if (!row || row.used_at || row.expires_at < new Date().toISOString())
    return json(ctx.res, 400, { error: 'invalid_or_expired_token' });
  db.prepare('UPDATE users SET email_verified_at = ? WHERE id = ?').run(new Date().toISOString(), row.user_id);
  db.prepare('UPDATE email_verification_tokens SET used_at = ? WHERE id = ?').run(new Date().toISOString(), row.id);
  audit(db, row.user_id, ctx.company.id, 'email_verified');
  return json(ctx.res, 200, { ok: true });
});

/* ── session management ── */
route('GET', '/api/auth/sessions', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const rows = db.prepare(
    `SELECT id, created_at, expires_at, revoked_at FROM sessions
     WHERE user_id = ? AND company_id = ? AND expires_at > ? AND revoked_at IS NULL ORDER BY created_at DESC`
  ).all(session.user_id, ctx.company.id, new Date().toISOString());
  return json(ctx.res, 200, { sessions: rows.map(s => ({ ...s, current: s.id === session.id })) });
});

route('DELETE', '/api/auth/sessions', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const body = ctx.body;
  const targetId = body?.sessionId;
  if (targetId) {
    const r = db.prepare('UPDATE sessions SET revoked_at = ? WHERE id = ? AND user_id = ? AND company_id = ?')
      .run(new Date().toISOString(), String(targetId), session.user_id, ctx.company.id);
    if (!r.changes) return json(ctx.res, 404, { error: 'session_not_found' });
  } else {
    db.prepare('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND company_id = ? AND id != ? AND revoked_at IS NULL')
      .run(new Date().toISOString(), session.user_id, ctx.company.id, session.id);
  }
  audit(db, session.user_id, ctx.company.id, 'session.revoked');
  return json(ctx.res, 200, { ok: true });
});

route('POST', '/api/auth/sessions/revoke-others', (ctx) => { // HQ convenience alias for DELETE /api/auth/sessions
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  db.prepare('UPDATE sessions SET revoked_at = ? WHERE user_id = ? AND company_id = ? AND id != ? AND revoked_at IS NULL')
    .run(new Date().toISOString(), session.user_id, ctx.company.id, session.id);
  audit(db, session.user_id, ctx.company.id, 'session.revoked.others');
  return json(ctx.res, 200, { ok: true });
});

/* ── enquiries (public marketing form) ── */
route('POST', '/api/enquiry', async (ctx) => {
  const { res, company } = ctx;
  const body = await readJson(ctx.req);
  const email = typeof body?.email === 'string' ? body.email.trim() : '';
  if (!EMAIL.test(email)) return json(res, 400, { error: 'valid email required' });
  db.prepare('INSERT INTO enquiries (id, company_id, email, name, message, created_at) VALUES (?,?,?,?,?,?)')
    .run(crypto.randomUUID(), company.id, email,
      typeof body?.name === 'string' ? body.name.slice(0, 200) : null,
      typeof body?.message === 'string' ? body.message.slice(0, 4000) : null,
      new Date().toISOString());
  audit(db, null, company.id, 'enquiry.received', email);
  return json(res, 202, { ok: true });
});

/* ── customer data (replaces the 503 stubs with real contracts) ── */
route('GET', '/api/me/summary', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company, ['customer', 'staff', 'admin', 'ceo']);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const subs = db.prepare(
    `SELECT s.id, s.plan, s.status, s.amount_minor, s.currency, s.started_at, p.name AS product
     FROM subscriptions s LEFT JOIN products p ON p.id = s.product_id
     WHERE s.company_id = ? AND s.customer_id IN (SELECT id FROM customers WHERE user_id = ?)`
  ).all(ctx.company.id, session.user_id);
  const payments = db.prepare(
    `SELECT id, amount_minor, currency, status, reference, created_at FROM payments
     WHERE company_id = ? AND customer_id IN (SELECT id FROM customers WHERE user_id = ?)
     ORDER BY created_at DESC LIMIT 20`
  ).all(ctx.company.id, session.user_id);
  const spendMinor = payments.filter(p => p.status === 'settled').reduce((a, p) => a + p.amount_minor, 0);
  return json(ctx.res, 200, {
    company: ctx.company.slug,
    subscriptions: subs,
    recentPayments: payments,
    totals: { settledSpendMinor: spendMinor, currency: 'GBP' },
    notice: 'Payments are recorded in the internal ledger. External card processing stays disabled until a merchant account is connected.',
  });
});

route('GET', '/api/me/export', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const user = db.prepare('SELECT id, email, created_at, mfa_enrolled, email_verified_at FROM users WHERE id = ?').get(session.user_id);
  const membership = db.prepare('SELECT role, created_at FROM user_companies WHERE user_id = ? AND company_id = ?').get(session.user_id, ctx.company.id);
  const enquiryRows = db.prepare('SELECT email, name, message, created_at FROM enquiries WHERE company_id = ? AND email = ?').all(ctx.company.id, user.email);
  ctx.res.writeHead(200, {
    'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
    'Content-Disposition': `attachment; filename="my-data-${ctx.company.slug}.json"`,
  });
  return ctx.res.end(JSON.stringify({ exportedAt: new Date().toISOString(), user, membership, enquiries: enquiryRows }, null, 2));
});

route('GET', '/api/admin/summary', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company, ['staff', 'admin', 'ceo']);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const counts = {
    customers: db.prepare('SELECT COUNT(*) c FROM customers WHERE company_id = ?').get(ctx.company.id).c,
    activeSubscriptions: db.prepare(`SELECT COUNT(*) c FROM subscriptions WHERE company_id = ? AND status = 'active'`).get(ctx.company.id).c,
    enquiries: db.prepare('SELECT COUNT(*) c FROM enquiries WHERE company_id = ?').get(ctx.company.id).c,
    newEnquiries: db.prepare(`SELECT COUNT(*) c FROM enquiries WHERE company_id = ? AND status = 'new'`).get(ctx.company.id).c,
  };
  const revenue = db.prepare(`SELECT COALESCE(SUM(amount_minor),0) s FROM payments WHERE company_id = ? AND status = 'settled'`).get(ctx.company.id).s;
  const expenses = db.prepare('SELECT COALESCE(SUM(amount_minor),0) s FROM expenses WHERE company_id = ?').get(ctx.company.id).s;
  const recentEnquiries = db.prepare('SELECT email, name, message, status, created_at FROM enquiries WHERE company_id = ? ORDER BY created_at DESC LIMIT 10').all(ctx.company.id);
  return json(ctx.res, 200, {
    company: ctx.company.slug, companyName: ctx.company.name, counts,
    finance: { settledRevenueMinor: revenue, expensesMinor: expenses, netMinor: revenue - expenses, currency: 'GBP' },
    recentEnquiries,
  });
});

/* ── Universal Business Group: directory, tools, workspaces, HQ config ── */
route('GET', '/api/businesses', (ctx) => {
  return json(ctx.res, 200, {
    headquarters: { name: HEADQUARTERS.name, dashboard: HEADQUARTERS.dashboard },
    businesses: getAllBusinesses(),
  });
});

route('GET', '/api/businesses/:businessId', (ctx) => {
  const business = getBusiness(ctx.params.businessId);
  if (!business) return json(ctx.res, 404, { error: 'Business not found.' });
  return json(ctx.res, 200, business);
});

route('GET', '/api/businesses/:businessId/tools', (ctx) => {
  try {
    return json(ctx.res, 200, { businessId: ctx.params.businessId, tools: getBusinessTools(ctx.params.businessId) });
  } catch (e) {
    return json(ctx.res, e.status || 500, { error: e.message });
  }
});

/* Per-user workspace creation — always scoped to the authenticated session. */
route('POST', '/api/workspaces', async (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const body = await readJson(ctx.req);
  try {
    const config = createWorkspaceConfiguration({
      userId: session.user_id,
      businessId: typeof body?.businessId === 'string' ? body.businessId : '',
      displayName: typeof body?.displayName === 'string' ? body.displayName.slice(0, 200) : undefined,
    });
    const business = getBusiness(config.businessId);
    const linked = business && business.slug
      ? db.prepare('SELECT id FROM companies WHERE slug = ?').get(business.slug)
      : null;
    const existing = db.prepare('SELECT id FROM workspaces WHERE user_id = ? AND business_id = ?').get(session.user_id, config.businessId);
    if (existing) return json(ctx.res, 409, { error: 'workspace_already_exists', workspaceId: existing.id });
    const id = crypto.randomUUID();
    db.prepare('INSERT INTO workspaces (id, user_id, business_id, company_id, display_name, status, settings, created_at) VALUES (?,?,?,?,?,?,?,?)')
      .run(id, config.userId, config.businessId, linked ? linked.id : null, config.displayName,
        config.status, JSON.stringify(config.settings), config.createdAt);
    audit(db, session.user_id, linked ? linked.id : ctx.company.id, 'workspace.created', config.businessId);
    return json(ctx.res, 201, { ...config, workspaceId: id, companyName: business && business.slug ? business.slug : null });
  } catch (e) {
    return json(ctx.res, e.status || 500, { error: e.message });
  }
});

route('GET', '/api/workspaces', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  const rows = db.prepare(
    `SELECT w.id, w.business_id, w.display_name, w.status, w.created_at, c.slug AS company_slug, c.name AS company_name
     FROM workspaces w LEFT JOIN companies c ON c.id = w.company_id
     WHERE w.user_id = ? ORDER BY w.created_at`
  ).all(session.user_id);
  return json(ctx.res, 200, { workspaces: rows });
});

/* Headquarters + security configuration. Live-service status is CEO-only. */
route('GET', '/api/hq/config', (ctx) => {
  return json(ctx.res, 200, {
    headquarters: HEADQUARTERS,
    security: SECURITY_SETTINGS,
    liveServices: {
      publicStatus: 'All live-service capabilities are disabled until real, approved provider credentials are configured.',
    },
  });
});

route('GET', '/api/hq/live-services', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company, ['ceo']);
  if (!session) return json(ctx.res, 401, { error: 'unauthorised' });
  return json(ctx.res, 200, { liveServices: LIVE_SERVICE_SETTINGS });
});

/* ── HQ consolidated reporting (replaces LEDGER_NOT_CONFIGURED 503) ── */
route('GET', '/api/consolidated', (ctx) => {
  const { session } = requireSession(db, ctx.req, ctx.company, ['ceo']);
  if (!session) return json(ctx.res, 401, { error: 'Unauthorised' });
  if (!ctx.company.is_hq) return json(ctx.res, 403, { error: 'hq_only' });
  const businesses = db.prepare('SELECT * FROM companies WHERE is_hq = 0 ORDER BY name').all().map(c => {
    const revenue = db.prepare(`SELECT COALESCE(SUM(amount_minor),0) s FROM payments WHERE company_id = ? AND status = 'settled'`).get(c.id).s;
    const expenses = db.prepare('SELECT COALESCE(SUM(amount_minor),0) s FROM expenses WHERE company_id = ?').get(c.id).s;
    const cash = db.prepare(
      `SELECT COALESCE(SUM(CASE WHEN jl.direction='debit' THEN jl.amount_minor ELSE 0 END),0)
        - COALESCE(SUM(CASE WHEN jl.direction='credit' THEN jl.amount_minor ELSE 0 END),0) bal
       FROM journal_lines jl JOIN journal_entries je ON je.id = jl.entry_id
       JOIN ledger_accounts la ON la.id = jl.account_id
       WHERE je.company_id = ? AND la.code = '1000'`).get(c.id).bal;
    return {
      company: c.slug, name: c.name,
      revenueMinor: revenue, expensesMinor: expenses, netProfitMinor: revenue - expenses,
      cashBalanceMinor: cash, currency: 'GBP',
      customers: db.prepare('SELECT COUNT(*) c FROM customers WHERE company_id = ?').get(c.id).c,
    };
  });
  const totals = businesses.reduce((a, b) => ({
    revenueMinor: a.revenueMinor + b.revenueMinor,
    expensesMinor: a.expensesMinor + b.expensesMinor,
    netProfitMinor: a.netProfitMinor + b.netProfitMinor,
    cashBalanceMinor: a.cashBalanceMinor + b.cashBalanceMinor,
    customers: a.customers + b.customers,
  }), { revenueMinor: 0, expensesMinor: 0, netProfitMinor: 0, cashBalanceMinor: 0, customers: 0 });
  const balanced = db.prepare(
    `SELECT je.company_id, je.id FROM journal_entries je WHERE je.company_id IN (SELECT id FROM companies WHERE is_hq = 0)
     AND (SELECT COALESCE(SUM(CASE WHEN direction='debit' THEN amount_minor ELSE -amount_minor END),0) FROM journal_lines WHERE entry_id = je.id) != 0`
  ).all();
  return json(ctx.res, 200, {
    status: 'ok', currency: 'GBP', generatedAt: new Date().toISOString(),
    totals, businesses,
    controls: { doubleEntryBalanced: balanced.length === 0, balancedEntriesChecked: 'all journal entries' },
  });
});

module.exports = { routes, db, json, readJson };
