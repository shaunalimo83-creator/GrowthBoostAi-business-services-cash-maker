'use strict';
/* Empire backend — HTTP server + router (zero-dependency runtime beyond express/better-sqlite3). */
const http = require('http');
const express = require('express');
const { routes, db } = require('./routes');
const { resolveCompany, json } = require('./auth');

const app = express();
app.disable('x-powered-by');

// CORS: development-friendly. Set ALLOWED_ORIGINS to restrict.
const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && (!allowed.length || allowed.includes(origin))) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
  }
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Company-Slug');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  next();
});

// Route dispatch (supports :params; JSON body parsed in handlers via readJson)
app.use((req, res) => {
  const pathOnly = req.url.split('?')[0].replace(/\/+$/, '') || '/';
  for (const r of routes) {
    if (r.method !== req.method) continue;
    const patternParts = r.pattern.split('/').filter(Boolean);
    const pathParts = pathOnly.split('/').filter(Boolean);
    if (patternParts.length !== pathParts.length) continue;
    const params = {};
    let ok = true;
    for (let i = 0; i < patternParts.length; i++) {
      if (patternParts[i].startsWith(':')) params[patternParts[i].slice(1)] = decodeURIComponent(pathParts[i]);
      else if (patternParts[i] !== pathParts[i]) { ok = false; break; }
    }
    if (!ok) continue;
    const company = resolveCompany(db, req);
    const ctx = { req, res, company, params, body: undefined };
    try {
      Promise.resolve(r.handler(ctx)).catch(err => {
        console.error('Handler error:', err);
        if (!res.headersSent) json(res, 500, { error: 'internal_error' });
      });
    } catch (err) {
      console.error('Dispatch error:', err);
      if (!res.headersSent) json(res, 500, { error: 'internal_error' });
    }
    return;
  }
  json(res, 404, { error: 'not_found', path: pathOnly });
});

const PORT = Number(process.env.PORT || 4000);
http.createServer(app).listen(PORT, () => {
  console.log(`Empire backend listening on http://localhost:${PORT}`);
  console.log(`Select company via "x-company-slug" header (slugs: growthboost, ai-magazine, trust-vault, stock-express, real-estate, supergpu, dailyaccess, hq).`);
});

module.exports = app;
