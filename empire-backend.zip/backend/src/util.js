'use strict';
/* Crypto + auth helpers (pure Node, no native deps beyond better-sqlite3). */
const crypto = require('crypto');

const MFA_KEY = () => {
  const k = process.env.MFA_ENCRYPTION_KEY || 'dev-only-change-me-0123456789abcdef0123456789abcdef';
  return crypto.createHash('sha256').update(String(k)).digest(); // 32 bytes
};

function sha256(s) { return crypto.createHash('sha256').update(s).digest('hex'); }

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${hash}`;
}

function verifyPassword(password, stored) {
  try {
    const [scheme, salt, hash] = String(stored).split('$');
    if (scheme !== 'scrypt' || !salt || !hash) return false;
    const test = crypto.scryptSync(password, salt, 64);
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), test);
  } catch { return false; }
}

function newSessionToken() { return crypto.randomBytes(32).toString('hex'); }

/* --- TOTP (RFC 6238, SHA-1, 30s step, 6 digits, ±1 step window) --- */
function base32Encode(buf) {
  const alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = 0, value = 0, out = '';
  for (const b of buf) { value = (value << 8) | b; bits += 8; while (bits >= 5) { out += alpha[(value >>> (bits - 5)) & 31]; bits -= 5; } }
  if (bits > 0) out += alpha[(value << (5 - bits)) & 31];
  return out;
}
function base32Decode(str) {
  const alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = 0, value = 0; const out = [];
  for (const ch of str.toUpperCase().replace(/=+$/, '')) {
    const idx = alpha.indexOf(ch); if (idx === -1) continue;
    value = (value << 5) | idx; bits += 5;
    if (bits >= 8) { out.push((value >>> (bits - 8)) & 255); bits -= 8; }
  }
  return Buffer.from(out);
}
function totpCode(secretB32, forTime = Math.floor(Date.now() / 1000)) {
  const counter = Math.floor(forTime / 30);
  const buf = Buffer.alloc(8); buf.writeUInt32BE(Math.floor(counter / 2 ** 32), 0); buf.writeUInt32BE(counter >>> 0, 4);
  const hmac = crypto.createHmac('sha1', base32Decode(secretB32)).update(buf).digest();
  const off = hmac[hmac.length - 1] & 0xf;
  const code = ((hmac[off] & 0x7f) << 24 | hmac[off + 1] << 16 | hmac[off + 2] << 8 | hmac[off + 3]) % 1e6;
  return String(code).padStart(6, '0');
}
function verifyTotp(secretB32, code, forTime = Math.floor(Date.now() / 1000)) {
  if (!/^\d{6}$/.test(String(code || ''))) return false;
  for (const drift of [-1, 0, 1]) if (totpCode(secretB32, forTime + drift * 30) === code) return true;
  return false;
}
function generateTotpSecret() { return base32Encode(crypto.randomBytes(20)); }

/* --- MFA secret encryption at rest (AES-256-GCM) --- */
function encryptMfaSecret(plain) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', MFA_KEY(), iv);
  const enc = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  return iv.toString('hex') + ':' + cipher.getAuthTag().toString('hex') + ':' + enc.toString('hex');
}
function decryptMfaSecret(stored) {
  const [iv, tag, enc] = String(stored).split(':');
  const decipher = crypto.createDecipheriv('aes-256-gcm', MFA_KEY(), Buffer.from(iv, 'hex'));
  decipher.setAuthTag(Buffer.from(tag, 'hex'));
  return Buffer.concat([decipher.update(Buffer.from(enc, 'hex')), decipher.final()]).toString('utf8');
}

module.exports = {
  sha256, hashPassword, verifyPassword, newSessionToken,
  totpCode, verifyTotp, generateTotpSecret, encryptMfaSecret, decryptMfaSecret,
};
