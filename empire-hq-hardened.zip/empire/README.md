# Empire — Seven-Business Ecosystem with CEO Master Dashboard

Production-shaped monorepo: **7 business apps + 1 CEO Master Dashboard**,
one shared TypeScript core, one PostgreSQL schema with company-level data
isolation, a double-entry ledger with financial controls, and honest,
labelled handling of every regulated capability.

| # | Company | App | Subdomain |
|---|---|---|---|
| 1 | GrowthBoost AI | `apps/growthboost` | growthboost.example.com |
| 2 | AI Magazine & Comic Book Studio | `apps/ai-magazine` | aimagazine.example.com |
| 3 | Trust Vault Bank | `apps/trust-vault` | trustvault.example.com |
| 4 | Stock Market Express | `apps/stock-express` | stockexpress.example.com |
| 5 | Real Estate Master Developments | `apps/real-estate` | realestate.example.com |
| 6 | SUPERGPU UNIVERSAL | `apps/supergpu` | supergpu.example.com |
| 7 | DailyAccess | `apps/dailyaccess` | dailyaccess.example.com |
| — | **CEO Master Dashboard (HQ)** | `apps/hq` | hq.example.com |

Reporting currency: **GBP** everywhere.

## What is real vs pending (no fake anything)

- **Real & tested now**: RBAC, money primitives, double-entry ledger with
  intercompany authorisation, TOTP MFA, password hashing, business registry,
  all eight app skeletons with working navigation/forms/state handling,
  Prisma schema + RLS policies, documentation and integration register.
- **Pending/unavailable (labelled, never faked)**: payment processing (PSP
  merchant accounts), Trust Vault financial services (needs an appropriately
  authorised partner — it is *not* an authorised bank), Stock Market Express
  live trading (paper trading only), market data feeds.

## Current implementation boundary

The HQ consolidated-reporting API deliberately returns HTTP 503 until a real
managed-auth adapter, mandatory MFA, CEO cross-company permission check and
live ledger query are configured. This is fail-closed behaviour, not a live
financial service. The HQ login, staff, reports and security pages are setup
scaffolds; do not expose them publicly as production controls yet.

For local development, the intended app ports are HQ 3000, GrowthBoost 3001,
AI Magazine 3002, Trust Vault 3003, Stock Express 3004, Real Estate 3005,
SUPERGPU 3006 and DailyAccess 3007. Production domains remain unregistered
until real domains, DNS records and TLS certificates are configured.

## Quick start

```bash
npm install
cp .env.example .env
npm run generate:apps     # regenerate the eight apps
npx prisma validate --schema packages/db/prisma/schema.prisma
npm run typecheck
npm test                  # Vitest suites (unit + ecosystem)
```

E2E (staging): `npx playwright test --config tests/playwright.config.ts`

## Local app ports

Run each app from its directory with `npm run dev`; ports are configured uniquely: HQ 3000, GrowthBoost 3001, AI Magazine 3002, Trust Vault 3003, Stock Express 3004, Real Estate 3005, SUPERGPU 3006, DailyAccess 3007.

## Documentation

- [docs/architecture.md](docs/architecture.md) — platform, tenancy, isolation
- [docs/security.md](docs/security.md) — auth, permissions, financial controls
- [docs/deployment.md](docs/deployment.md) — staged rollout per business
- [docs/backup-recovery.md](docs/backup-recovery.md) — backups, RPO/RTO, runbook
- [docs/integration-register.md](docs/integration-register.md) — connected/pending/unavailable
- [docs/api/openapi.yaml](docs/api/openapi.yaml) — API documentation
