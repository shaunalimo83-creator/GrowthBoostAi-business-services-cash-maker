## Account recovery

Password reset via verified email link; MFA re-enrolment requires support identity check.
