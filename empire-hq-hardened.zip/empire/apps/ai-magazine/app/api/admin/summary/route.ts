import { NextResponse } from "next/server";
// Requires staff/admin membership in this company (RBAC: admin:read).
export async function GET() {
  return NextResponse.json({ error: "forbidden" }, { status: 403 });
}
