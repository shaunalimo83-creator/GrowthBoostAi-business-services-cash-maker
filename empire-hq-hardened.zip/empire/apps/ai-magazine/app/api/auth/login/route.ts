import { NextResponse } from "next/server";
// Login goes through the managed auth service. Response codes:
// 200 session created · 207 MFA code required · 401 invalid credentials
export async function POST() {
  return NextResponse.json({ error: "auth service not configured in this environment" }, { status: 501 });
}
