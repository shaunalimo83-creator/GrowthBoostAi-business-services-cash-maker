import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "AI Magazine & Comic Book Studio",
  description: "AI publishing: magazines, comics, creator portfolios and creator shops.",
  openGraph: { title: "AI Magazine & Comic Book Studio", description: "AI publishing: magazines, comics, creator portfolios and creator shops." },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body>{children}</body></html>);
}
