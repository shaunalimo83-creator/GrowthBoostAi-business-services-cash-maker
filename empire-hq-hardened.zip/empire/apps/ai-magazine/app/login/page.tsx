'use client';
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mfaCode, setMfaCode] = useState("");
  const [mfaStep, setMfaStep] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, password, mfaCode: mfaCode || undefined }),
      });
      if (res.status === 207) { setMfaStep(true); return; } // MFA code required
      if (!res.ok) { setError("Invalid email or password."); return; }
      router.push("/dashboard");
    } catch { setError("Network error. Please try again."); }
    finally { setBusy(false); }
  }

  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 420, margin: "80px auto", padding: 24 }}>
      <h1>Sign in</h1>
      <form onSubmit={submit}>
        <label>Email<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <label>Password<input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        {mfaStep && (
          <label>Two-factor code
            <input inputMode="numeric" pattern="[0-9]{6}" required value={mfaCode} onChange={(e) => setMfaCode(e.target.value)} />
          </label>
        )}
        <button type="submit" disabled={busy}>{busy ? "Signing in…" : mfaStep ? "Verify" : "Next"}</button>
      </form>
      {error && <p role="alert" style={{ color: "#B91C1C" }}>{error}</p>}
      <p style={{ fontSize: 13 }}><a href="/account-recovery">Forgot password / account recovery</a></p>
    </main>
  );
}
