import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({ app: "dailyaccess", status: "ok", ts: new Date().toISOString() });
}
