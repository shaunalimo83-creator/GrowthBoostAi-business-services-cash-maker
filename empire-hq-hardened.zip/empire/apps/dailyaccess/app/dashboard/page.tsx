'use client';
import { useEffect, useState } from "react";

type Summary = { customerId: string; subscriptions: number; openInvoices: number; note: string };

export default function Dashboard() {
  const [data, setData] = useState<Summary | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");

  useEffect(() => {
    let alive = true;
    fetch("/api/me/summary")
      .then((r) => { if (!r.ok) throw new Error(); return r.json(); })
      .then((d) => { if (alive) { setData(d); setState("ready"); } })
      .catch(() => { if (alive) setState("error"); });
    return () => { alive = false; };
  }, []);

  if (state === "loading") return <main style={{ padding: 24 }}>Loading…</main>;
  if (state === "error") return <main style={{ padding: 24 }} role="alert">Could not load your dashboard. <a href="/login">Sign in</a> and try again.</main>;

  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 900, margin: "0 auto", padding: 24 }}>
      <h1>DailyAccess — customer dashboard</h1>
      <p>Subscriptions: {data!.subscriptions} · Open invoices: {data!.openInvoices}</p>
      <p style={{ fontSize: 13, color: "#555" }}>{data!.note}</p>
      <p><a href="/api/me/export">Download my data (GDPR export)</a> · <a href="/support">Support</a></p>
    </main>
  );
}
