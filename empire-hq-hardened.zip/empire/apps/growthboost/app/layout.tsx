import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "GrowthBoost AI",
  description: "AI business growth, marketing, websites, marketplace, bookings and automation.",
  openGraph: { title: "GrowthBoost AI", description: "AI business growth, marketing, websites, marketplace, bookings and automation." },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body>{children}</body></html>);
}
