import { NextResponse } from "next/server";

/**
 * Fail-closed placeholder until a verified managed-auth adapter and
 * database-backed CEO permission check are configured. Do not return
 * cross-company financial data from an unauthenticated route.
 */
export async function GET() {
  return NextResponse.json(
    {
      status: "not_configured",
      code: "CEO_AUTH_AND_LEDGER_REQUIRED",
      message: "Consolidated reporting is unavailable until CEO authentication, MFA, cross-company reporting permission, and the live ledger are configured.",
    },
    { status: 503, headers: { "Cache-Control": "no-store" } },
  );
}
