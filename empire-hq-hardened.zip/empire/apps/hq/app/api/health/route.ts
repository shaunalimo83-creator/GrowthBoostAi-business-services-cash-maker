import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({ app: "hq", status: "ok", ts: new Date().toISOString() });
}
