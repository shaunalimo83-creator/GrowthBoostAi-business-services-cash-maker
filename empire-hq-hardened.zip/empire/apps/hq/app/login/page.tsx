'use client';
// CEO login: password + mandatory TOTP MFA (RFC 6238, see @empire/core/mfa).
export default function Login() {
  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 420, margin: "80px auto" }}>
      <h1>CEO sign-in</h1>
      <p>MFA is mandatory. Enrolment and verification run through the managed auth service.</p>
      <p style={{ fontSize: 13, color: "#555" }}>Wired to the auth provider at deployment (see docs/deployment.md).</p>
    </main>
  );
}
