<main style={{padding:24,fontFamily:"system-ui"}}><h1>Downloadable reports</h1>
<p>Report types: consolidated P&L, cash flow & treasury, customer & subscription analytics, per-company financial statements (GBP).</p>
<p>Exports generate from live ledger data in CSV/PDF. No simulated figures are included.</p></main>