<main style={{padding:24,whiteSpace:"pre-wrap"}}># Terms of service — Real Estate Master Developments

> TEMPLATE — must be reviewed by qualified counsel before production use.

These terms govern use of Real Estate Master Developments services. Liability limits, cancellation and refund rights, service levels and dispute resolution are documented here before go-live.
</main>