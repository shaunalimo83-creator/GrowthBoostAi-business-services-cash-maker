# Stock Market Express app

Company id: `stock-express` · Currency: GBP · Subdomain: `stock-express.example.com`

Pages: / (marketing + enquiry), /login (MFA-aware), /dashboard, /admin, /legal/privacy, /legal/terms, /support, /account-recovery.
APIs: /api/health, /api/auth/login, /api/enquiry, /api/me/summary, /api/me/export, /api/admin/summary.
