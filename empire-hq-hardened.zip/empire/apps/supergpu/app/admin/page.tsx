'use client';
import { useEffect, useState } from "react";

type Row = { label: string; value: string };

export default function Admin() {
  const [rows, setRows] = useState<Row[] | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");

  useEffect(() => {
    fetch("/api/admin/summary")
      .then((r) => { if (!r.ok) throw new Error(); return r.json(); })
      .then((d) => { setRows(d.rows); setState("ready"); })
      .catch(() => setState("error"));
  }, []);

  if (state === "loading") return <main style={{ padding: 24 }}>Loading…</main>;
  if (state === "error") return <main style={{ padding: 24 }} role="alert">Admin area requires staff sign-in with MFA.</main>;

  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 900, margin: "0 auto", padding: 24 }}>
      <h1>SUPERGPU UNIVERSAL — business administration</h1>
      <table cellPadding={8}><tbody>
        {rows!.map((r) => <tr key={r.label}><th>{r.label}</th><td>{r.value}</td></tr>)}
      </tbody></table>
      <h2>Payments</h2>
      <p>Checkout is unavailable until a payment provider is connected and verified. No test or simulated charges are shown to customers.</p>
      <h2>Staff & permissions</h2>
      <p>Managed in the company admin area with role-based access (customer / staff / admin) — see the security documentation.</p>
    </main>
  );
}
