import { NextResponse } from "next/server";
// Returns the signed-in customer's summary for company "supergpu".
// 401 when unauthenticated; figures come from live database rows only.
export async function GET() {
  return NextResponse.json({ error: "sign-in required" }, { status: 401 });
}
