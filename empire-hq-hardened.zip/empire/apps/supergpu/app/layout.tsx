import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "SUPERGPU UNIVERSAL",
  description: "GPU optimisation, diagnostics, recovery, cloud GPU workstations and rendering.",
  openGraph: { title: "SUPERGPU UNIVERSAL", description: "GPU optimisation, diagnostics, recovery, cloud GPU workstations and rendering." },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body>{children}</body></html>);
}
