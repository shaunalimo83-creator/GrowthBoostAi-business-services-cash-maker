<main style={{padding:24,whiteSpace:"pre-wrap"}}># Privacy policy — Trust Vault Bank

> TEMPLATE — must be reviewed by qualified counsel before production use.

We process personal data under UK GDPR. Data controller: Trust Vault Bank (a separate legal entity within the group). Lawful bases, retention periods, data-subject rights (access, rectification, erasure, portability), international transfers and our Data Protection Officer contact are documented here before go-live. Customer data is never shared with other group companies without a lawful basis.
</main>