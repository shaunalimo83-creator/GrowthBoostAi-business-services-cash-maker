# Architecture

## Overview

One maintainable monorepo (npm workspaces) delivering **eight applications**: seven
business websites and one CEO Master Dashboard, all built on a shared core.

```
empire/
├─ apps/
│  ├─ growthboost/      # GrowthBoost AI
│  ├─ ai-magazine/      # AI Magazine & Comic Book Studio
│  ├─ trust-vault/      # Trust Vault Bank (regulated capabilities pending)
│  ├─ stock-express/    # Stock Market Express (paper trading only)
│  ├─ real-estate/      # Real Estate Master Developments
│  ├─ supergpu/         # SUPERGPU UNIVERSAL
│  ├─ dailyaccess/      # DailyAccess
│  └─ hq/               # CEO Master Dashboard
├─ packages/
│  ├─ core/             # entities, RBAC, money, double-entry ledger, TOTP MFA, auth, payment SPI
│  ├─ db/               # Prisma schema (PostgreSQL) + RLS policies
│  └─ ui/               # shared design tokens/components
├─ docs/                # security, deployment, backup, API docs, integration register
├─ tests/               # cross-cutting integration tests (Vitest) + Playwright e2e
├─ infra/               # docker-compose, IaC notes
└─ scripts/             # generators, CI helpers
```

## Tenancy & data isolation

- One PostgreSQL database. Every tenant table carries `company_id`.
- PostgreSQL **row-level security** policies (see `packages/db/policies/rls.sql`)
  pin every query to `current_setting('app.company_id')` — an application bug
  cannot leak one company's rows into another.
- Each company has its own admin area, customers, products, ledger and
  integration records. Legal/financial records are separate per company
  (separate ledger accounts and journals per `company_id`).

## Money & financial controls

- Amounts are **integer minor units** (pence). No floats anywhere.
- A **double-entry ledger** validates every journal: balanced per currency,
  ≥2 entries, single company per journal. Cross-company movement is only
  possible via an explicit intercompany journal pair carrying a board
  authorisation reference (`IntercompanyAuthorisation`).
- Payments flow exclusively through the `PaymentProvider` interface
  (`packages/core/src/payments.ts`). Until a PSP merchant account is connected
  **and webhook signature verification is configured**, every money path throws
  `ProviderNotConnectedError` and the UI shows "payments unavailable".
- Consolidated HQ reporting is read-only aggregation (`cross_company:read_reports`)
  and by design can never read customer banking data.

## Authentication

- Managed auth service (Cognito/Auth0/Keycloak) in production; MFA is TOTP
  (RFC 6238) — a full implementation with skew tolerance and constant-time
  comparison ships in `packages/core/src/mfa.ts` with tests.
- Session tokens are 256-bit random, stored hashed; passwords scrypt-hashed.

## Request flow

```
Browser ──> Next.js app (app router, per company subdomain)
             └─ /api/* route handler
                  ├─ auth middleware → AuthContext (user + memberships)
                  ├─ authorize(companyId, permission)   ← RBAC gate
                  ├─ Prisma with company_id scope + RLS
                  └─ PaymentProvider / storage / email via interfaces
```

## Deployment topology

- Apps: containerised Next.js (see `infra/`), one deployment per company
  subdomain + `hq.`; can run on Vercel or any Node host.
- Database: managed PostgreSQL with automated backups + PITR.
- Object storage: S3-compatible bucket, SSE-KMS, versioning on.
- Observability: Sentry (errors), OpenTelemetry (traces), structured logs.
