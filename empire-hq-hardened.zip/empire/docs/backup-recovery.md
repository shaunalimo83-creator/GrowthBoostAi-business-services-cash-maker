# Backup & Recovery Procedures

## Backups

| Asset | Method | Frequency | Retention |
|---|---|---|---|
| PostgreSQL | Managed snapshots + WAL/PITR | continuous WAL, daily snapshot | 35 days |
| Object storage | Bucket versioning + cross-region replication | continuous | 90 days |
| Secrets | KMS-backed; rotation runbook | quarterly | n/a |
| Ledger exports | Signed CSV export to write-once bucket | daily | 7 years |

Verification: restore drills run **monthly** into a scratch database; the
restored row counts and ledger checksums are compared against production
(read-only) and recorded in the ops log.

## Recovery objectives

- RPO ≤ 5 minutes (WAL), RTO ≤ 60 minutes per app.

## Recovery runbook (summary)

1. Declare incident; freeze payment webhooks (provider dashboard).
2. Provision scratch instance; `pg_restore` latest snapshot; replay WAL to
   the desired timestamp.
3. Verify: row counts per company, journal balance per company
   (`validateJournal` over restored journals), auth service reachability.
4. Repoint apps (health checks `/api/health`), unfreeze webhooks, replay the
   provider event log to reconcile payments (never assume success — reconcile).
5. Post-incident: audit-log review, blameless postmortem within 5 days.

## Data subjects (GDPR)

Customer export: `GET /api/me/export` (JSON of the customer's own rows).
Erasure: admin-initiated workflow that anonymises and retains only what
accounting law requires (ledger entries are never deleted — they are
immutable by design).
