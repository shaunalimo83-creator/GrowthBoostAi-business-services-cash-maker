# Integration Register

Status meaning — **connected**: live and verified · **pending**: contracted or
planned, not yet verified · **unavailable**: no authorised path exists yet.

| # | Service | Company | Kind | Status | Notes |
|---|---|---|---|---|---|
| 1 | PostgreSQL | All | Data | **pending** | Managed instance provisioned at deploy; schema + RLS ready |
| 2 | Managed auth (MFA/TOTP) | All | Auth | **pending** | TOTP implementation shipped in core; IdP wiring at deploy |
| 3 | Object storage (S3+KMS) | All | Storage | **pending** | Bucket + versioning at deploy |
| 4 | Stripe (or equivalent PSP) | All seven | Payment | **unavailable** | Needs merchant account per company; UI shows “payments unavailable” until connected |
| 5 | Email (SMTP/SES) | All | Notifications | **pending** | Templates ready |
| 6 | Sentry + OpenTelemetry | All | Observability | **pending** | DSNs at deploy |
| 7 | Market data feed | Stock Market Express | Data | **unavailable** | Requires licensed data provider |
| 8 | Brokerage / order routing | Stock Market Express | Trading | **unavailable** | Requires appropriately authorised partner; **paper trading only** meanwhile |
| 9 | Banking / e-money partner | Trust Vault Bank | Financial services | **unavailable** | Requires appropriately authorised partner; no banking data stored until signed |
| 10 | Analytics (privacy-preserving) | All | Analytics | **pending** | Plausible/self-hosted recommended |
| 11 | Domain + DNS + TLS | All | Hosting | **pending** | Per-company subdomains |
| 12 | AI briefing assistant (HQ) | HQ | AI | **connected (local)** | Uses consolidated data only; no external AI provider wired yet |

Review cadence: monthly, owned by the CEO office; changes are audit-logged.
