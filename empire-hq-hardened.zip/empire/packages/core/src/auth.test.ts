import { describe, it, expect } from "vitest";
import {
  generateTotpSecret,
  totpCode,
  verifyTotp,
  base32Decode,
  hashPassword,
  verifyPassword,
  newSessionToken,
  authorize,
} from "./index.js";

describe("MFA (TOTP)", () => {
  it("round-trips a base32 secret", () => {
    const secret = generateTotpSecret();
    expect(secret.length).toBe(32);
    expect(base32Decode(secret).length).toBe(20);
  });

  it("accepts the current code and rejects a wrong code", () => {
    const secret = generateTotpSecret();
    const now = 1_764_000_000; // fixed timestamp for determinism
    const code = totpCode(secret, Math.floor(now / 30));
    expect(verifyTotp(secret, code, now)).toBe(true);
    expect(verifyTotp(secret, "000000", now)).toBe(false);
    expect(verifyTotp(secret, "abc", now)).toBe(false);
  });

  it("rejects a reused code from a neighbouring step only within skew", () => {
    const secret = generateTotpSecret();
    const now = 1_764_000_000;
    const prev = totpCode(secret, Math.floor(now / 30) - 1);
    expect(verifyTotp(secret, prev, now)).toBe(true); // within ±1 step skew
  });
});

describe("passwords", () => {
  it("hashes and verifies without storing plaintext", () => {
    const stored = hashPassword("correct horse battery staple");
    expect(stored).not.toContain("correct horse");
    expect(verifyPassword("correct horse battery staple", stored)).toBe(true);
    expect(verifyPassword("wrong password", stored)).toBe(false);
    expect(verifyPassword("x", "garbage")).toBe(false);
  });

  it("produces a unique salt per hash", () => {
    expect(hashPassword("a")).not.toBe(hashPassword("a"));
  });

  it("issues high-entropy session tokens", () => {
    const t = newSessionToken();
    expect(t.length).toBeGreaterThanOrEqual(40);
    expect(newSessionToken()).not.toBe(t);
  });
});

describe("authorize wrapper", () => {
  it("returns 401 without auth, 403 without permission, ok otherwise", () => {
    expect(authorize({ companyId: "growthboost" }, "admin:read")).toMatchObject({ ok: false, status: 401 });
    const ctx = { userId: "u", memberships: [{ userId: "u", companyId: "growthboost", role: "staff" as const }] };
    expect(authorize({ auth: ctx, companyId: "growthboost" }, "admin:write")).toMatchObject({ ok: false, status: 403 });
    expect(authorize({ auth: ctx, companyId: "growthboost" }, "admin:read")).toEqual({ ok: true });
  });
});
