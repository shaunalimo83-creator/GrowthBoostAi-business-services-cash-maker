import { describe, it, expect } from "vitest";
import { BUSINESSES, BUSINESS_IDS, getBusiness, HOLDING } from "./entities.js";

describe("business registry", () => {
  it("contains exactly the seven businesses", () => {
    expect(BUSINESSES).toHaveLength(7);
    expect(BUSINESS_IDS).toEqual([
      "growthboost",
      "ai-magazine",
      "trust-vault",
      "stock-express",
      "real-estate",
      "supergpu",
      "dailyaccess",
    ]);
  });

  it("uses GBP as the reporting currency everywhere", () => {
    expect(HOLDING.reportingCurrency).toBe("GBP");
    for (const b of BUSINESSES) expect(b.currency).toBe("GBP");
  });

  it("marks Trust Vault financial services and Stock Express trading as pending authorised partner", () => {
    expect(getBusiness("trust-vault")!.regulated.financialServices).toBe(
      "pending-authorised-partner",
    );
    expect(getBusiness("stock-express")!.regulated.trading).toBe("pending-authorised-partner");
  });

  it("has no connected payment provider anywhere yet", () => {
    for (const b of BUSINESSES) expect(b.regulated.payments).toBe("pending-provider");
  });

  it("gives every business a unique slug and domain", () => {
    const slugs = BUSINESSES.map((b) => b.slug);
    expect(new Set(slugs).size).toBe(7);
    const domains = BUSINESSES.map((b) => b.domain);
    expect(new Set(domains).size).toBe(7);
  });
});
