import { describe, it, expect } from "vitest";
import { gbp } from "./money.js";
import {
  validateJournal,
  UnbalancedJournalError,
  CrossCompanyPostError,
  accountBalances,
  consolidatedProfitLoss,
  type Journal,
} from "./ledger.js";

const sale: Journal = {
  id: "j1",
  date: "2026-11-16",
  reference: "INV-001",
  description: "Consulting invoice",
  entries: [
    { companyId: "growthboost", accountCode: "1100", amount: gbp(100) }, // debtors (debit)
    { companyId: "growthboost", accountCode: "4000", amount: gbp(-100) }, // income (credit)
  ],
};

describe("ledger", () => {
  it("accepts a balanced single-company journal", () => {
    expect(() => validateJournal(sale)).not.toThrow();
  });

  it("rejects unbalanced journals", () => {
    const bad: Journal = {
      ...sale,
      entries: [sale.entries[0], { ...sale.entries[1], amount: gbp(-90) }],
    };
    expect(() => validateJournal(bad)).toThrow(UnbalancedJournalError);
  });

  it("rejects journals with fewer than two entries", () => {
    expect(() => validateJournal({ ...sale, entries: [sale.entries[0]] })).toThrow(/two entries/);
  });

  it("blocks cross-company posting without an intercompany pair", () => {
    const bad: Journal = {
      ...sale,
      entries: [
        { companyId: "growthboost", accountCode: "1100", amount: gbp(100) },
        { companyId: "real-estate", accountCode: "2100", amount: gbp(-100) },
      ],
    };
    expect(() => validateJournal(bad)).toThrow(CrossCompanyPostError);
  });

  it("allows intercompany movement only with a matching authorisation reference", () => {
    const ok: Journal = {
      id: "j2",
      date: "2026-11-16",
      reference: "IC-001",
      description: "Authorised intercompany loan",
      entries: [
        { companyId: "growthboost", accountCode: "1300", amount: gbp(50) },
        { companyId: "real-estate", accountCode: "2300", amount: gbp(-50) },
      ],
      intercompany: {
        fromCompanyId: "growthboost",
        toCompanyId: "real-estate",
        authorisationRef: "BRD-2026-0007",
      },
    };
    expect(() => validateJournal(ok)).not.toThrow();

    const noRef: Journal = { ...ok, intercompany: { ...ok.intercompany!, authorisationRef: "" } };
    expect(() => validateJournal(noRef)).toThrow(/authorisation reference/);

    const wrongCompanies: Journal = {
      ...ok,
      entries: [
        { companyId: "growthboost", accountCode: "1300", amount: gbp(50) },
        { companyId: "supergpu", accountCode: "2300", amount: gbp(-50) },
      ],
    };
    expect(() => validateJournal(wrongCompanies)).toThrow(CrossCompanyPostError);
  });

  it("nets account balances per company", () => {
    const balances = accountBalances(sale.entries);
    expect(balances.get("growthboost")!.get("1100")!.minor).toBe(10000);
    expect(balances.get("growthboost")!.get("4000")!.minor).toBe(-10000);
  });

  it("consolidates P&L across companies", () => {
    const incomeForEstate: Journal = {
      id: "j3",
      date: "2026-11-16",
      reference: "INV-002",
      description: "Rent",
      entries: [
        { companyId: "real-estate", accountCode: "1100", amount: gbp(40) },
        { companyId: "real-estate", accountCode: "4000", amount: gbp(-40) },
      ],
    };
    const pl = consolidatedProfitLoss([sale, incomeForEstate]);
    expect(pl.income).toBe(14000);
    expect(pl.profit).toBe(14000);
  });
});
