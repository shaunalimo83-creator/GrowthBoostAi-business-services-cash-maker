import type { Money } from "./money.js";
import { sum } from "./money.js";
import type { Currency } from "./entities.js";

/**
 * Double-entry ledger primitives.
 *
 * Invariants enforced here (and tested):
 *  - every journal has >= 2 entries;
 *  - entries must balance to zero in each currency;
 *  - every entry names exactly one company (entity) — the ledger of one
 *    company can never post into another company's accounts;
 *  - inter-company movement requires an explicit, separately authorised
 *    intercompany journal pair (loan/capital accounts), never a plain post.
 */

export type LedgerAccountType = "asset" | "liability" | "equity" | "income" | "expense";

export interface LedgerAccount {
  companyId: string;
  code: string;
  name: string;
  type: LedgerAccountType;
}

export interface LedgerEntry {
  companyId: string;
  accountCode: string;
  /** Positive = debit, negative = credit (signed convention) */
  amount: Money;
}

export interface Journal {
  id: string;
  date: string; // ISO date
  reference: string;
  description: string;
  entries: LedgerEntry[];
  /** Set for the explicit intercompany pair only */
  intercompany?: { fromCompanyId: string; toCompanyId: string; authorisationRef: string };
}

export class UnbalancedJournalError extends Error {
  constructor(public readonly currency: string, public readonly delta: number) {
    super(`journal does not balance in ${currency}: residual ${delta} minor units`);
  }
}

export class CrossCompanyPostError extends Error {
  constructor(public readonly companies: string[]) {
    super(
      `journal touches multiple companies without an authorised intercompany pair: ${companies.join(", ")}`,
    );
  }
}

export function validateJournal(j: Journal): void {
  if (j.entries.length < 2) throw new Error("journal requires at least two entries");

  const companies = Array.from(new Set(j.entries.map((e) => e.companyId)));
  if (companies.length > 1) {
    if (!j.intercompany) throw new CrossCompanyPostError(companies);
    const { fromCompanyId, toCompanyId, authorisationRef } = j.intercompany;
    if (!authorisationRef || authorisationRef.length < 6) {
      throw new Error("intercompany journal requires an authorisation reference");
    }
    const expected = Array.from(new Set([fromCompanyId, toCompanyId])).sort();
    if (JSON.stringify(companies.sort()) !== JSON.stringify(expected)) {
      throw new CrossCompanyPostError(companies);
    }
  }

  // Balance per currency. Reporting currency consolidation happens upstream.
  const byCurrency = new Map<Currency, number>();
  for (const e of j.entries) {
    byCurrency.set(e.amount.currency, (byCurrency.get(e.amount.currency) ?? 0) + e.amount.minor);
  }
  for (const [currency, delta] of byCurrency) {
    if (delta !== 0) throw new UnbalancedJournalError(currency, delta);
  }
}

/** Account balances by netting signed entries, grouped per company. */
export function accountBalances(
  entries: LedgerEntry[],
): Map<string, Map<string, Money>> {
  const out = new Map<string, Map<string, Money>>();
  for (const e of entries) {
    if (!out.has(e.companyId)) out.set(e.companyId, new Map());
    const accounts = out.get(e.companyId)!;
    const prev = accounts.get(e.accountCode);
    if (prev) {
      prev.minor += e.amount.minor;
    } else {
      accounts.set(e.accountCode, { currency: e.amount.currency, minor: e.amount.minor });
    }
  }
  return out;
}

/** Account-code convention: 4xxx = income, 5xxx = expense (standard UK chart).
 *  P&L consolidation counts income/expense accounts only; balance-sheet
 *  accounts (debtors, cash, loans) are excluded from the P&L. */
export function consolidatedProfitLoss(
  journals: Journal[],
  fxRate: (currency: string) => number = (c) => {
    if (c !== "GBP") throw new Error(`no FX rate configured for ${c}`);
    return 1;
  },
): { income: number; expense: number; profit: number } {
  let income = 0;
  let expense = 0;
  for (const j of journals) validateJournal(j);
  for (const j of journals) {
    for (const e of j.entries) {
      const rate = fxRate(e.amount.currency);
      if (e.accountCode.startsWith("4") && e.amount.minor < 0) income += -e.amount.minor * rate; // credits
      else if (e.accountCode.startsWith("5") && e.amount.minor > 0) expense += e.amount.minor * rate; // debits
    }
  }
  return { income, expense, profit: income - expense };
}

export function totalOf(entries: LedgerEntry[]): number {
  return sum(entries.map((e) => e.amount)).minor;
}
