import { describe, it, expect } from "vitest";
import { SimulatedProvider, ProviderNotConnectedError, getPaymentProvider } from "./payments.js";

describe("payment provider contract", () => {
  it("refuses to run the simulated provider in production", () => {
    expect(() => new SimulatedProvider("production")).toThrow(/forbidden in production/);
  });

  it("throws ProviderNotConnectedError (never fakes success) for every money path", async () => {
    const p = new SimulatedProvider("development");
    await expect(
      p.createIntent({
        companyId: "growthboost",
        customerId: "c1",
        amountMinor: 1000,
        currency: "GBP",
        reference: "INV-1",
        description: "test",
      }),
    ).rejects.toThrow(ProviderNotConnectedError);
    await expect(
      p.refund({ providerRef: "x", amountMinor: 100, reason: "test", authorisationRef: "AUTH-1" }),
    ).rejects.toThrow(ProviderNotConnectedError);
    expect(() => p.verifyWebhook(Buffer.from("x"), "sig")).toThrow(ProviderNotConnectedError);
  });

  it("production without a live merchant account throws rather than faking", () => {
    expect(() => getPaymentProvider("production")).toThrow(ProviderNotConnectedError);
  });
});
