-- Row-Level Security: company isolation enforced by the database.
-- The application connects as app_user with SET app.company_id per request;
-- policies below make cross-company reads/writes impossible even under a
-- buggy query. The HQ reporting service uses a separate, audited role (see
-- docs/security.md) which still cannot see customer banking data (that data
-- lives in a trust-vault-only table that the HQ role is never granted).

-- Enable RLS on every tenant table.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'Product','Customer','Subscription','Payment','Expense',
    'JournalEntry','Integration','UserCompany','AuditLog'
  ]
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY;', t);
  END LOOP;
END $$;

-- Generic tenant policy: rows are visible only when app.company_id matches.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'Product','Customer','Subscription','Payment','Expense',
    'JournalEntry','Integration','UserCompany','AuditLog'
  ]
  LOOP
    EXECUTE format($f$
      CREATE POLICY tenant_isolation ON %I
        USING (company_id = current_setting('app.company_id', true))
        WITH CHECK (company_id = current_setting('app.company_id', true));
    $f$, t);
  END LOOP;
END $$;

-- Banking data (Trust Vault): separate table; HQ role has NO grant on it.
-- CREATE TABLE trust_vault.banking_assets (...); -- created only when the
-- authorised-partner integration is signed. Until then Trust Vault stores no
-- banking data at all.
