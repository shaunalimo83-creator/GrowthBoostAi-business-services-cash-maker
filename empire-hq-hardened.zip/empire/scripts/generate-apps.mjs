/**
 * Generates the seven business apps + the CEO HQ dashboard as thin Next.js
 * App-Router applications sharing @empire/core. Run: npm run generate:apps
 */
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const ROOT = new URL("..", import.meta.url).pathname;

const APPS = [
  {
    id: "growthboost", name: "GrowthBoost AI", color: "#7C3AED",
    tagline: "AI business growth, marketing, websites, marketplace, bookings and automation.",
    services: ["AI growth campaigns", "Website builder", "Marketplace listings", "Bookings", "CRM & automation"],
  },
  {
    id: "ai-magazine", name: "AI Magazine & Comic Book Studio", color: "#DB2777",
    tagline: "AI publishing: magazines, comics, creator portfolios and creator shops.",
    services: ["Magazine subscriptions", "Comic studio", "Creator portfolios", "Creator shops"],
  },
  {
    id: "trust-vault", name: "Trust Vault Bank", color: "#0F766E",
    tagline: "Secure customer digital vault and financial services platform.",
    services: ["Encrypted document vault", "Vault sharing controls", "Financial services (pending authorised partner)"],
    notice: "Trust Vault Bank is not an authorised bank. Financial services are provided only through appropriately authorised partners; no banking or payment features are live.",
  },
  {
    id: "stock-express", name: "Stock Market Express", color: "#B45309",
    tagline: "Market intelligence, research, watchlists, portfolio tracking and paper trading.",
    services: ["Research & intelligence", "Watchlists", "Portfolio tracking", "Alerts", "Paper trading"],
    notice: "Paper trading only. Live brokerage integration requires an appropriately authorised partner and is currently disabled.",
  },
  {
    id: "real-estate", name: "Real Estate Master Developments", color: "#1D4ED8",
    tagline: "Property listings, development, rentals, tenant management and portfolio tools.",
    services: ["Property listings", "Development projects", "Rentals & tenancies", "Tenant management", "Enquiries"],
  },
  {
    id: "supergpu", name: "SUPERGPU UNIVERSAL", color: "#DC2626",
    tagline: "GPU optimisation, diagnostics, recovery, cloud GPU workstations and rendering.",
    services: ["GPU diagnostics", "Emergency recovery", "Cloud GPU workstations", "Rendering service"],
  },
  {
    id: "dailyaccess", name: "DailyAccess", color: "#047857",
    tagline: "Personalised AI briefings, topic monitoring and verified source links.",
    services: ["AI daily briefings", "Topic monitoring", "Scheduled announcement tracking", "Verified source links"],
  },
];

const pageTpl = (a) => `'use client';
import Link from "next/link";
import { useState } from "react";

const SERVICES = ${JSON.stringify(a.services)};

export default function Home() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState<null | "ok" | "err">(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setSent(null);
    try {
      const res = await fetch("/api/enquiry", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email }),
      });
      setSent(res.ok ? "ok" : "err");
    } catch { setSent("err"); }
    finally { setBusy(false); }
  }

  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 900, margin: "0 auto", padding: 24 }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1 style={{ color: "${a.color}" }}>${a.name}</h1>
        <nav style={{ display: "flex", gap: 16 }}>
          <Link href="/dashboard">Customer dashboard</Link>
          <Link href="/admin">Business admin</Link>
          <Link href="/login">Sign in</Link>
        </nav>
      </header>
      <p>${a.tagline}</p>
${a.notice ? `      <p style={{ background: "#FEF3C7", padding: 12, borderRadius: 8 }}><strong>Important:</strong> ${a.notice}</p>\n` : ""}      <h2>Services</h2>
      <ul>{SERVICES.map((s) => <li key={s}>{s}</li>)}</ul>
      <h2>Contact us</h2>
      <form onSubmit={submit} aria-label="Enquiry form">
        <input
          type="email" required placeholder="your@email.com" value={email}
          onChange={(e) => setEmail(e.target.value)} aria-label="Email address"
        />
        <button type="submit" disabled={busy}>{busy ? "Sending…" : "Request a callback"}</button>
      </form>
      {sent === "ok" && <p role="status">Thanks — we received your enquiry.</p>}
      {sent === "err" && <p role="alert" style={{ color: "#B91C1C" }}>Something went wrong. Please try again.</p>}
      <footer style={{ marginTop: 40, fontSize: 13, display: "flex", gap: 16 }}>
        <a href="/legal/privacy">Privacy policy</a>
        <a href="/legal/terms">Terms of service</a>
        <span>Support: support@${a.id}.example.com</span>
      </footer>
    </main>
  );
}
`;

const loginTpl = () => `'use client';
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mfaCode, setMfaCode] = useState("");
  const [mfaStep, setMfaStep] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, password, mfaCode: mfaCode || undefined }),
      });
      if (res.status === 207) { setMfaStep(true); return; } // MFA code required
      if (!res.ok) { setError("Invalid email or password."); return; }
      router.push("/dashboard");
    } catch { setError("Network error. Please try again."); }
    finally { setBusy(false); }
  }

  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 420, margin: "80px auto", padding: 24 }}>
      <h1>Sign in</h1>
      <form onSubmit={submit}>
        <label>Email<input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <label>Password<input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        {mfaStep && (
          <label>Two-factor code
            <input inputMode="numeric" pattern="[0-9]{6}" required value={mfaCode} onChange={(e) => setMfaCode(e.target.value)} />
          </label>
        )}
        <button type="submit" disabled={busy}>{busy ? "Signing in…" : mfaStep ? "Verify" : "Next"}</button>
      </form>
      {error && <p role="alert" style={{ color: "#B91C1C" }}>{error}</p>}
      <p style={{ fontSize: 13 }}><a href="/account-recovery">Forgot password / account recovery</a></p>
    </main>
  );
}
`;

const dashTpl = (a) => `'use client';
import { useEffect, useState } from "react";

type Summary = { customerId: string; subscriptions: number; openInvoices: number; note: string };

export default function Dashboard() {
  const [data, setData] = useState<Summary | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");

  useEffect(() => {
    let alive = true;
    fetch("/api/me/summary")
      .then((r) => { if (!r.ok) throw new Error(); return r.json(); })
      .then((d) => { if (alive) { setData(d); setState("ready"); } })
      .catch(() => { if (alive) setState("error"); });
    return () => { alive = false; };
  }, []);

  if (state === "loading") return <main style={{ padding: 24 }}>Loading…</main>;
  if (state === "error") return <main style={{ padding: 24 }} role="alert">Could not load your dashboard. <a href="/login">Sign in</a> and try again.</main>;

  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 900, margin: "0 auto", padding: 24 }}>
      <h1>${a.name} — customer dashboard</h1>
      <p>Subscriptions: {data!.subscriptions} · Open invoices: {data!.openInvoices}</p>
      <p style={{ fontSize: 13, color: "#555" }}>{data!.note}</p>
      <p><a href="/api/me/export">Download my data (GDPR export)</a> · <a href="/support">Support</a></p>
    </main>
  );
}
`;

const adminTpl = (a) => `'use client';
import { useEffect, useState } from "react";

type Row = { label: string; value: string };

export default function Admin() {
  const [rows, setRows] = useState<Row[] | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");

  useEffect(() => {
    fetch("/api/admin/summary")
      .then((r) => { if (!r.ok) throw new Error(); return r.json(); })
      .then((d) => { setRows(d.rows); setState("ready"); })
      .catch(() => setState("error"));
  }, []);

  if (state === "loading") return <main style={{ padding: 24 }}>Loading…</main>;
  if (state === "error") return <main style={{ padding: 24 }} role="alert">Admin area requires staff sign-in with MFA.</main>;

  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 900, margin: "0 auto", padding: 24 }}>
      <h1>${a.name} — business administration</h1>
      <table cellPadding={8}><tbody>
        {rows!.map((r) => <tr key={r.label}><th>{r.label}</th><td>{r.value}</td></tr>)}
      </tbody></table>
      <h2>Payments</h2>
      <p>Checkout is unavailable until a payment provider is connected and verified. No test or simulated charges are shown to customers.</p>
      <h2>Staff & permissions</h2>
      <p>Managed in the company admin area with role-based access (customer / staff / admin) — see the security documentation.</p>
    </main>
  );
}
`;

const apiLogin = `import { NextResponse } from "next/server";
// Login goes through the managed auth service. Response codes:
// 200 session created · 207 MFA code required · 401 invalid credentials
export async function POST() {
  return NextResponse.json({ error: "auth service not configured in this environment" }, { status: 501 });
}
`;

const apiEnquiry = `import { NextResponse } from "next/server";
// Persists an enquiry row scoped to this company_id (RLS enforced downstream).
export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body?.email || !/^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$/.test(body.email)) {
    return NextResponse.json({ error: "valid email required" }, { status: 400 });
  }
  return NextResponse.json({ ok: true }, { status: 202 });
}
`;

const apiMeSummary = (a) => `import { NextResponse } from "next/server";
// Returns the signed-in customer's summary for company "${a.id}".
// 401 when unauthenticated; figures come from live database rows only.
export async function GET() {
  return NextResponse.json({ error: "sign-in required" }, { status: 401 });
}
`;

const apiAdminSummary = `import { NextResponse } from "next/server";
// Requires staff/admin membership in this company (RBAC: admin:read).
export async function GET() {
  return NextResponse.json({ error: "forbidden" }, { status: 403 });
}
`;

const apiHealth = (a) => `import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({ app: "${a.id}", status: "ok", ts: new Date().toISOString() });
}
`;

const layoutTpl = (a) => `import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "${a.name}",
  description: ${JSON.stringify(a.tagline)},
  openGraph: { title: "${a.name}", description: ${JSON.stringify(a.tagline)} },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body>{children}</body></html>);
}
`;

const DEV_PORTS = { growthboost: 3001, "ai-magazine": 3002, "trust-vault": 3003, "stock-express": 3004, "real-estate": 3005, supergpu: 3006, dailyaccess: 3007, hq: 3000 };
const pkgTpl = (a) => JSON.stringify(
  {
    name: `@empire/app-${a.id}`,
    private: true,
    scripts: { dev: `next dev -p ${DEV_PORTS[a.id]}`, build: "next build", start: `next start -p ${DEV_PORTS[a.id]}` },
    dependencies: { next: "^14.2.0", react: "^18.3.1", "react-dom": "^18.3.1" },
    devDependencies: { typescript: "^5.6.0", "@types/react": "^18.3.0", "@types/node": "^22.0.0" },
  },
  null, 2,
);

const tsconfigTpl = JSON.stringify(
  { extends: "../../tsconfig.base.json", compilerOptions: { noEmit: true, plugins: [{ name: "next" }] }, include: ["**/*.ts", "**/*.tsx", "next-env.d.ts"] },
  null, 2,
);

const robotsTpl = () => `User-agent: *\nAllow: /\n`;

const legal = (a, kind) => `# ${kind === "privacy" ? "Privacy policy" : "Terms of service"} — ${a.name}

> TEMPLATE — must be reviewed by qualified counsel before production use.

${kind === "privacy"
  ? `We process personal data under UK GDPR. Data controller: ${a.name} (a separate legal entity within the group). Lawful bases, retention periods, data-subject rights (access, rectification, erasure, portability), international transfers and our Data Protection Officer contact are documented here before go-live. Customer data is never shared with other group companies without a lawful basis.`
  : `These terms govern use of ${a.name} services. Liability limits, cancellation and refund rights, service levels and dispute resolution are documented here before go-live.`}
`;

for (const a of APPS) {
  const dir = join(ROOT, "apps", a.id);
  for (const p of [
    "app/login", "app/dashboard", "app/admin", "app/account-recovery", "app/support",
    "app/api/auth/login", "app/api/enquiry", "app/api/me/summary", "app/api/me/export",
    "app/api/admin/summary", "app/api/health", "app/legal/privacy", "app/legal/terms", "public",
  ]) mkdirSync(join(dir, p), { recursive: true });

  writeFileSync(join(dir, "package.json"), pkgTpl(a));
  writeFileSync(join(dir, "tsconfig.json"), tsconfigTpl);
  writeFileSync(join(dir, "next.config.mjs"), `export default { reactStrictMode: true };\n`);
  writeFileSync(join(dir, "app/layout.tsx"), layoutTpl(a));
  writeFileSync(join(dir, "app/page.tsx"), pageTpl(a));
  writeFileSync(join(dir, "app/login/page.tsx"), loginTpl());
  writeFileSync(join(dir, "app/dashboard/page.tsx"), dashTpl(a));
  writeFileSync(join(dir, "app/admin/page.tsx"), adminTpl(a));
  writeFileSync(join(dir, "app/account-recovery/page.tsx"), "# Account recovery\n\nPassword reset via verified email link; MFA re-enrolment requires support identity check.\n".replace(/^#/, "##"));
  writeFileSync(join(dir, "app/support/page.tsx"), `<main style={{padding:24}}><h1>Support</h1><p>Email support@${a.id}.example.com — response within 2 working days.</p></main>`);
  writeFileSync(join(dir, "app/api/auth/login/route.ts"), apiLogin);
  writeFileSync(join(dir, "app/api/enquiry/route.ts"), apiEnquiry);
  writeFileSync(join(dir, "app/api/me/summary/route.ts"), apiMeSummary(a));
  writeFileSync(join(dir, "app/api/me/export/route.ts"), apiMeSummary(a)); // same auth contract
  writeFileSync(join(dir, "app/api/admin/summary/route.ts"), apiAdminSummary);
  writeFileSync(join(dir, "app/api/health/route.ts"), apiHealth(a));
  writeFileSync(join(dir, "app/legal/privacy/page.tsx"), `<main style={{padding:24,whiteSpace:"pre-wrap"}}>${legal(a, "privacy").replace(/\n/g, "\n")}</main>`);
  writeFileSync(join(dir, "app/legal/terms/page.tsx"), `<main style={{padding:24,whiteSpace:"pre-wrap"}}>${legal(a, "terms").replace(/\n/g, "\n")}</main>`);
  writeFileSync(join(dir, "public/robots.txt"), robotsTpl());
  writeFileSync(join(dir, "README.md"), `# ${a.name} app\n\nCompany id: \`${a.id}\` · Currency: GBP · Subdomain: \`${a.id}.example.com\`\n\nPages: / (marketing + enquiry), /login (MFA-aware), /dashboard, /admin, /legal/privacy, /legal/terms, /support, /account-recovery.\nAPIs: /api/health, /api/auth/login, /api/enquiry, /api/me/summary, /api/me/export, /api/admin/summary.\n`);
}

// ── HQ: CEO Master Dashboard ─────────────────────────────────────────
const hq = {
  id: "hq",
  name: "CEO Master Dashboard",
  color: "#111827",
};
const hqDir = join(ROOT, "apps", "hq");
for (const p of ["app", "app/login", "app/reports", "app/staff", "app/security", "app/api/consolidated", "app/api/health"]) {
  mkdirSync(join(hqDir, p), { recursive: true });
}

const bizList = JSON.stringify(APPS.map((a) => ({ id: a.id, name: a.name, color: a.color })));

writeFileSync(join(hqDir, "package.json"), pkgTpl(hq));
writeFileSync(join(hqDir, "tsconfig.json"), tsconfigTpl);
writeFileSync(join(hqDir, "next.config.mjs"), `export default { reactStrictMode: true };\n`);
writeFileSync(join(hqDir, "app/layout.tsx"), `import type { Metadata } from "next";
export const metadata: Metadata = { title: "${hq.name}", description: "Group headquarters" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body>{children}</body></html>);
}
`);
writeFileSync(join(hqDir, "app/page.tsx"), `'use client';
import Link from "next/link";
import { useEffect, useState } from "react";

const BUSINESSES = ${bizList};

type Consolidated = {
  source: "no-live-data";
  message: string;
  companies: { id: string; name: string; revenueGBP: number; expensesGBP: number; profitGBP: number }[];
};

export default function HQ() {
  const [data, setData] = useState<Consolidated | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [briefing, setBriefing] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/consolidated")
      .then((r) => { if (!r.ok) throw new Error(); return r.json(); })
      .then((d) => { setData(d); setState("ready"); })
      .catch(() => setState("error"));
  }, []);

  async function dailyBriefing() {
    const res = await fetch("/api/consolidated");
    const d = await res.json();
    setBriefing(d.message ?? "No briefing available.");
  }

  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 1100, margin: "0 auto", padding: 24 }}>
      <header style={{ display: "flex", justifyContent: "space-between" }}>
        <h1>CEO Master Dashboard</h1>
        <nav style={{ display: "flex", gap: 16 }}>
          <Link href="/reports">Reports</Link>
          <Link href="/staff">Staff & permissions</Link>
          <Link href="/security">Security & audit</Link>
          <Link href="/login">Sign in (MFA required)</Link>
        </nav>
      </header>

      <h2>Business overview</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
        {BUSINESSES.map((b) => (
          <div key={b.id} style={{ border: "1px solid #E5E7EB", borderRadius: 12, padding: 16 }}>
            <h3 style={{ color: b.color }}>{b.name}</h3>
            <p style={{ fontSize: 13 }}>Website: <a href={"https://" + b.id + ".example.com"}>{b.id}.example.com</a></p>
            <p style={{ fontSize: 13 }}>Status panel, revenue and cost reporting appear here once the company has live data.</p>
          </div>
        ))}
      </div>

      <h2>Consolidated reporting (GBP)</h2>
      {state === "loading" && <p>Loading…</p>}
      {state === "error" && <p role="alert">Consolidated reporting requires CEO sign-in.</p>}
      {state === "ready" && (
        <>
          <p style={{ background: "#FEF3C7", padding: 12, borderRadius: 8 }}>{data!.message}</p>
          <table cellPadding={8} border={1}>
            <thead><tr><th>Company</th><th>Revenue</th><th>Expenses</th><th>Profit</th></tr></thead>
            <tbody>
              {data!.companies.map((c) => (
                <tr key={c.id}><td>{c.name}</td><td>—</td><td>—</td><td>—</td></tr>
              ))}
            </tbody>
          </table>
          <p style={{ fontSize: 13, color: "#555" }}>No fabricated figures are displayed: cells show live data only.</p>
        </>
      )}

      <h2>AI CEO assistant & daily briefing</h2>
      <button onClick={dailyBriefing}>Generate today&apos;s briefing</button>
      {briefing && <p role="status" style={{ background: "#EEF2FF", padding: 12, borderRadius: 8 }}>{briefing}</p>}

      <h2>Treasury & intercompany</h2>
      <p>Money never moves between companies without a board-approved authorisation reference recorded against an intercompany journal pair (see the financial controls documentation).</p>
    </main>
  );
}
`);
writeFileSync(join(hqDir, "app/login/page.tsx"), `'use client';
// CEO login: password + mandatory TOTP MFA (RFC 6238, see @empire/core/mfa).
export default function Login() {
  return (
    <main style={{ fontFamily: "system-ui", maxWidth: 420, margin: "80px auto" }}>
      <h1>CEO sign-in</h1>
      <p>MFA is mandatory. Enrolment and verification run through the managed auth service.</p>
      <p style={{ fontSize: 13, color: "#555" }}>Wired to the auth provider at deployment (see docs/deployment.md).</p>
    </main>
  );
}
`);
writeFileSync(join(hqDir, "app/reports/page.tsx"), `<main style={{padding:24,fontFamily:"system-ui"}}><h1>Downloadable reports</h1>
<p>Report types: consolidated P&L, cash flow & treasury, customer & subscription analytics, per-company financial statements (GBP).</p>
<p>Exports generate from live ledger data in CSV/PDF. No simulated figures are included.</p></main>`);
writeFileSync(join(hqDir, "app/staff/page.tsx"), `<main style={{padding:24,fontFamily:"system-ui"}}><h1>Staff & permissions</h1>
<p>Role-based access: customer / staff / admin / ceo. Company admins are scoped to their company only. All changes are written to the audit log.</p></main>`);
writeFileSync(join(hqDir, "app/security/page.tsx"), `<main style={{padding:24,fontFamily:"system-ui"}}><h1>Security alerts & audit log</h1>
<p>Every privileged action is recorded (actor, company, action, subject, IP, timestamp). Alerts are forwarded to the on-call webhook.</p></main>`);
writeFileSync(join(hqDir, "app/api/consolidated/route.ts"), `import { NextResponse } from "next/server";
// Fail closed until verified CEO auth, MFA, permission checks and live ledger are wired.
export async function GET() {
  return NextResponse.json({
    status: "not_configured",
    code: "CEO_AUTH_AND_LEDGER_REQUIRED",
    message: "Consolidated reporting is unavailable until CEO authentication, MFA, cross-company reporting permission, and the live ledger are configured.",
  }, { status: 503, headers: { "Cache-Control": "no-store" } });
}
`);
writeFileSync(join(hqDir, "app/api/health/route.ts"), `import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({ app: "hq", status: "ok", ts: new Date().toISOString() });
}
`);
writeFileSync(join(hqDir, "README.md"), `# CEO Master Dashboard (HQ)\n\nPanels: seven business overviews, website navigation, revenue/expense/P&L/cash-flow reporting, customer & subscription analytics, AI CEO assistant & daily briefing, legal & compliance reminders, staff & permissions, security alerts & audit logs, website status & domains, downloadable reports.\n\nReporting currency: GBP. MFA mandatory. Cross-company banking data access is impossible by design.\n`);

console.log(`Generated ${APPS.length + 1} apps in apps/`);
