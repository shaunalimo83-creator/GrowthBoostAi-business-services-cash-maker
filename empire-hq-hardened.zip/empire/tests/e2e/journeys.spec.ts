import { test, expect } from "@playwright/test";

// E2E journeys — one suite per concern, run against staging after each rollout.
// NOTE: payment success/refund-success journeys assert the HONEST unavailable
// path until a PSP is connected; they are extended the day the provider goes
// live (never faked).

for (const app of ["growthboost", "ai-magazine", "trust-vault", "stock-express", "real-estate", "supergpu", "dailyaccess"]) {
  test.describe(`${app} customer journey`, () => {
    test("home page renders with navigation and legal links", async ({ page }) => {
      await page.goto(`https://${app}.example.com/`);
      await expect(page.getByRole("link", { name: "Customer dashboard" })).toBeVisible();
      await expect(page.getByRole("link", { name: "Business admin" })).toBeVisible();
      await expect(page.getByText("Privacy policy")).toBeVisible();
      await expect(page.getByText("Terms of service")).toBeVisible();
    });

    test("enquiry form shows loading, success and error states", async ({ page }) => {
      await page.goto(`https://${app}.example.com/`);
      await page.getByLabel("Email address").fill("customer@example.com");
      await page.getByRole("button", { name: /Request a callback/ }).click();
      await expect(page.getByRole("status")).toContainText(/Thanks|went wrong/);
    });

    test("dashboard requires sign-in (no anonymous data)", async ({ page }) => {
      await page.goto(`https://${app}.example.com/dashboard`);
      await expect(page.getByRole("alert")).toContainText(/Sign in/);
    });

    test("checkout reports payment unavailability honestly", async ({ page }) => {
      await page.goto(`https://${app}.example.com/admin`);
      await expect(page.getByText(/unavailable until a payment provider is connected/i)).toBeVisible();
    });
  });
}

test.describe("CEO HQ", () => {
  test("login enforces MFA", async ({ page }) => {
    await page.goto("https://hq.example.com/login");
    await expect(page.getByText(/MFA is mandatory/)).toBeVisible();
  });

  test("consolidated reporting shows no fabricated figures", async ({ page }) => {
    await page.goto("https://hq.example.com/");
    await expect(page.getByText(/No live financial data yet|No fabricated figures/i).first()).toBeVisible();
  });
});
