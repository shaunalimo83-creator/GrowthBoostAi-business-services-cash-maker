import { defineConfig } from "vitest/config";

/**
 * Playwright e2e (run against a deployed/staging instance):
 *   npx playwright test
 * The spec file lives at tests/e2e/journeys.spec.ts — these are the journeys
 * the platform promises: register, authenticate (MFA), permissions,
 * payment (unavailable path), cancellation, refunds (authorised path),
 * customer journeys, reporting, backup verification.
 */
export default defineConfig({ test: { environment: "node" } });
