import React from "react";
import { createRoot } from "react-dom/client";
import { AppProvider } from "./store.jsx";
import { Shell } from "./shell.jsx";
import "./styles.css";

createRoot(document.getElementById("root")).render(
  <AppProvider>
    <Shell />
  </AppProvider>
);
