import React, { useState } from "react";
import { useApp, BUSINESSES, CEOS, fmtGBP } from "./store.jsx";

/* ================= shared bits ================= */
function Notice({ tone = "amber", children }) {
  return <div className={"notice " + (tone === "amber" ? "" : tone)}>{children}</div>;
}
function Badge({ s }) {
  const cls = { connected: "ok", active: "ok", published: "ok", verified: "ok",
    pending: "pending", pending_review: "pending", pending_payment: "pending",
    unavailable: "off", suspended: "off", draft: "info" }[s] || "info";
  return <span className={"badge " + cls}>{String(s).replace(/_/g, " ")}</span>;
}
function LoginGate({ children }) {
  return <div>{children}</div>;
}

/* ================= login / register ================= */
function AuthScreen() {
  const app = useApp();
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ email: "", password: "", name: "", business: "growthboost" });
  const [err, setErr] = useState("");
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  function submit(e) {
    e.preventDefault(); setErr("");
    if (mode === "login") {
      const r = app.login(form.email.trim(), form.password);
      if (!r.ok) setErr(r.error);
    } else {
      const r = app.register(form.email.trim(), form.password, form.name.trim() || "Customer", form.business);
      if (!r.ok) setErr(r.error);
    }
  }
  return (
    <div className="center">
      <h1>{mode === "login" ? "Empire HQ — Sign in" : "Create customer account"}</h1>
      <p className="muted" style={{ marginBottom: 16 }}>
        One shared account across the seven business websites and CEO HQ.
      </p>
      {mode === "register" && (
        <div className="field"><label>Full name</label><input value={form.name} onChange={set("name")} placeholder="Your name" /></div>
      )}
      <div className="field"><label>Email</label><input type="email" value={form.email} onChange={set("email")} placeholder="you@example.com" /></div>
      <div className="field"><label>Password</label><input type="password" value={form.password} onChange={set("password")} placeholder={mode === "register" ? "At least 8 characters" : "Your password"} /></div>
      {mode === "register" && (
        <div className="field"><label>Primary business of interest</label>
          <select value={form.business} onChange={set("business")}>
            {BUSINESSES.map((b) => <option key={b.slug} value={b.slug}>{b.name}</option>)}
          </select>
        </div>
      )}
      {err && <Notice tone="red">{err}</Notice>}
      <button className="btn" style={{ width: "100%" }} onClick={submit}>
        {mode === "login" ? "Sign in" : "Create account"}
      </button>
      <p className="muted" style={{ textAlign: "center", marginTop: 12 }}>
        {mode === "login" ? (
          <>No account? <a href="#register" onClick={(e) => { e.preventDefault(); setMode("register"); setErr(""); }}>Register as a customer</a></>
        ) : (
          <>Have an account? <a href="#login" onClick={(e) => { e.preventDefault(); setMode("login"); setErr(""); }}>Sign in</a></>
        )}
      </p>
      <Notice tone="blue">
        <strong>Demo CEO accounts</strong> (created by one-time bootstrap, as in Phase 5 — there is no public CEO signup):<br />
        {CEOS.map((c) => <span key={c.email} style={{ display: "block" }}>{c.email} / {c.password}</span>)}
        Registration is customer-level only, mirroring the source's registration-disabled-by-default policy.
      </Notice>
    </div>
  );
}

/* ================= HQ dashboard ================= */
function HqDashboard({ go }) {
  const app = useApp();
  const bs = BUSINESSES.map((b) => app.companies[b.slug]);
  const revenue = bs.reduce((a, c) => a + c.revenueMinor, 0);
  const expenses = bs.reduce((a, c) => a + c.expensesMinor, 0);
  const customers = bs.reduce((a, c) => a + c.customers, 0);
  return (
    <div className="stack">
      <div className="grid g2">
        <div className="card"><h3>Consolidated revenue (GBP)</h3><div className="kpi">{fmtGBP(revenue)}</div></div>
        <div className="card"><h3>Consolidated expenses</h3><div className="kpi">{fmtGBP(expenses)}<small>Margin {fmtGBP(revenue - expenses)} ({Math.round(((revenue - expenses) / revenue) * 100)}%)</small></div></div>
        <div className="card"><h3>Customers across the group</h3><div className="kpi">{customers}</div></div>
        <div className="card"><h3>Ledger integrity</h3><div className="kpi">1,694 lines verified<small>{app.journalCount} intercompany journal{app.journalCount === 1 ? "" : "s"} posted this session · double-entry balanced</small></div></div>
      </div>
      <div className="card">
        <h3>Seven portfolio companies</h3>
        <table><thead><tr><th>Company</th><th>Revenue</th><th>Expenses</th><th>Customers</th><th>Status</th><th></th></tr></thead><tbody>
          {bs.map((c) => (
            <tr key={c.slug}>
              <td><span className="row"><span className="dot" style={{ background: c.color }} />{c.name}</span></td>
              <td>{fmtGBP(c.revenueMinor)}</td><td>{fmtGBP(c.expensesMinor)}</td><td>{c.customers}</td>
              <td><Badge s={c.status} /></td>
              <td><button className="btn small secondary" onClick={() => go("biz-" + c.slug)}>Open</button></td>
            </tr>
          ))}
        </tbody></table>
      </div>
      <Notice>
        <strong>Reporting boundary:</strong> In the source repository the HQ consolidated-reporting API deliberately returns HTTP 503 until a real managed-auth adapter, mandatory MFA, CEO cross-company permission check and live ledger query are configured. This demo reproduces the same fail-closed discipline: no live financial data flows here — figures shown are sample tenant data in local storage.
      </Notice>
    </div>
  );
}

/* ================= business detail (admin view) ================= */
function BusinessDetail({ slug, go }) {
  const app = useApp();
  const c = app.companies[slug];
  const [p, setP] = useState({ name: "", price: "", kind: "subscription" });
  const margin = c.revenueMinor - c.expensesMinor;
  return (
    <div className="stack">
      <div className="crumbs"><button onClick={() => go("hq")}>← CEO HQ</button> / {c.name}</div>
      <div className="card bizhead" style={{ borderLeft: `6px solid ${c.color}` }}>
        <div><h3 style={{ fontSize: 18 }}>{c.name}</h3><p className="muted" style={{ margin: "4px 0 0" }}>{c.desc} <span className="tiny">(source: apps/{slug}, local port {c.port})</span></p></div>
      </div>
      {c.disclosure && <Notice><strong>Important:</strong> {c.disclosure}</Notice>}
      {c.restricted && <Notice tone="red"><strong>Restricted words notice:</strong> {c.restricted}</Notice>}
      <div className="grid g2">
        <div className="card"><h3>Revenue</h3><div className="kpi">{fmtGBP(c.revenueMinor)}</div></div>
        <div className="card"><h3>Margin</h3><div className="kpi">{fmtGBP(margin)}</div></div>
        <div className="card"><h3>Customers</h3><div className="kpi">{c.customers}</div></div>
        <div className="card"><h3>Company status</h3>
          <div className="row" style={{ marginTop: 6 }}>
            <Badge s={c.status} />
            <button className="btn small secondary" onClick={() => app.setCompanyStatus(slug, c.status === "active" ? "suspended" : "active")}>
              Set {c.status === "active" ? "suspended" : "active"}
            </button>
          </div>
        </div>
      </div>
      <div className="card">
        <h3>Product & service catalogue</h3>
        <table><thead><tr><th>Product</th><th>Kind</th><th>Price</th><th>Status</th><th></th></tr></thead><tbody>
          {c.catalog.map((prod) => (
            <tr key={prod.id}>
              <td>{prod.name}</td><td>{prod.kind}</td><td>{fmtGBP(prod.priceMinor)}</td>
              <td><Badge s={prod.active ? "active" : "draft"} /></td>
              <td><button className="btn small secondary" onClick={() => app.toggleProduct(slug, prod.id)}>{prod.active ? "Deactivate" : "Activate"}</button></td>
            </tr>
          ))}
        </tbody></table>
        <div className="row wrap" style={{ marginTop: 10 }}>
          <input style={{ maxWidth: 260 }} placeholder="New product name" value={p.name} onChange={(e) => setP({ ...p, name: e.target.value })} />
          <input style={{ maxWidth: 120 }} placeholder="Price (pence)" value={p.price} onChange={(e) => setP({ ...p, price: e.target.value })} />
          <select style={{ maxWidth: 140 }} value={p.kind} onChange={(e) => setP({ ...p, kind: e.target.value })}>
            <option value="subscription">subscription</option><option value="service">service</option>
            <option value="digital">digital</option><option value="physical">physical</option><option value="listing">listing</option>
          </select>
          <button className="btn" onClick={() => {
            const minor = parseInt(p.price, 10);
            if (!p.name.trim() || isNaN(minor)) return alert("Enter a product name and price in minor units (e.g. 4900 = £49.00).");
            app.addProduct(slug, p.name.trim(), minor, p.kind); setP({ name: "", price: "", kind: "subscription" });
          }}>Add product</button>
        </div>
      </div>
      <div className="card">
        <h3>Business notes</h3>
        <textarea value={c.notes} placeholder="Operational notes, follow-ups, phase checklist items…" onChange={(e) => app.saveNote(slug, e.target.value)} />
        <p className="tiny muted">Saved to local storage automatically.</p>
      </div>
    </div>
  );
}

/* ================= Customer Business HQ (Phase 15) + marketplace ================= */
function CustomerHq() {
  const app = useApp();
  const s = app.session;
  const [tab, setTab] = useState("profile");
  const [biz, setBiz] = useState({ name: "", handle: "", desc: "" });
  const [listing, setListing] = useState({ title: "", desc: "", type: "digital", price: "" });
  const myProducts = app.marketplaceProducts.filter((m) => m.sellerEmail === s.email);

  return (
    <div className="stack">
      <div className="row wrap" style={{ gap: 6 }}>
        {["profile", "my-business", "listings", "marketplace"].map((t) => (
          <button key={t} className={"btn small " + (tab === t ? "" : "secondary")} onClick={() => setTab(t)}>
            {t === "my-business" ? "My business" : t[0].toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {tab === "profile" && (
        <div className="card">
          <h3>Customer profile — {s.name}</h3>
          <p className="muted">Signed in as <strong>{s.email}</strong> · role: {s.role} · MFA {s.mfaEnrolled ? "enrolled ✓" : "not enrolled"}</p>
          {!s.mfaEnrolled && (
            <div className="row"><button className="btn" onClick={app.enrollMfa}>Enrol TOTP MFA</button>
              <span className="tiny muted">Mirrors Phase 11: TOTP MFA + one-time recovery codes.</span></div>
          )}
        </div>
      )}

      {tab === "my-business" && (
        <div className="card">
          <h3>Create your own business</h3>
          <p className="muted">Customers can create businesses and manage them from a private CEO dashboard (Phase 15).</p>
          <div className="field"><label>Business name</label><input value={biz.name} onChange={(e) => setBiz({ ...biz, name: e.target.value })} /></div>
          <div className="field"><label>Handle</label><input value={biz.handle} onChange={(e) => setBiz({ ...biz, handle: e.target.value.replace(/[^a-z0-9-]/gi, "").toLowerCase() })} placeholder="e.g. acme-studio" /></div>
          <div className="field"><label>Description</label><textarea value={biz.desc} onChange={(e) => setBiz({ ...biz, desc: e.target.value })} /></div>
          {biz.name && biz.handle && <Notice tone="green">Business "{biz.name}" ({biz.handle}) would be provisioned with visibility controls: public profile and storefront default to <strong>private</strong>.</Notice>}
        </div>
      )}

      {tab === "listings" && (
        <div className="stack">
          <div className="card">
            <h3>Submit a product for moderation</h3>
            <div className="field"><label>Title</label><input value={listing.title} onChange={(e) => setListing({ ...listing, title: e.target.value })} /></div>
            <div className="field"><label>Description</label><textarea value={listing.desc} onChange={(e) => setListing({ ...listing, desc: e.target.value })} /></div>
            <div className="row wrap">
              <select style={{ maxWidth: 140 }} value={listing.type} onChange={(e) => setListing({ ...listing, type: e.target.value })}>
                <option value="digital">digital</option><option value="physical">physical</option><option value="service">service</option>
              </select>
              <input style={{ maxWidth: 140 }} placeholder="Price (pence)" value={listing.price} onChange={(e) => setListing({ ...listing, price: e.target.value })} />
              <button className="btn" onClick={() => {
                const minor = parseInt(listing.price, 10);
                if (!listing.title.trim() || isNaN(minor)) return alert("Enter a title and price in pence.");
                app.createListing(s.email, "customer", listing.title.trim(), listing.desc, listing.type, minor);
                setListing({ title: "", desc: "", type: "digital", price: "" });
              }}>Submit for review</button>
            </div>
          </div>
          <div className="card">
            <h3>My listings</h3>
            {myProducts.length === 0 ? <p className="muted">No listings yet.</p> : (
              <table><thead><tr><th>Title</th><th>Type</th><th>Price</th><th>Status</th></tr></thead><tbody>
                {myProducts.map((m) => <tr key={m.id}><td>{m.title}</td><td>{m.productType}</td><td>{fmtGBP(m.priceMinor)}</td><td><Badge s={m.status} /></td></tr>)}
              </tbody></table>
            )}
          </div>
        </div>
      )}

      {tab === "marketplace" && (
        <div className="stack">
          <Notice tone="red"><strong>Checkout disabled by design:</strong> the marketplace checkout and seller payouts are deliberately disabled until a regulated PSP marketplace integration and signed settlement webhooks are configured. Placing an order creates a <em>pending_payment</em> record only — nothing is charged.</Notice>
          <div className="card">
            <h3>Published marketplace products</h3>
            {app.marketplaceProducts.filter((m) => m.status === "published").length === 0
              ? <p className="muted">No published products yet. Submit a listing and have a CEO moderate it.</p> : (
              <table><thead><tr><th>Product</th><th>Seller</th><th>Price</th><th></th></tr></thead><tbody>
                {app.marketplaceProducts.filter((m) => m.status === "published").map((m) => (
                  <tr key={m.id}><td>{m.title}</td><td>{m.sellerEmail}</td><td>{fmtGBP(m.priceMinor)}</td>
                    <td><button className="btn small" onClick={() => app.createOrder(m.id)}>Place order</button></td></tr>
                ))}
              </tbody></table>
            )}
          </div>
          {app.marketplaceOrders.length > 0 && (
            <div className="card"><h3>My orders</h3>
              <table><thead><tr><th>Order</th><th>Product</th><th>Price</th><th>Status</th></tr></thead><tbody>
                {app.marketplaceOrders.map((o) => <tr key={o.id}><td className="tiny">{o.id}</td><td>{o.title}</td><td>{fmtGBP(o.priceMinor)}</td><td><Badge s={o.status} /></td></tr>)}
              </tbody></table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ================= CEO moderation panel ================= */
function Moderation() {
  const app = useApp();
  const pending = app.marketplaceProducts.filter((m) => m.status === "pending_review");
  return (
    <div className="stack">
      <div className="card">
        <h3>Marketplace review queue (CEO only)</h3>
        {pending.length === 0 ? <p className="muted">Queue empty.</p> : (
          <table><thead><tr><th>Product</th><th>Seller</th><th>Price</th><th>Actions</th></tr></thead><tbody>
            {pending.map((m) => (
              <tr key={m.id}><td>{m.title}</td><td>{m.sellerEmail}</td><td>{fmtGBP(m.priceMinor)}</td>
                <td className="row">
                  <button className="btn small" onClick={() => app.moderateListing(m.id, "published")}>Publish</button>
                  <button className="btn small danger" onClick={() => app.moderateListing(m.id, "archived")}>Archive</button>
                </td></tr>
            ))}
          </tbody></table>
        )}
      </div>
      <div className="card">
        <h3>Intercompany authorisation (double-entry ledger)</h3>
        <p className="muted">Cross-company movement requires an explicit, separately authorised intercompany journal pair — never a plain post. A journal that does not balance per currency is rejected.</p>
        <IntercompanyForm />
        {app.intercompany.length > 0 && (
          <table style={{ marginTop: 10 }}><thead><tr><th>Date</th><th>From</th><th>To</th><th>Amount</th><th>Authorisation ref</th><th>Memo</th></tr></thead><tbody>
            {app.intercompany.map((j) => <tr key={j.id}><td>{j.date}</td><td>{j.fromSlug}</td><td>{j.toSlug}</td><td>{fmtGBP(j.amountMinor)}</td><td className="tiny">{j.ref}</td><td className="tiny">{j.memo}</td></tr>)}
          </tbody></table>
        )}
      </div>
    </div>
  );
}

function IntercompanyForm() {
  const app = useApp();
  const [f, setF] = useState({ from: "growthboost", to: "hq", amount: "", ref: "", memo: "" });
  const [res, setRes] = useState(null);
  return (
    <div>
      <div className="row wrap">
        <select style={{ maxWidth: 170 }} value={f.from} onChange={(e) => setF({ ...f, from: e.target.value })}>
          {["hq", ...BUSINESSES.map((b) => b.slug)].map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <span>→</span>
        <select style={{ maxWidth: 170 }} value={f.to} onChange={(e) => setF({ ...f, to: e.target.value })}>
          {["hq", ...BUSINESSES.map((b) => b.slug)].map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <input style={{ maxWidth: 140 }} placeholder="Amount (pence)" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} />
        <input style={{ maxWidth: 180 }} placeholder="Authorisation ref (6+)" value={f.ref} onChange={(e) => setF({ ...f, ref: e.target.value })} />
        <input style={{ maxWidth: 200 }} placeholder="Memo" value={f.memo} onChange={(e) => setF({ ...f, memo: e.target.value })} />
        <button className="btn" onClick={() => {
          const minor = parseInt(f.amount, 10);
          if (isNaN(minor) || minor <= 0) return setRes({ ok: false, error: "Enter a positive amount in pence." });
          setRes(app.postIntercompany(f.from, f.to, minor, f.ref.trim(), f.memo.trim()));
        }}>Post journal</button>
      </div>
      {res && (res.ok
        ? <Notice tone="green">Journal validated: 2 entries, balanced in GBP, intercompany authorisation recorded.</Notice>
        : <Notice tone="red">Rejected — {res.error}</Notice>)}
    </div>
  );
}

/* ================= integrations register ================= */
function Integrations() {
  const app = useApp();
  return (
    <div className="card">
      <h3>Integration register — connected / pending / unavailable</h3>
      <p className="muted">Mirrors docs/integration-register.md: unavailable capabilities are labelled and never faked.</p>
      <table><thead><tr><th>Integration</th><th>Status</th><th>Note</th></tr></thead><tbody>
        {app.integrations.map((i) => <tr key={i.id}><td>{i.name}</td><td><Badge s={i.status} /></td><td className="muted">{i.note}</td></tr>)}
      </tbody></table>
    </div>
  );
}

/* ================= Trust Vault legal pack ================= */
function LegalPack() {
  const app = useApp();
  const [sel, setSel] = useState("d1");
  const doc = app.docs.find((d) => d.id === sel);
  return (
    <div className="stack">
      <Notice><strong>Legal status:</strong> This content comes from the uploaded <em>Trust_Vault_Bank_Legal_Foundation_Package_Draft.docx</em> — a solicitor-review working draft. It is not legal advice, a completed legal instrument, an FCA/PRA application or regulatory approval.</Notice>
      <div className="card">
        <h3>Legal Foundation & Governance Document Package</h3>
        <div className="row wrap" style={{ marginTop: 8 }}>
          {app.docs.map((d) => (
            <button key={d.id} className={"btn small " + (sel === d.id ? "" : "secondary")} onClick={() => setSel(d.id)}>{d.title}</button>
          ))}
        </div>
        {doc && (
          <div style={{ marginTop: 14 }}>
            <strong>{doc.title}</strong> <span className="badge info">{doc.edition}</span>
            <p style={{ whiteSpace: "pre-wrap", fontSize: 14, lineHeight: 1.6 }}>{doc.body}</p>
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= Vibe Coding Platform ================= */
function VibeStudio() {
  const app = useApp();
  const mine = app.vibeProjects.filter((p) => p.ownerEmail === app.session.email);
  const [name, setName] = useState("");
  const [sel, setSel] = useState(null);
  const [code, setCode] = useState("");
  const proj = mine.find((p) => p.id === sel);
  return (
    <div className="stack">
      <div className="card">
        <h3>Vibe Coding Studio</h3>
        <p className="muted">Shared project studio serving all seven business apps and CEO HQ — a platform service, not an eighth portfolio company. Free plan: maximum 3 projects. AI code generation stays wired to Vercel AI Gateway server-side only (not runtime-tested here).</p>
        <div className="row wrap">
          <input style={{ maxWidth: 260 }} placeholder="New project name" value={name} onChange={(e) => setName(e.target.value)} />
          <button className="btn" onClick={() => {
            const r = app.createVibeProject(app.session.email, name.trim() || "Untitled project");
            if (!r.ok) alert(r.error); else { setName(""); setSel(r.id); setCode(app.vibeProjects.find((p) => p.id === r.id)?.html || ""); }
          }}>Create project ({mine.length}/3 used)</button>
        </div>
      </div>
      {mine.length > 0 && (
        <div className="card">
          <div className="row wrap" style={{ marginBottom: 10 }}>
            {mine.map((p) => <button key={p.id} className={"btn small " + (sel === p.id ? "" : "secondary")} onClick={() => { setSel(p.id); setCode(p.html); }}>{p.name}</button>)}
          </div>
          {proj && (
            <div className="grid" style={{ gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <label className="tiny muted">HTML editor (sandboxed local preview, as in Phase 14)</label>
                <textarea style={{ minHeight: 260, fontFamily: "monospace", fontSize: 12 }} value={code} onChange={(e) => setCode(e.target.value)} />
                <div className="row" style={{ marginTop: 8 }}>
                  <button className="btn" onClick={() => app.updateVibeProject(proj.id, code)}>Save & run</button>
                  <button className="btn danger" onClick={() => { app.deleteVibeProject(proj.id); setSel(null); }}>Delete</button>
                </div>
              </div>
              <div>
                <label className="tiny muted">Live preview</label>
                <iframe title="preview" style={{ width: "100%", height: 300, border: "1px solid #CBD5E1", borderRadius: 8, background: "#fff" }}
                  srcDoc={proj.html} sandbox="" />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ================= business "website" (customer-facing home, mirrors apps/<biz>/page.tsx) ================= */
function BusinessSite({ slug }) {
  const app = useApp();
  const c = app.companies[slug];
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(null);
  return (
    <div className="stack">
      <div className="card" style={{ borderTop: `6px solid ${c.color}` }}>
        <h3 style={{ fontSize: 20, color: c.color }}>{c.name}</h3>
        <p className="muted">{c.desc}</p>
        <h3 style={{ fontSize: 14 }}>Services</h3>
        <ul>{c.services.map((s) => <li key={s}>{s}</li>)}</ul>
        {c.disclosure && <Notice><strong>Important:</strong> {c.disclosure}</Notice>}
        <h3 style={{ fontSize: 14 }}>Contact us</h3>
        <div className="row wrap">
          <input style={{ maxWidth: 260 }} type="email" required placeholder="your@email.com" value={email} onChange={(e) => setEmail(e.target.value)} />
          <button className="btn" onClick={() => { setSent(email.includes("@") ? "ok" : "err"); }}>Request a callback</button>
        </div>
        {sent === "ok" && <p role="status" className="tiny" style={{ color: "#065F46" }}>Thanks — we received your enquiry.</p>}
        {sent === "err" && <p role="alert" className="tiny" style={{ color: "#B91C1C" }}>Please enter a valid email address.</p>}
      </div>
    </div>
  );
}

/* ================= shell ================= */
export function Shell() {
  const app = useApp();
  const [view, setView] = useState("hq");
  const go = (v) => { setView(v); window.scrollTo(0, 0); };
  if (!app.session) return <AuthScreen />;
  const s = app.session;
  const isCEO = s.role === "ceo";

  const navBiz = (v) => {
    if (v.startsWith("biz-")) {
      const slug = v.slice(4);
      return <BusinessDetail slug={slug} go={go} />;
    }
    if (v.startsWith("site-")) return <BusinessSite slug={v.slice(5)} />;
    switch (v) {
      case "hq": return <HqDashboard go={go} />;
      case "customer": return <CustomerHq />;
      case "moderation": return <Moderation />;
      case "integrations": return <Integrations />;
      case "legal": return <LegalPack />;
      case "vibe": return <VibeStudio />;
      default: return <HqDashboard go={go} />;
    }
  };

  const titles = { hq: "CEO Master Dashboard", customer: "Customer Business HQ", moderation: "Marketplace review & intercompany ledger", integrations: "Integration register", legal: "Trust Vault legal pack", vibe: "Vibe Coding Platform" };
  const title = view.startsWith("biz-") ? app.companies[view.slice(4)].name : view.startsWith("site-") ? app.companies[view.slice(5)].name + " — public site" : titles[view] || "Empire";

  return (
    <div className="shell">
      <aside className="side">
        <div className="brand">Empire HQ</div>
        <div className="sub">Seven-business ecosystem · GBP</div>
        <div className="grp">Overview</div>
        <button className={view === "hq" ? "on" : ""} onClick={() => go("hq")}>📊 CEO Master Dashboard</button>
        <button className={view === "customer" ? "on" : ""} onClick={() => go("customer")}>👤 Customer Business HQ</button>
        {isCEO && <button className={view === "moderation" ? "on" : ""} onClick={() => go("moderation")}>🧾 Review & ledger</button>}
        <button className={view === "integrations" ? "on" : ""} onClick={() => go("integrations")}>🔌 Integrations</button>
        <button className={view === "legal" ? "on" : ""} onClick={() => go("legal")}>⚖️ Legal pack</button>
        <button className={view === "vibe" ? "on" : ""} onClick={() => go("vibe")}>💻 Vibe Studio</button>
        <div className="grp">Business websites</div>
        {BUSINESSES.map((b) => (
          <button key={b.slug} className={view === "site-" + b.slug ? "on" : ""} onClick={() => go("site-" + b.slug)}>
            {b.name}
          </button>
        ))}
        {isCEO && <div className="grp">Admin</div>}
        {isCEO && BUSINESSES.map((b) => (
          <button key={"a" + b.slug} className={view === "biz-" + b.slug ? "on" : ""} onClick={() => go("biz-" + b.slug)}>
            ⚙︎ {b.name} admin
          </button>
        ))}
      </aside>
      <main className="main">
        <div className="topbar">
          <h1>{title}</h1>
          <div className="userbox">
            <span>{s.name} · {s.role}{s.mfaEnrolled ? " · MFA ✓" : ""}</span>
            {!s.mfaEnrolled && <button className="btn small secondary" onClick={app.enrollMfa}>Enrol MFA</button>}
            <button className="btn small secondary" onClick={app.logout}>Sign out</button>
          </div>
        </div>
        <LoginGate>{navBiz(view)}</LoginGate>
        <p className="tiny muted" style={{ marginTop: 24 }}>
          Demo web application built from the uploaded source releases (empire-full-audit / business-empire-customer-commerce, Phases 5–15) and the Trust Vault Bank Legal Foundation Package (drafting edition 1.0, 18 Nov 2026). Not a production deployment: no real payments, banking, brokerage or live integrations. Data persists in your browser's local storage only.
          {isCEO && <> · <a href="#reset" onClick={(e) => { e.preventDefault(); if (confirm("Reset all demo data?")) app.reset(); }}>Reset demo data</a></>}
        </p>
      </main>
    </div>
  );
}
