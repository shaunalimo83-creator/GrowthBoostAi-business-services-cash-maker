import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

/* ================= money & ledger primitives (from packages/core) ================= */
export const CURRENCIES = ["GBP"];
export const fmtGBP = (minor) =>
  new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" }).format(minor / 100);

/* Double-entry ledger: every journal >=2 entries, balances per currency,
   one company per journal unless an authorised intercompany pair is given. */
export function validateJournal(j) {
  if (j.entries.length < 2) throw new Error("journal requires at least two entries");
  const companies = [...new Set(j.entries.map((e) => e.companyId))];
  if (companies.length > 1) {
    if (!j.intercompany) throw new Error("cross-company post without intercompany authorisation");
    if (!j.intercompany.authorisationRef || j.intercompany.authorisationRef.length < 6)
      throw new Error("intercompany journal requires an authorisation reference");
  }
  const byCur = {};
  for (const e of j.entries) byCur[e.amount.currency] = (byCur[e.amount.currency] || 0) + e.amount.minor;
  for (const [cur, delta] of Object.entries(byCur))
    if (delta !== 0) throw new Error(`journal does not balance in ${cur}: residual ${delta}`);
  return true;
}

/* ================= seed data (from README + schema) ================= */
const BUSINESSES = [
  { slug: "growthboost", name: "GrowthBoost AI", color: "#7C3AED", port: 3001,
    desc: "AI-powered marketing automation and business growth services.",
    services: ["AI marketing automation", "Lead generation campaigns", "SEO content engine", "Analytics & reporting"],
    disclosure: null },
  { slug: "ai-magazine", name: "AI Magazine & Comic Book Studio", color: "#DB2777", port: 3002,
    desc: "AI-generated magazines, comics and creative publishing studio.",
    services: ["AI magazine production", "Comic book studio", "Cover art generation", "Serialised stories"],
    disclosure: null },
  { slug: "trust-vault", name: "Trust Vault Bank", color: "#0F766E", port: 3003,
    desc: "Secure customer digital vault and financial services platform.",
    services: ["Encrypted document vault", "Vault sharing controls", "Financial services (pending authorised partner)"],
    disclosure: "Trust Vault Bank is not an authorised bank. Financial services are provided only through appropriately authorised partners; no banking or payment features are live.",
    restricted: "The words 'bank', 'deposit', 'savings account', 'protected', 'insured', 'escrow', 'safeguarded' and 'FSCS protected' must not be used to imply a permission or protection that does not apply (FSMA restricted words; FCA customer-facing rules)." },
  { slug: "stock-express", name: "Stock Market Express", color: "#B45309", port: 3004,
    desc: "Market intelligence, research, watchlists, portfolio tracking and paper trading.",
    services: ["Research & intelligence", "Watchlists", "Portfolio tracking", "Alerts", "Paper trading"],
    disclosure: "Paper trading only. Live brokerage integration requires an appropriately authorised partner and is currently disabled." },
  { slug: "real-estate", name: "Real Estate Master Developments", color: "#1D4ED8", port: 3005,
    desc: "Property development pipeline, unit tracking and portfolio management.",
    services: ["Development pipeline", "Unit availability tracker", "Investor updates", "Portfolio analytics"],
    disclosure: null },
  { slug: "supergpu", name: "SUPERGPU UNIVERSAL", color: "#DC2626", port: 3006,
    desc: "GPU compute marketplace — reserve GPU hours for AI training and inference.",
    services: ["GPU hour reservations", "H100/A100 clusters", "Inference endpoints", "Developer API"],
    disclosure: null },
  { slug: "dailyaccess", name: "DailyAccess", color: "#0891B2", port: 3007,
    desc: "Membership site: daily digital access passes and curated content.",
    services: ["Daily access passes", "Curated content feed", "Member newsletter", "Community forum"],
    disclosure: null },
];

const CEOS = [
  { email: "ceo@hq.example.com", password: "EmpireCEO1!", name: "CEO" },
  { email: "demo@hq.example.com", password: "Demo1234!", name: "Demo CEO" },
];

/* ================= auth (demo: local, mirrors bootstrap-ceo one-time CEO model) ================= */
const SafeStore = {
  get(k, fb) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : fb; } catch { return fb; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

function seedState() {
  const companies = {};
  BUSINESSES.forEach((b) => {
    companies[b.slug] = {
      ...b,
      revenueMinor: { growthboost: 4820000, "ai-magazine": 2150000, "trust-vault": 360000, "stock-express": 1540000, "real-estate": 7200000, supergpu: 5410000, dailyaccess: 890000 }[b.slug],
      expensesMinor: { growthboost: 1930000, "ai-magazine": 980000, "trust-vault": 410000, "stock-express": 620000, "real-estate": 3960000, supergpu: 2870000, dailyaccess: 350000 }[b.slug],
      customers: { growthboost: 312, "ai-magazine": 158, "trust-vault": 96, "stock-express": 421, "real-estate": 38, supergpu: 143, dailyaccess: 655 }[b.slug],
      status: "active",
      notes: "",
      catalog: [
        { id: b.slug + "-p1", name: `${b.name} — Starter plan`, priceMinor: 2900, kind: "subscription", active: true },
        { id: b.slug + "-p2", name: `${b.name} — Pro plan`, priceMinor: 9900, kind: "subscription", active: true },
        { id: b.slug + "-p3", name: `${b.name} — Enterprise services`, priceMinor: 249900, kind: "service", active: false },
      ],
    };
  });
  return {
    session: null, users: [], companies,
    customers: [], marketplaceProducts: [], marketplaceOrders: [],
    vibeProjects: [], integrations: [
      { id: "i1", name: "Managed identity provider (Google Workspace)", status: "connected", note: "growthboost-secure-google-auth.zip — OAuth 2.0 / OIDC adapter for HQ staff sign-in." },
      { id: "i2", name: "Payment service provider (marketplace checkout + payouts)", status: "unavailable", note: "Deliberately disabled until a regulated PSP merchant account and signed settlement webhooks are configured." },
      { id: "i3", name: "Authorised banking partner (Trust Vault)", status: "unavailable", note: "Trust Vault financial services require an FCA-authorised partner; fail-closed." },
      { id: "i4", name: "Live brokerage / market data feed (Stock Express)", status: "unavailable", note: "Paper trading only until an authorised partner is live." },
      { id: "i5", name: "AI code generation (Vercel AI Gateway)", status: "pending", note: "Wired server-side for the Vibe Coding Platform; not runtime-tested." },
      { id: "i6", name: "PostgreSQL + Prisma + RLS", status: "connected", note: "Company-level row isolation; policies in packages/db/policies/rls.sql." },
    ],
    intercompany: [], journalCount: 0,
    docs: [
      { id: "d1", title: "Legal Foundation & Governance Package (Trust Vault Bank)", edition: "Drafting edition 1.0 — 18 Nov 2026", body: "Solicitor-review working draft for the UK partner-led launch (Birmingham, England). A preliminary drafting aid — not legal advice, a completed legal instrument, an FCA/PRA application or regulatory approval. All square-bracket fields must be completed and independently verified. Engage a UK solicitor experienced in FSMA, payments/e-money, banking, trusts and company law, plus a UK tax adviser and regulatory compliance specialist. The precise regulatory perimeter must be mapped activity by activity: a commercial partnership, BaaS provider, agent/distributor arrangement, outsourcing contract or referral agreement does not itself grant the brand owner regulatory permission." },
      { id: "d2", title: "Document index (01–10)", edition: "Pack contents", body: "01 Founder's structure and instructions memorandum · 02 Parent company governance framework and draft articles schedule · 03 Founder/CEO appointments (11) · 04 Trustee appointment and retirement deed pack (14) · 05 Parent–subsidiary and intercompany agreement pack (11) · 06 Partner-led financial services agreement pack (17) · 07 Customer terms and disclosures (15) · 08 Regulatory readiness and compliance framework (12) · 09 Data protection and operational policies (14) · 10 Signing, closing and post-completion bundle (11)." },
      { id: "d3", title: "Appendix B — Key official reference material", edition: "Links", body: "Bank of England — New bank authorisation process (bankofengland.co.uk/prudential-regulation/new-bank-start-up-unit) · FCA — Safeguarding requirements for payment and e-money institutions (fca.org.uk/firms/emi-payment-institutions-safeguarding-requirements) · FCA — Payment Services and Electronic Money: Our Approach, March 2026 · GOV.UK — When you must register a trust (gov.uk/trusts-taxes/registering-a-trust) · GOV.UK — Trust record-keeping for tax purposes · GOV.UK — Incorporation and names." },
      { id: "d4", title: "Appendix C — Execution checklist", edition: "Checklist", body: "Confirm legal names and capacity of every party · confirm whether the document is an agreement, deed, board resolution or policy · check deed execution and witness requirements with a solicitor · check whether independent legal advice is required · complete schedules, annexes, dates, defined terms and cross-references · confirm stamp duty, land registration, Companies House or HMRC filings · obtain regulated partner approval where required · sign, date, deliver and store executed copies securely · maintain a register of versions, approvals, review dates and responsible owners." },
      { id: "d5", title: "Architecture — platform, tenancy, isolation", edition: "docs/architecture.md", body: "Nine app workspaces: 7 business apps, CEO HQ and the shared Vibe Coding Platform. One shared TypeScript core, one PostgreSQL schema with company-level data isolation (RLS), double-entry ledger with financial controls, intercompany authorisation, TOTP MFA, rate-limited login, recovery codes. Reporting currency GBP everywhere." },
      { id: "d6", title: "Phase register (Phases 5–15)", edition: "docs/*", body: "P5 one-time CEO bootstrap (no public signup) · P6 session/recovery hardening + login throttling · P7 PostgreSQL RLS tenant isolation hardening · P8 API tenant context, fail-closed 503 routes · P9 business workspaces (setup-pending disclosures) · P10 shared customer identity across all 7 apps · P11 customer security (email verification, TOTP MFA, recovery codes) · P12 account recovery · P13 authorisation checks · P14 Vibe Coding Platform · P15 customer business HQ & marketplace (checkout/payouts disabled)." },
    ],
  };
}

export function AppProvider({ children }) {
  const [state, setState] = useState(() => SafeStore.get("empire.v1", null) || seedState());
  useEffect(() => SafeStore.set("empire.v1", state), [state]);

  const api = useMemo(() => {
    const patch = (fn) => setState((s) => ({ ...s, ...fn(s) }));
    return {
      state,
      // ---- auth ----
      login(email, password) {
        const u = state.users.find((u) => u.email === email && u.password === password);
        const ceo = CEOS.find((c) => c.email === email && c.password === password);
        if (u || ceo) {
          const name = ceo ? ceo.name : u.name;
          const role = ceo ? "ceo" : u.role;
          patch((s) => ({ session: { email, name, role, mfaEnrolled: ceo ? true : !!u.mfaEnrolled } }));
          return { ok: true, role, mfaEnrolled: ceo ? true : !!u.mfaEnrolled };
        }
        return { ok: false, error: "Invalid email or password." };
      },
      register(email, password, name, businessSlug) {
        if (state.users.some((u) => u.email === email)) return { ok: false, error: "An account with this email already exists." };
        if (password.length < 8) return { ok: false, error: "Password must be at least 8 characters." };
        patch((s) => ({
          users: [...s.users, { email, password, name, role: "customer", mfaEnrolled: false, business: businessSlug, recoveryCodes: Array.from({ length: 8 }, () => Math.random().toString(36).slice(2, 10).toUpperCase()) }],
          session: { email, name, role: "customer", mfaEnrolled: false },
          customers: [...s.customers, { id: "c" + Date.now(), email, name, business: businessSlug, joined: new Date().toISOString().slice(0, 10) }],
        }));
        return { ok: true };
      },
      logout() { patch(() => ({ session: null })); },
      enrollMfa() { patch((s) => ({ session: { ...s.session, mfaEnrolled: true } })); },
      // ---- business admin ----
      toggleProduct(slug, id) { patch((s) => ({ companies: { ...s.companies, [slug]: { ...s.companies[slug], catalog: s.companies[slug].catalog.map((p) => (p.id === id ? { ...p, active: !p.active } : p)) } } })); },
      addProduct(slug, name, priceMinor, kind) { patch((s) => ({ companies: { ...s.companies, [slug]: { ...s.companies[slug], catalog: [...s.companies[slug].catalog, { id: slug + "-p" + Date.now(), name, priceMinor, kind, active: true }] } } })); },
      setCompanyStatus(slug, status) { patch((s) => ({ companies: { ...s.companies, [slug]: { ...s.companies[slug], status } } })); },
      saveNote(slug, notes) { patch((s) => ({ companies: { ...s.companies, [slug]: { ...s.companies[slug], notes } } })); },
      // ---- marketplace (checkout disabled until PSP — fail closed) ----
      createListing(sellerEmail, businessSlug, title, desc, productType, priceMinor) {
        patch((s) => ({ marketplaceProducts: [...s.marketplaceProducts, { id: "mp" + Date.now(), sellerEmail, businessSlug, title, desc, productType, priceMinor, status: "pending_review" }] }));
        return { ok: true, status: "pending_review" };
      },
      moderateListing(id, status) { patch((s) => ({ marketplaceProducts: s.marketplaceProducts.map((p) => (p.id === id ? { ...p, status } : p)) })); },
      createOrder(productId) {
        let result = null;
        patch((s) => {
          const p = s.marketplaceProducts.find((p) => p.id === productId);
          if (!p) return {};
          const order = { id: "ord" + Date.now(), productId, title: p.title, sellerEmail: p.sellerEmail, priceMinor: p.priceMinor, status: "pending_payment", note: "Checkout is disabled until a regulated PSP integration and signed settlement webhooks are configured. This order was NOT charged." };
          result = order;
          return { marketplaceOrders: [...s.marketplaceOrders, order] };
        });
        return result;
      },
      // ---- vibe coding platform (free plan: max 3 projects) ----
      createVibeProject(ownerEmail, name, html) {
        const mine = state.vibeProjects.filter((p) => p.ownerEmail === ownerEmail);
        if (mine.length >= 3) return { ok: false, error: "Free plan limit reached: 3 projects. Upgrade required for more (checkout pending PSP)." };
        const id = "vp" + Date.now();
        patch((s) => ({ vibeProjects: [...s.vibeProjects, { id, ownerEmail, name, html: html || "<h1>Hello from Vibe Studio</h1>", createdAt: new Date().toISOString().slice(0, 10) }] }));
        return { ok: true, id };
      },
      updateVibeProject(id, html) { patch((s) => ({ vibeProjects: s.vibeProjects.map((p) => (p.id === id ? { ...p, html } : p)) })); },
      deleteVibeProject(id) { patch((s) => ({ vibeProjects: s.vibeProjects.filter((p) => p.id !== id) })); },
      // ---- HQ ledger / intercompany ----
      postIntercompany(fromSlug, toSlug, amountMinor, ref, memo) {
        try {
          if (fromSlug === toSlug) throw new Error("Choose two different companies");
          if (!ref || ref.length < 6) throw new Error("Intercompany journal requires an authorisation reference of at least 6 characters");
          validateJournal({ entries: [
            { companyId: fromSlug, accountCode: "1400-due-from", amount: { currency: "GBP", minor: amountMinor } },
            { companyId: toSlug, accountCode: "2400-due-to", amount: { currency: "GBP", minor: -amountMinor } },
          ], intercompany: { fromCompanyId: fromSlug, toCompanyId: toSlug, authorisationRef: ref } });
          patch((s) => ({ intercompany: [...s.intercompany, { id: "ic" + Date.now(), fromSlug, toSlug, amountMinor, ref, memo, date: new Date().toISOString().slice(0, 10) }], journalCount: s.journalCount + 1 }));
          return { ok: true };
        } catch (e) { return { ok: false, error: e.message }; }
      },
      reset() { setState(seedState()); },
    };
  }, [state]);

  return <Ctx.Provider value={{ ...state, ...api }}>{children}</Ctx.Provider>;
}

export { BUSINESSES, CEOS };
